CREATE FUNCTION st_translate(geometry, double precision, double precision, double precision) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_Affine($1, 1, 0, 0, 0, 1, 0, 0, 0, 1, $2, $3, $4)
$$;

COMMENT ON FUNCTION st_translate(GEOMETRY, DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION) IS 'args: g1, deltax, deltay, deltaz - Translate a geometry by given offsets.';

ALTER FUNCTION st_translate(GEOMETRY, DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION) OWNER TO postgres;

