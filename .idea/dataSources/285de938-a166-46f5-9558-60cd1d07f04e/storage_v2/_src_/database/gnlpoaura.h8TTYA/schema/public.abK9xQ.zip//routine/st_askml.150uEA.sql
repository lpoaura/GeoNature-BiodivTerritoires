CREATE FUNCTION st_askml(geog geography, maxdecimaldigits integer DEFAULT 15) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_AsKML(2, $1, $2, null)
$$;

COMMENT ON FUNCTION st_askml(GEOGRAPHY, INTEGER) IS 'args: geog, maxdecimaldigits=15 - Return the geometry as a KML element. Several variants. Default version=2, default maxdecimaldigits=15';

ALTER FUNCTION st_askml(GEOGRAPHY, INTEGER) OWNER TO postgres;

