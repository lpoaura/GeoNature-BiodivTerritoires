CREATE FUNCTION refresh_materialized_view_data() RETURNS void
    LANGUAGE plpgsql
AS
$$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY gn_dashboard.vm_synthese;
  REFRESH MATERIALIZED VIEW CONCURRENTLY gn_dashboard.vm_synthese_frameworks;
  REFRESH MATERIALIZED VIEW CONCURRENTLY gn_dashboard.vm_taxonomie;
END
$$;

ALTER FUNCTION refresh_materialized_view_data() OWNER TO geonature;

