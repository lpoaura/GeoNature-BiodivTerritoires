CREATE FUNCTION st_astiff(rast raster, nbands integer[], compression text, srid integer DEFAULT NULL::integer) RETURNS bytea
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT st_astiff(st_band($1, $2), $3, $4)
$$;

COMMENT ON FUNCTION st_astiff(RASTER, INTEGER[], TEXT, INTEGER) IS 'args: rast, nbands, compression='', srid=sameassource - Return the raster selected bands as a single TIFF image (byte array). If no band is specified or any of specified bands does not exist in the raster, then will try to use all bands.';

ALTER FUNCTION st_astiff(RASTER, INTEGER[], TEXT, INTEGER) OWNER TO postgres;

