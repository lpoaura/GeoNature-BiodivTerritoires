CREATE FUNCTION st_grayscale(rast raster, redband integer DEFAULT 1, greenband integer DEFAULT 2, blueband integer DEFAULT 3, extenttype text DEFAULT 'INTERSECTION'::text) RETURNS raster
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE plpgsql
AS
$$
DECLARE
	BEGIN

		RETURN public.ST_Grayscale(
			ARRAY[
				ROW(rast, redband)::rastbandarg,
				ROW(rast, greenband)::rastbandarg,
				ROW(rast, blueband)::rastbandarg
			]::rastbandarg[],
			extenttype
		);

	END;

$$;

ALTER FUNCTION st_grayscale(RASTER, INTEGER, INTEGER, INTEGER, TEXT) OWNER TO postgres;

