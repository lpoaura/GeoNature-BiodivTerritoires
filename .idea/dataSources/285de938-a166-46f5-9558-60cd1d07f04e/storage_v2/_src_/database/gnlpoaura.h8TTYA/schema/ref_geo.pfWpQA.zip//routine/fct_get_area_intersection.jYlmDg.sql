CREATE FUNCTION fct_get_area_intersection(mygeom geometry, myidtype integer DEFAULT NULL::integer)
    RETURNS TABLE(id_area integer, id_type integer, area_code character varying, area_name character varying)
    LANGUAGE plpgsql
AS
$$
DECLARE
  isrid int;
BEGIN
  SELECT gn_commons.get_default_parameter('local_srid', NULL) INTO isrid;
  RETURN QUERY
  WITH d  as (
      SELECT public.st_transform(myGeom,isrid) geom_trans
  )
  SELECT a.id_area, a.id_type, a.area_code, a.area_name
  FROM ref_geo.l_areas a, d
  WHERE public.st_intersects(geom_trans, a.geom)
    AND (myIdType IS NULL OR a.id_type = myIdType)
    AND enable=true;
END;
$$;

ALTER FUNCTION fct_get_area_intersection(GEOMETRY, INTEGER) OWNER TO geonature;

