CREATE FUNCTION to_timestamp_from_excel(exceldate integer) RETURNS timestamp without time zone
    LANGUAGE plpgsql
AS
$$
BEGIN
   IF ExcelDate > 59 THEN
    ExcelDate = ExcelDate - 1;
   END IF;
   RETURN date '1899-12-31' + ExcelDate;
END;
$$;

ALTER FUNCTION to_timestamp_from_excel(INTEGER) OWNER TO lpoaura_fcl;

