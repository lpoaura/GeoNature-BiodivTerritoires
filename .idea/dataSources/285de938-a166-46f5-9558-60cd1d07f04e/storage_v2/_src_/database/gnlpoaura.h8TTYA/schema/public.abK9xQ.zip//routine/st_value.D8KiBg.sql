CREATE FUNCTION st_value(rast raster, x integer, y integer, exclude_nodata_value boolean DEFAULT true) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT st_value($1, 1, $2, $3, $4)
$$;

COMMENT ON FUNCTION st_value(RASTER, INTEGER, INTEGER, BOOLEAN) IS 'args: rast, x, y, exclude_nodata_value=true - Returns the value of a given band in a given columnx, rowy pixel or at a particular geometric point. Band numbers start at 1 and assumed to be 1 if not specified. If exclude_nodata_value is set to false, then all pixels include nodata pixels are considered to intersect and return value. If exclude_nodata_value is not passed in then reads it from metadata of raster.';

ALTER FUNCTION st_value(RASTER, INTEGER, INTEGER, BOOLEAN) OWNER TO postgres;

