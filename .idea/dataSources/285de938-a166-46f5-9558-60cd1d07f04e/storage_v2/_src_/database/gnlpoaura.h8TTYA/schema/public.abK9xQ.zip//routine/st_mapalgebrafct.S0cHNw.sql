CREATE FUNCTION st_mapalgebrafct(rast raster, band integer, onerastuserfunc regprocedure, VARIADIC args text[]) RETURNS raster
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_mapalgebrafct($1, $2, NULL, $3, VARIADIC $4)
$$;

ALTER FUNCTION st_mapalgebrafct(RASTER, INTEGER, REGPROCEDURE, TEXT[]) OWNER TO postgres;

