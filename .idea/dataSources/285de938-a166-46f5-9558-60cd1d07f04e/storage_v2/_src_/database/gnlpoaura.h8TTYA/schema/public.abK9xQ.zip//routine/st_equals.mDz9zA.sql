CREATE FUNCTION st_equals(geom1 geometry, geom2 geometry) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.~=) $2 AND public._ST_Equals($1,$2)
$$;

COMMENT ON FUNCTION st_equals(GEOMETRY, GEOMETRY) IS 'args: A, B - Returns true if the given geometries represent the same geometry. Directionality is ignored.';

ALTER FUNCTION st_equals(GEOMETRY, GEOMETRY) OWNER TO postgres;

