CREATE FUNCTION modify_date_update() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
BEGIN
    NEW.date_update := now();
    RETURN NEW;
END;
$$;

ALTER FUNCTION modify_date_update() OWNER TO geonature;

