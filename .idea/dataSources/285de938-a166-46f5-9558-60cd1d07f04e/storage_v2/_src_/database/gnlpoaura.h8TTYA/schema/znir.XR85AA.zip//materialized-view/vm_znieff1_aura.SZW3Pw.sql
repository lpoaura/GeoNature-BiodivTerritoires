CREATE MATERIALIZED VIEW vm_znieff1_aura AS
SELECT
    znieff1_aura.fid
  , znieff1_aura.msgeometry AS geom
  , znieff1_aura.gml_id
  , znieff1_aura.gid
  , znieff1_aura.id_org
  , znieff1_aura.id_mnhn
  , znieff1_aura.nom
  , znieff1_aura.url_pdf
  , znieff1_aura.lien_mnhn
  , znieff1_aura.surface_si
  , znieff1_aura.generation
FROM tmp.znieff1_aura;

ALTER MATERIALIZED VIEW vm_znieff1_aura OWNER TO geonature;

