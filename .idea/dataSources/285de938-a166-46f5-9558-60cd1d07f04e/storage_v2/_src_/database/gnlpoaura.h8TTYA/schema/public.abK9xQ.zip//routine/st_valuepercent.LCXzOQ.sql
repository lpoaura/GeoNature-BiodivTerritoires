CREATE FUNCTION st_valuepercent(rast raster, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT percent double precision) RETURNS SETOF record
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT value, percent FROM public._ST_valuecount($1, 1, TRUE, $2, $3)
$$;

ALTER FUNCTION st_valuepercent(RASTER, DOUBLE PRECISION[], DOUBLE PRECISION, OUT DOUBLE PRECISION, OUT DOUBLE PRECISION) OWNER TO postgres;

