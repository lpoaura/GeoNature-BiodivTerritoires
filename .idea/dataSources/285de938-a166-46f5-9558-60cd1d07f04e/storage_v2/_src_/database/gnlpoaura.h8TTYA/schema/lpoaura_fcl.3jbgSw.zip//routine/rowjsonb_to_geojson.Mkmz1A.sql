CREATE FUNCTION rowjsonb_to_geojson(rowjsonb jsonb, geom_column text DEFAULT 'geom'::text) RETURNS text
    IMMUTABLE
    STRICT
    LANGUAGE plpgsql
AS
$$
DECLARE
 json_props jsonb;
 json_geom jsonb;
 json_type jsonb;
BEGIN
 IF NOT rowjsonb ? geom_column THEN
   RAISE EXCEPTION 'geometry column ''%'' is missing', geom_column;
 END IF;
 json_geom := ST_AsGeoJSON((rowjsonb ->> geom_column)::geometry)::jsonb;
 json_geom := jsonb_build_object('geometry', json_geom);
 json_props := jsonb_build_object('properties', rowjsonb - geom_column);
 json_type := jsonb_build_object('type', 'Feature');
 return (json_type || json_geom || json_props)::text;
END;
$$;

ALTER FUNCTION rowjsonb_to_geojson(JSONB, TEXT) OWNER TO lpoaura_fcl;

