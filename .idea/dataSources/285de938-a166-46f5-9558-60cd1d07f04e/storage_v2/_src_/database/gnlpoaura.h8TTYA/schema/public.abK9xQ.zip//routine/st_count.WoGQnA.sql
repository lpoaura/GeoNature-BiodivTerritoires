CREATE FUNCTION st_count(rastertable text, rastercolumn text, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true) RETURNS bigint
    STABLE
    STRICT
    LANGUAGE SQL
AS
$$
SELECT public._ST_count($1, $2, $3, $4, 1)
$$;

COMMENT ON FUNCTION st_count(TEXT, TEXT, INTEGER, BOOLEAN) IS 'args: rastertable, rastercolumn, nband=1, exclude_nodata_value=true - Returns the number of pixels in a given band of a raster or raster coverage. If no band is specified defaults to band 1. If exclude_nodata_value is set to true, will only count pixels that are not equal to the nodata value.';

ALTER FUNCTION st_count(TEXT, TEXT, INTEGER, BOOLEAN) OWNER TO postgres;

