CREATE FUNCTION st_worldtorastercoordy(rast raster, xw double precision, yw double precision) RETURNS integer
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT rowy FROM public._ST_worldtorastercoord($1, $2, $3)
$$;

COMMENT ON FUNCTION st_worldtorastercoordy(RASTER, DOUBLE PRECISION, DOUBLE PRECISION) IS 'args: rast, xw, yw - Returns the row in the raster of the point geometry (pt) or a X and Y world coordinate (xw, yw) represented in world spatial reference system of raster.';

ALTER FUNCTION st_worldtorastercoordy(RASTER, DOUBLE PRECISION, DOUBLE PRECISION) OWNER TO postgres;

