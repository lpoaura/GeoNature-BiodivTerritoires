CREATE FUNCTION st_valuepercent(rast raster, nband integer, searchvalue double precision, roundto double precision DEFAULT 0) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT ( public._ST_valuecount($1, $2, TRUE, ARRAY[$3]::double precision[], $4)).percent
$$;

ALTER FUNCTION st_valuepercent(RASTER, INTEGER, DOUBLE PRECISION, DOUBLE PRECISION) OWNER TO postgres;

