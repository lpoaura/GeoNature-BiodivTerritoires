CREATE FUNCTION update_timestamp() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
BEGIN
  IF (NEW != OLD)
  THEN
    NEW.timestamp_update = CURRENT_TIMESTAMP;
    RETURN NEW;
  END IF;
  RETURN OLD;
END;
$$;

ALTER FUNCTION update_timestamp() OWNER TO lpoaura_fcl;

