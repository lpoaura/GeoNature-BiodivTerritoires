CREATE MATERIALIZED VIEW vm_phylum AS
SELECT DISTINCT tx.phylum
FROM taxonomie.taxref tx;

ALTER MATERIALIZED VIEW vm_phylum OWNER TO geonature;

CREATE UNIQUE INDEX i_unique_phylum
    ON vm_phylum(phylum);

