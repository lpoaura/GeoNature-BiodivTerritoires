CREATE FUNCTION st_quantile(rast raster, quantiles double precision[], OUT quantile double precision, OUT value double precision) RETURNS SETOF record
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_quantile($1, 1, TRUE, 1, $2)
$$;

COMMENT ON FUNCTION st_quantile(RASTER, DOUBLE PRECISION[], OUT DOUBLE PRECISION, OUT DOUBLE PRECISION) IS 'args: rast, quantiles - Compute quantiles for a raster or raster table coverage in the context of the sample or population. Thus, a value could be examined to be at the rasters 25%, 50%, 75% percentile.';

ALTER FUNCTION st_quantile(RASTER, DOUBLE PRECISION[], OUT DOUBLE PRECISION, OUT DOUBLE PRECISION) OWNER TO postgres;

