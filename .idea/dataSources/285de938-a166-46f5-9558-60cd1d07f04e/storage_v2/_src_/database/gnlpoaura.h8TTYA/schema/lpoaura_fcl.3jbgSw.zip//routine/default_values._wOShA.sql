CREATE FUNCTION default_values() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin
        if new.reference is null or new.reference = ''
        then
            new.reference := current_user || extract(epoch from now())::int::text;
        end if;
        if new.creator is null or new.creator = ''
        then
            new.creator := current_user;
        end if;
        if new.id is null or new.id = 0
        then
            -- new.id := NEXTVAL('zone_etude_pkey');
            new := new::hstore - 'id'::hstore;
        end if;
        if new.timestamp_create is null
        then
            new.timestamp_create := now();
        end if;
        return new;
    end
$$;

ALTER FUNCTION default_values() OWNER TO lpoaura_fcl;

