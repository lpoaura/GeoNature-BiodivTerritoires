CREATE FUNCTION st_asgeojson(gj_version integer, geog geography, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_AsGeoJson($1, $2, $3, $4);
$$;

COMMENT ON FUNCTION st_asgeojson(INTEGER, GEOGRAPHY, INTEGER, INTEGER) IS 'args: gj_version, geog, maxdecimaldigits=15, options=0 - Return the geometry as a GeoJSON element.';

ALTER FUNCTION st_asgeojson(INTEGER, GEOGRAPHY, INTEGER, INTEGER) OWNER TO postgres;

