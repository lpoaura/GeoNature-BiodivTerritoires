CREATE FUNCTION get_id_source(mysource character varying) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
DECLARE
    myidsource INTEGER;
BEGIN
    SELECT id_source INTO myidsource
        from gn_synthese.t_sources
        where name_source ILIKE mysource;
    RETURN myidsource;
END;
$$;

ALTER FUNCTION get_id_source(VARCHAR) OWNER TO geonature;

