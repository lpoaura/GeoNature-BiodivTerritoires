CREATE FUNCTION st_approxsummarystats(rast raster, nband integer, sample_percent double precision) RETURNS summarystats
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_summarystats($1, $2, TRUE, $3)
$$;

ALTER FUNCTION st_approxsummarystats(RASTER, INTEGER, DOUBLE PRECISION) OWNER TO postgres;

