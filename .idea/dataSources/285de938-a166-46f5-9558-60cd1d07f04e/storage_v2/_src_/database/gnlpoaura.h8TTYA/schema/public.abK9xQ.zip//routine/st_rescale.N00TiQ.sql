CREATE FUNCTION st_rescale(rast raster, scalex double precision, scaley double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) RETURNS raster
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT  public._ST_GdalWarp($1, $4, $5, NULL, $2, $3)
$$;

COMMENT ON FUNCTION st_rescale(RASTER, DOUBLE PRECISION, DOUBLE PRECISION, TEXT, DOUBLE PRECISION) IS 'args: rast, scalex, scaley, algorithm=NearestNeighbour, maxerr=0.125 - Resample a raster by adjusting only its scale (or pixel size). New pixel values are computed using the NearestNeighbor (english or american spelling), Bilinear, Cubic, CubicSpline or Lanczos resampling algorithm. Default is NearestNeighbor.';

ALTER FUNCTION st_rescale(RASTER, DOUBLE PRECISION, DOUBLE PRECISION, TEXT, DOUBLE PRECISION) OWNER TO postgres;

