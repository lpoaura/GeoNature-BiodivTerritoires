CREATE FUNCTION st_dwithin(geography, geography, double precision, boolean) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.&&) public._ST_Expand($2,$3) AND $2 OPERATOR(public.&&) public._ST_Expand($1,$3) AND public._ST_DWithin($1, $2, $3, $4)
$$;

COMMENT ON FUNCTION st_dwithin(GEOGRAPHY, GEOGRAPHY, DOUBLE PRECISION, BOOLEAN) IS 'args: gg1, gg2, distance_meters, use_spheroid - Returns true if the geometries are within the specified distance of one another. For geometry units are in those of spatial reference and for geography units are in meters and measurement is defaulted to use_spheroid=true (measure around spheroid), for faster check, use_spheroid=false to measure along sphere.';

ALTER FUNCTION st_dwithin(GEOGRAPHY, GEOGRAPHY, DOUBLE PRECISION, BOOLEAN) OWNER TO postgres;

