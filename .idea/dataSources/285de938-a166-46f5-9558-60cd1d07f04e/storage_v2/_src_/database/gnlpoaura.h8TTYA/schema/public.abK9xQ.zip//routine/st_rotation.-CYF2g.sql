CREATE FUNCTION st_rotation(raster) RETURNS double precision
    LANGUAGE SQL
AS
$$
SELECT ( public.ST_Geotransform($1)).theta_i
$$;

COMMENT ON FUNCTION st_rotation(RASTER) IS 'args: rast - Returns the rotation of the raster in radian.';

ALTER FUNCTION st_rotation(RASTER) OWNER TO postgres;

