CREATE FUNCTION st_multipolygonfromtext(text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_MPolyFromText($1)
$$;

ALTER FUNCTION st_multipolygonfromtext(TEXT) OWNER TO postgres;

