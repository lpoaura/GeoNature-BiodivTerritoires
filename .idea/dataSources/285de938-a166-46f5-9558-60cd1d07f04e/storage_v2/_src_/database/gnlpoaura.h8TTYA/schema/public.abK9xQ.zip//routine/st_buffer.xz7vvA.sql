CREATE FUNCTION st_buffer(geography, double precision, text) RETURNS geography
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.geography(public.ST_Transform(public.ST_Buffer(public.ST_Transform(public.geometry($1), public._ST_BestSRID($1)), $2, $3), 4326))
$$;

COMMENT ON FUNCTION st_buffer(GEOGRAPHY, DOUBLE PRECISION, TEXT) IS 'args: g1, radius_of_buffer, buffer_style_parameters - (T)Returns a geometry covering all points within a given distancefrom the input geometry.';

ALTER FUNCTION st_buffer(GEOGRAPHY, DOUBLE PRECISION, TEXT) OWNER TO postgres;

