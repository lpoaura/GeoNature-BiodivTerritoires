CREATE FUNCTION st_linefromwkb(bytea) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'LINESTRING'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END

$$;

COMMENT ON FUNCTION st_linefromwkb(BYTEA) IS 'args: WKB - Makes a LINESTRING from WKB with the given SRID';

ALTER FUNCTION st_linefromwkb(BYTEA) OWNER TO postgres;

