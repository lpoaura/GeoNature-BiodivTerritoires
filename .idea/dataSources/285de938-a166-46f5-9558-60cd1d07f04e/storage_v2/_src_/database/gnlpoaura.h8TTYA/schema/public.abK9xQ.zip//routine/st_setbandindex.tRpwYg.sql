CREATE FUNCTION st_setbandindex(rast raster, band integer, outdbindex integer, force boolean DEFAULT false) RETURNS raster
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_SetBandPath($1, $2, NULL, $3, $4)
$$;

COMMENT ON FUNCTION st_setbandindex(RASTER, INTEGER, INTEGER, BOOLEAN) IS 'args: rast, band, outdbindex, force=false - Update the external band number of an out-db band';

ALTER FUNCTION st_setbandindex(RASTER, INTEGER, INTEGER, BOOLEAN) OWNER TO postgres;

