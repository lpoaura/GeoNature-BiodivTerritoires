CREATE FUNCTION st_angle(line1 geometry, line2 geometry) RETURNS double precision
    IMMUTABLE
    STRICT
    LANGUAGE SQL
AS
$$
SELECT ST_Angle(St_StartPoint($1), ST_EndPoint($1), St_StartPoint($2), ST_EndPoint($2))
$$;

COMMENT ON FUNCTION st_angle(GEOMETRY, GEOMETRY) IS 'args: line1, line2 - Returns the angle between 3 points, or between 2 vectors (4 points or 2 lines).';

ALTER FUNCTION st_angle(GEOMETRY, GEOMETRY) OWNER TO postgres;

