CREATE FUNCTION fct_trg_cor_site_area() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
BEGIN

	DELETE FROM gn_monitoring.cor_site_area WHERE id_base_site = NEW.id_base_site;
	INSERT INTO gn_monitoring.cor_site_area
	SELECT NEW.id_base_site, (ref_geo.fct_get_area_intersection(NEW.geom)).id_area;

  RETURN NEW;
END;
$$;

ALTER FUNCTION fct_trg_cor_site_area() OWNER TO geonature;

