CREATE FUNCTION dropgeometrycolumn(schema_name character varying, table_name character varying, column_name character varying) RETURNS text
    STRICT
    LANGUAGE plpgsql
AS
$$
DECLARE
	ret text;
BEGIN
	SELECT public.DropGeometryColumn('',$1,$2,$3) into ret;
	RETURN ret;
END;
$$;

COMMENT ON FUNCTION dropgeometrycolumn(VARCHAR, VARCHAR, VARCHAR) IS 'args: schema_name, table_name, column_name - Removes a geometry column from a spatial table.';

ALTER FUNCTION dropgeometrycolumn(VARCHAR, VARCHAR, VARCHAR) OWNER TO postgres;

