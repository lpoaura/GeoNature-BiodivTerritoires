CREATE RULE lpoaura_fcl_layer_style_ins AS
    ON INSERT TO layer_styles DO INSTEAD  INSERT INTO qgis_shared.layer_styles (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, stylename, styleqml, stylesld, useasdefault, description, owner, ui)
  VALUES (new.f_table_catalog, new.f_table_schema, new.f_table_name, new.f_geometry_column, new.stylename, new.styleqml, new.stylesld, new.useasdefault, new.description, new.owner, new.ui);

