CREATE VIEW v_metadata_for_export(jeu_donnees, jdd_id, jdd_uuid, cadre_acquisition, acteurs, nombre_obs) AS
WITH
    count_nb_obs AS (
        SELECT
            count(*) AS nb_obs
          , synthese.id_dataset
        FROM gn_synthese.synthese
        GROUP BY synthese.id_dataset
    )
SELECT
    d.dataset_name                                                        AS jeu_donnees
  , d.id_dataset                                                          AS jdd_id
  , d.unique_dataset_id                                                   AS jdd_uuid
  , af.acquisition_framework_name                                         AS cadre_acquisition
  , string_agg(DISTINCT concat(COALESCE(orga.nom_organisme,
                                        ((roles.nom_role::TEXT || ' '::TEXT) || roles.prenom_role::TEXT)::CHARACTER VARYING),
                               ': ', nomencl.label_default), ' | '::TEXT) AS acteurs
  , count_nb_obs.nb_obs                                                   AS nombre_obs
FROM
    gn_meta.t_datasets d
        JOIN gn_meta.t_acquisition_frameworks af ON af.id_acquisition_framework = d.id_acquisition_framework
        JOIN gn_meta.cor_dataset_actor act ON act.id_dataset = d.id_dataset
        JOIN ref_nomenclatures.t_nomenclatures nomencl ON nomencl.id_nomenclature = act.id_nomenclature_actor_role
        LEFT JOIN utilisateurs.bib_organismes orga ON orga.id_organisme = act.id_organism
        LEFT JOIN utilisateurs.t_roles roles ON roles.id_role = act.id_role
        JOIN count_nb_obs ON count_nb_obs.id_dataset = d.id_dataset
GROUP BY
    d.id_dataset
  , d.unique_dataset_id
  , d.dataset_name
  , af.acquisition_framework_name
  , count_nb_obs.nb_obs;

ALTER TABLE v_metadata_for_export
    OWNER TO geonature;

