CREATE FUNCTION default_creator() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin
        if NEW.creator is null or NEW.creator = ''
        then
            NEW.creator := current_user;
        end if;
        return NEW;
    end
$$;

ALTER FUNCTION default_creator() OWNER TO lpoaura_fcl;

