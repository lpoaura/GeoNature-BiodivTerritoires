CREATE VIEW v_color_taxon_area(cd_nom, id_area, nb_obs, last_date, color) AS
SELECT
    cor_area_taxon.cd_nom
  , cor_area_taxon.id_area
  , cor_area_taxon.nb_obs
  , cor_area_taxon.last_date
  , CASE
        WHEN date_part('day'::TEXT, now() - cor_area_taxon.last_date::TIMESTAMP WITH TIME ZONE) < 365::DOUBLE PRECISION
            THEN 'grey'::TEXT
        ELSE 'red'::TEXT
        END AS color
FROM gn_synthese.cor_area_taxon;

ALTER TABLE v_color_taxon_area
    OWNER TO geonature;

