CREATE FUNCTION st_polygonfromtext(text, integer) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_PolyFromText($1, $2)
$$;

COMMENT ON FUNCTION st_polygonfromtext(TEXT, INTEGER) IS 'args: WKT, srid - Makes a Geometry from WKT with the given SRID. If SRID is not given, it defaults to 0.';

ALTER FUNCTION st_polygonfromtext(TEXT, INTEGER) OWNER TO postgres;

