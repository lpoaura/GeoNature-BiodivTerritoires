CREATE FUNCTION get_default_nomenclature_value(myidtype character varying, myidorganism integer DEFAULT 0, myregne character varying DEFAULT '0'::character varying, mygroup2inpn character varying DEFAULT '0'::character varying) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
    --Function that return the default nomenclature id with wanteds nomenclature type, organism id, regne, group2_inpn
--Return -1 if nothing matche with given parameters
  DECLARE
    theidnomenclature integer;
  BEGIN
      SELECT INTO theidnomenclature id_nomenclature
      FROM gn_synthese.defaults_nomenclatures_value
      WHERE mnemonique_type = myidtype
      AND (id_organism = 0 OR id_organism = myidorganism)
      AND (regne = '0' OR regne = myregne)
      AND (group2_inpn = '0' OR group2_inpn = mygroup2inpn)
      ORDER BY group2_inpn DESC, regne DESC, id_organism DESC LIMIT 1;
    IF (theidnomenclature IS NOT NULL) THEN
      RETURN theidnomenclature;
    END IF;
    RETURN NULL;
  END;
$$;

ALTER FUNCTION get_default_nomenclature_value(VARCHAR, INTEGER, VARCHAR, VARCHAR) OWNER TO geonature;

