CREATE FUNCTION st_worldtorastercoordx(rast raster, xw double precision) RETURNS integer
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT columnx FROM public._ST_worldtorastercoord($1, $2, NULL)
$$;

COMMENT ON FUNCTION st_worldtorastercoordx(RASTER, DOUBLE PRECISION) IS 'args: rast, xw - Returns the column in the raster of the point geometry (pt) or a X and Y world coordinate (xw, yw) represented in world spatial reference system of raster.';

ALTER FUNCTION st_worldtorastercoordx(RASTER, DOUBLE PRECISION) OWNER TO postgres;

