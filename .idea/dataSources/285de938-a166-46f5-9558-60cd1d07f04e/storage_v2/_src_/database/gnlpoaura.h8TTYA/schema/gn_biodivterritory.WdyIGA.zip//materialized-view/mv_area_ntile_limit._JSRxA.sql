CREATE MATERIALIZED VIEW mv_area_ntile_limit AS
WITH
    occtax AS (
        SELECT
            mv_territory_general_stats.id_area
          , mv_territory_general_stats.type_code
          , mv_territory_general_stats.count_occtax                          AS count
          , ntile(5) OVER (ORDER BY mv_territory_general_stats.count_occtax) AS ntile
        FROM gn_biodivterritory.mv_territory_general_stats
    )
  , taxa AS (
    SELECT
        mv_territory_general_stats.id_area
      , mv_territory_general_stats.type_code
      , mv_territory_general_stats.count_taxa                          AS count
      , ntile(5) OVER (ORDER BY mv_territory_general_stats.count_taxa) AS ntile
    FROM gn_biodivterritory.mv_territory_general_stats
)
  , threatened AS (
    SELECT
        mv_territory_general_stats.id_area
      , mv_territory_general_stats.type_code
      , mv_territory_general_stats.count_taxa                                AS count
      , ntile(5) OVER (ORDER BY mv_territory_general_stats.count_threatened) AS ntile
    FROM gn_biodivterritory.mv_territory_general_stats
)
  , observer AS (
    SELECT
        mv_territory_general_stats.id_area
      , mv_territory_general_stats.type_code
      , mv_territory_general_stats.count_observer                          AS count
      , ntile(5) OVER (ORDER BY mv_territory_general_stats.count_observer) AS ntile
    FROM gn_biodivterritory.mv_territory_general_stats
)
  , date AS (
    SELECT
        mv_territory_general_stats.id_area
      , mv_territory_general_stats.type_code
      , mv_territory_general_stats.count_date                          AS count
      , ntile(5) OVER (ORDER BY mv_territory_general_stats.count_date) AS ntile
    FROM gn_biodivterritory.mv_territory_general_stats
)
  , u AS (
    SELECT
        'occtax'::TEXT    AS type
      , min(occtax.count) AS min
      , max(occtax.count) AS max
      , occtax.ntile
    FROM occtax
    GROUP BY occtax.ntile
    UNION
    SELECT
        'taxa'::TEXT
      , min(taxa.count) AS min
      , max(taxa.count) AS max
      , taxa.ntile
    FROM taxa
    GROUP BY taxa.ntile
    UNION
    SELECT
        'threatened'::TEXT
      , min(taxa.count) AS min
      , max(taxa.count) AS max
      , taxa.ntile
    FROM taxa
    GROUP BY taxa.ntile
    UNION
    SELECT
        'observer'::TEXT
      , min(observer.count) AS min
      , max(observer.count) AS max
      , observer.ntile
    FROM observer
    GROUP BY observer.ntile
    UNION
    SELECT
        'date'::TEXT
      , min(date.count) AS min
      , max(date.count) AS max
      , date.ntile
    FROM date
    GROUP BY date.ntile
)
SELECT
    row_number() OVER () AS id
  , u.type
  , u.min
  , u.max
  , u.ntile
FROM u
ORDER BY
    u.type
  , u.ntile;

ALTER MATERIALIZED VIEW mv_area_ntile_limit OWNER TO geonature;

