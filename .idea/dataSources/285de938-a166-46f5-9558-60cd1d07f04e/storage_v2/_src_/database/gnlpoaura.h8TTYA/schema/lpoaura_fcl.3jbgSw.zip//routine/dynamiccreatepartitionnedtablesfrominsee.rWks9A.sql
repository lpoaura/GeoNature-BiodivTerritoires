CREATE FUNCTION dynamiccreatepartitionnedtablesfrominsee(insee text, _main_table text, _target_schema text DEFAULT NULL::text) RETURNS boolean
    LANGUAGE plpgsql
AS
$$
declare
  query_str text;

begin
  if _target_schema is null
  then -- if no target schema provided ...
    select c.relnamespace :: regnamespace :: text -- ... default to schema of input table
    from pg_class c
    where c.oid = _main_table
    into _target_schema
    ;
  end if
  ;

  raise notice '%', _target_schema
  ;

  query_str = format('create table %1$I."%2$s_%3$s" partition of %1$I.%2$I FOR VALUES IN (%3$L);' ||
                     'alter table %1$I."%2$s_%3$s" add primary key (id) ;' ||
                     'create index on %1$I."%2$s_%3$s" (fichier_source);' ||
                     'create index on %1$I."%2$s_%3$s" (id_sighting);' ||
                     'create index on %1$I."%2$s_%3$s" (name_species);' ||
                     'create index on %1$I."%2$s_%3$s" (latin_species);' ||
                     'create index on %1$I."%2$s_%3$s" (id_species);' ||
                     'create index on %1$I."%2$s_%3$s" (atlas_code);' ||
                     'create index on %1$I."%2$s_%3$s" using GIST (geom);' ||
                     'create index on %1$I."%2$s_%3$s" (equipe);' ||
                     'create index on %1$I."%2$s_%3$s" (statut_nidif);' ||
                     'create index on %1$I."%2$s_%3$s" (exp_exclus);'
  , _target_schema
  , _main_table
  , insee)
  ;

  execute query_str
  ;

  raise notice 'QUERY: %', query_str
  ;

  return true
  ;

end
$$;

ALTER FUNCTION dynamiccreatepartitionnedtablesfrominsee(TEXT, TEXT, TEXT) OWNER TO lpoaura_fcl;

