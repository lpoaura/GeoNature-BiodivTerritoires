CREATE FUNCTION st_summarystats(rastertable text, rastercolumn text, exclude_nodata_value boolean) RETURNS summarystats
    STABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_summarystats($1, $2, 1, $3, 1)
$$;

COMMENT ON FUNCTION st_summarystats(TEXT, TEXT, BOOLEAN) IS 'args: rastertable, rastercolumn, exclude_nodata_value - Returns summarystats consisting of count, sum, mean, stddev, min, max for a given raster band of a raster or raster coverage. Band 1 is assumed is no band is specified.';

ALTER FUNCTION st_summarystats(TEXT, TEXT, BOOLEAN) OWNER TO postgres;

