CREATE FUNCTION st_intersects(geom1 geometry, geom2 geometry) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Intersects($1,$2)
$$;

COMMENT ON FUNCTION st_intersects(GEOMETRY, GEOMETRY) IS 'args: geomA, geomB - Returns TRUE if the Geometries/Geography "spatially intersect in 2D" - (share any portion of space) and FALSE if they dont (they are Disjoint). For geography -- tolerance is 0.00001 meters (so any points that close are considered to intersect)';

ALTER FUNCTION st_intersects(GEOMETRY, GEOMETRY) OWNER TO postgres;

