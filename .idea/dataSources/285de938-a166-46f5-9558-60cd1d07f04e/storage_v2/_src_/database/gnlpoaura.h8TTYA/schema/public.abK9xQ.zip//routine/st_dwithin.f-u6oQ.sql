CREATE FUNCTION st_dwithin(geom1 geometry, geom2 geometry, double precision) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.&&) public.ST_Expand($2,$3) AND $2 OPERATOR(public.&&) public.ST_Expand($1,$3) AND public._ST_DWithin($1, $2, $3)
$$;

COMMENT ON FUNCTION st_dwithin(GEOMETRY, GEOMETRY, DOUBLE PRECISION) IS 'args: g1, g2, distance_of_srid - Returns true if the geometries are within the specified distance of one another. For geometry units are in those of spatial reference and for geography units are in meters and measurement is defaulted to use_spheroid=true (measure around spheroid), for faster check, use_spheroid=false to measure along sphere.';

ALTER FUNCTION st_dwithin(GEOMETRY, GEOMETRY, DOUBLE PRECISION) OWNER TO postgres;

