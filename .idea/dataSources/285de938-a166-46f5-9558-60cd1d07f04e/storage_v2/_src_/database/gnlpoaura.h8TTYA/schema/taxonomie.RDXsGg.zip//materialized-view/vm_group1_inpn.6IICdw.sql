CREATE MATERIALIZED VIEW vm_group1_inpn AS
SELECT DISTINCT tx.group1_inpn
FROM taxonomie.taxref tx;

ALTER MATERIALIZED VIEW vm_group1_inpn OWNER TO geonature;

CREATE UNIQUE INDEX i_unique_group1_inpn
    ON vm_group1_inpn(group1_inpn);

