CREATE FUNCTION fct_trg_update_synthese_validation_status() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
-- This trigger function update validation informations in corresponding row in synthese table
BEGIN
  UPDATE gn_synthese.synthese 
  SET id_nomenclature_valid_status = NEW.id_nomenclature_valid_status,
  validation_comment = NEW.validation_comment,
  validator = (SELECT nom_role || ' ' || prenom_role FROM utilisateurs.t_roles WHERE id_role = NEW.id_validator)::text
  WHERE unique_id_sinp = NEW.uuid_attached_row;
RETURN NEW;
END;
$$;

ALTER FUNCTION fct_trg_update_synthese_validation_status() OWNER TO geonature;

