CREATE FUNCTION st_rotatey(geometry, double precision) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_Affine($1,  cos($2), 0, sin($2),  0, 1, 0,  -sin($2), 0, cos($2), 0,  0, 0)
$$;

COMMENT ON FUNCTION st_rotatey(GEOMETRY, DOUBLE PRECISION) IS 'args: geomA, rotRadians - Rotate a geometry rotRadians about the Y axis.';

ALTER FUNCTION st_rotatey(GEOMETRY, DOUBLE PRECISION) OWNER TO postgres;

