CREATE FUNCTION role_is_group(myidrole integer) RETURNS boolean
    LANGUAGE plpgsql
AS
$$
DECLARE
	is_group boolean;
BEGIN
  SELECT INTO is_group groupe FROM utilisateurs.t_roles
	WHERE id_role = myidrole;
  RETURN is_group;
END;
$$;

ALTER FUNCTION role_is_group(INTEGER) OWNER TO geonature;

