CREATE FUNCTION default_id() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin
        if NEW.id is null or NEW.id = 0
        then
            NEW.id := NEXTVAL('zone_etude_pkey');
        end if;
        return NEW;
    end
$$;

ALTER FUNCTION default_id() OWNER TO lpoaura_fcl;

