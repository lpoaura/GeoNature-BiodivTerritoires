CREATE FUNCTION st_buffer(geography, double precision) RETURNS geography
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.geography(public.ST_Transform(public.ST_Buffer(public.ST_Transform(public.geometry($1), public._ST_BestSRID($1)), $2), 4326))
$$;

COMMENT ON FUNCTION st_buffer(GEOGRAPHY, DOUBLE PRECISION) IS 'args: g1, radius_of_buffer_in_meters - (T)Returns a geometry covering all points within a given distancefrom the input geometry.';

ALTER FUNCTION st_buffer(GEOGRAPHY, DOUBLE PRECISION) OWNER TO postgres;

