CREATE MATERIALIZED VIEW vm_synthese AS
SELECT
    s.id_synthese
  , s.id_source
  , s.id_dataset
  , s.id_nomenclature_obj_count
  , s.count_min
  , s.count_max
  , s.cd_nom
  , t.cd_ref
  , s.nom_cite
  , t.id_statut
  , t.id_rang
  , t.regne
  , t.phylum
  , t.classe
  , t.ordre
  , t.famille
  , t.sous_famille
  , t.group1_inpn
  , t.group2_inpn
  , t.lb_nom
  , t.nom_vern
  , t.url
  , s.altitude_min
  , s.altitude_max
  , s.date_min
  , s.date_max
FROM
    gn_synthese.synthese s
        JOIN taxonomie.taxref t ON s.cd_nom = t.cd_nom;

COMMENT ON MATERIALIZED VIEW vm_synthese IS 'Vue matérialisée listant tous les taxons pour lesquels des données ont été observées, ainsi que leur rang taxonomique';

ALTER MATERIALIZED VIEW vm_synthese OWNER TO geonature;

CREATE UNIQUE INDEX vm_synthese_id_synthese_idx
    ON vm_synthese(id_synthese);

CREATE INDEX vm_synthese_cd_ref_idx
    ON vm_synthese(cd_ref);

