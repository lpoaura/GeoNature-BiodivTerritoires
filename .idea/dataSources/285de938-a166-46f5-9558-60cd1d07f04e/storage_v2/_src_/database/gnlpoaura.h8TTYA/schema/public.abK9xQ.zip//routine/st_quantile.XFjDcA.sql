CREATE FUNCTION st_quantile(rast raster, nband integer, exclude_nodata_value boolean, quantile double precision) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT ( public._ST_quantile($1, $2, $3, 1, ARRAY[$4]::double precision[])).value
$$;

COMMENT ON FUNCTION st_quantile(RASTER, INTEGER, BOOLEAN, DOUBLE PRECISION) IS 'args: rast, nband, exclude_nodata_value, quantile - Compute quantiles for a raster or raster table coverage in the context of the sample or population. Thus, a value could be examined to be at the rasters 25%, 50%, 75% percentile.';

ALTER FUNCTION st_quantile(RASTER, INTEGER, BOOLEAN, DOUBLE PRECISION) OWNER TO postgres;

