CREATE FUNCTION st_mlinefromtext(text, integer) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT CASE
	WHEN public.geometrytype(public.ST_GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN public.ST_GeomFromText($1,$2)
	ELSE NULL END

$$;

COMMENT ON FUNCTION st_mlinefromtext(TEXT, INTEGER) IS 'args: WKT, srid - Return a specified ST_MultiLineString value from WKT representation.';

ALTER FUNCTION st_mlinefromtext(TEXT, INTEGER) OWNER TO postgres;

