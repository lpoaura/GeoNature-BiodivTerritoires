CREATE RULE lpoaura_fcl_layer_style_del AS
    ON DELETE TO layer_styles DO INSTEAD  DELETE FROM qgis_shared.layer_styles
  WHERE layer_styles.id = old.id;

