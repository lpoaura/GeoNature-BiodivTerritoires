CREATE FUNCTION cruved_for_user_in_module(myuser integer, mymodulecode character varying) RETURNS json
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
    -- the function return user's CRUVED in the requested module
-- warning: the function not return the parent CRUVED but only the module cruved - no heritage
-- USAGE : SELECT utilisateurs.cruved_for_user_in_module(requested_userid,requested_moduleid);
-- SAMPLE : SELECT utilisateurs.cruved_for_user_in_module(2,3);
DECLARE
 thecruved json;
BEGIN
    SELECT array_to_json(array_agg(row))
    INTO thecruved
    FROM (
  SELECT code_action AS action, max(value_filter::int) AS level
        FROM gn_permissions.v_users_permissions
        WHERE id_role = myuser AND module_code = mymodulecode AND code_filter_type = 'SCOPE'
        GROUP BY code_action) row;
    RETURN thecruved;
END;
$$;

ALTER FUNCTION cruved_for_user_in_module(INTEGER, VARCHAR) OWNER TO geonature;

