CREATE FUNCTION st_asbinary(geography, text) RETURNS bytea
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_AsBinary($1::public.geometry, $2);
$$;

COMMENT ON FUNCTION st_asbinary(GEOGRAPHY, TEXT) IS 'args: g1, NDR_or_XDR - Return the Well-Known Binary (WKB) representation of the geometry/geography without SRID meta data.';

ALTER FUNCTION st_asbinary(GEOGRAPHY, TEXT) OWNER TO postgres;

