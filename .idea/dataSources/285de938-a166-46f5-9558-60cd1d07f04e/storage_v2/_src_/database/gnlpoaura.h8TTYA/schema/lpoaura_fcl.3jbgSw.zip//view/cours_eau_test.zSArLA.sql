CREATE VIEW cours_eau_test(gid, code_hydro, classe, toponyme, geom) AS
SELECT
    ce.gid
  , ce.code_hydro
  , ce.classe
  , ce.toponyme
  , st_intersection(ce.geom, st_buffer(ze.geom, 5000::DOUBLE PRECISION)) AS geom
FROM
    zone_etude.zone_etude_bkp20190710 ze
  , occsol.sandre_cours_eau ce
WHERE
    ze.reference::TEXT = 'plui_ccasv'::TEXT AND
    st_intersects(ze.geom, ce.geom);

ALTER TABLE cours_eau_test
    OWNER TO lpoaura_fcl;

