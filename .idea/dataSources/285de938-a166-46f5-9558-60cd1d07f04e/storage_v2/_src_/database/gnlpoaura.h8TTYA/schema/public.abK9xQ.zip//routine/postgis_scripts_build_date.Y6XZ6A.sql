CREATE FUNCTION postgis_scripts_build_date() RETURNS text
    IMMUTABLE
    LANGUAGE SQL
AS
$$
SELECT '2019-03-12 05:59:37'::text AS version
$$;

COMMENT ON FUNCTION postgis_scripts_build_date() IS 'Returns build date of the PostGIS scripts.';

ALTER FUNCTION postgis_scripts_build_date() OWNER TO postgres;

