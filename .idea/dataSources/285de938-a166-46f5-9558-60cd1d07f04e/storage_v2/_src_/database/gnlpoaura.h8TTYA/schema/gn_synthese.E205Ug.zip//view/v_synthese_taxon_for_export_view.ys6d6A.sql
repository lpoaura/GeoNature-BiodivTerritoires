CREATE VIEW v_synthese_taxon_for_export_view
            (nom_valide, cd_ref, nom_vern, group1_inpn, group2_inpn, regne, phylum, classe, ordre, famille, id_rang) AS
SELECT DISTINCT
    ref.nom_valide
  , ref.cd_ref
  , ref.nom_vern
  , ref.group1_inpn
  , ref.group2_inpn
  , ref.regne
  , ref.phylum
  , ref.classe
  , ref.ordre
  , ref.famille
  , ref.id_rang
FROM
    gn_synthese.synthese s
        JOIN taxonomie.taxref t ON s.cd_nom = t.cd_nom
        JOIN taxonomie.taxref ref ON t.cd_ref = ref.cd_nom;

ALTER TABLE v_synthese_taxon_for_export_view
    OWNER TO geonature;

