CREATE FUNCTION st_transform(rast raster, srid integer, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125, scalex double precision DEFAULT 0, scaley double precision DEFAULT 0) RETURNS raster
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_gdalwarp($1, $3, $4, $2, $5, $6)
$$;

COMMENT ON FUNCTION st_transform(RASTER, INTEGER, TEXT, DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION) IS 'args: rast, srid, algorithm=NearestNeighbor, maxerr=0.125, scalex, scaley - Reprojects a raster in a known spatial reference system to another known spatial reference system using specified resampling algorithm. Options are NearestNeighbor, Bilinear, Cubic, CubicSpline, Lanczos defaulting to NearestNeighbor.';

ALTER FUNCTION st_transform(RASTER, INTEGER, TEXT, DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION) OWNER TO postgres;

