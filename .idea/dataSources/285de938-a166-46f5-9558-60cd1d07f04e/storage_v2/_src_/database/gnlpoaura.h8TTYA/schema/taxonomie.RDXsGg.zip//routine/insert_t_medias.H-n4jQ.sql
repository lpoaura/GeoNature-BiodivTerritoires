CREATE FUNCTION insert_t_medias() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
    trimtitre text;
BEGIN
    new.date_media = now();
    trimtitre = replace(new.titre, ' ', '');
    --new.url = new.chemin || new.cd_ref || '_' || trimtitre || '.jpg';
    RETURN NEW;
END;
$$;

ALTER FUNCTION insert_t_medias() OWNER TO geonature;

