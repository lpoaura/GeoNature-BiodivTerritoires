CREATE FUNCTION st_geomfromgeojson(json) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_GeomFromGeoJson($1::text)
$$;

COMMENT ON FUNCTION st_geomfromgeojson(JSON) IS 'args: geomjson - Takes as input a geojson representation of a geometry and outputs a PostGIS geometry object';

ALTER FUNCTION st_geomfromgeojson(JSON) OWNER TO postgres;

