CREATE FUNCTION st_multipolygonfromtext(text, integer) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_MPolyFromText($1, $2)
$$;

ALTER FUNCTION st_multipolygonfromtext(TEXT, INTEGER) OWNER TO postgres;

