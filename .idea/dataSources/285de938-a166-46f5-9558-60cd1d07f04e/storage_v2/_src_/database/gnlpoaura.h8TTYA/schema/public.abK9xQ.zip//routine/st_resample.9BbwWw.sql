CREATE FUNCTION st_resample(rast raster, ref raster, usescale boolean, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) RETURNS raster
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.st_resample($1, $2, $4, $5, $3)
$$;

COMMENT ON FUNCTION st_resample(RASTER, RASTER, BOOLEAN, TEXT, DOUBLE PRECISION) IS 'args: rast, ref, usescale, algorithm=NearestNeighbour, maxerr=0.125 - Resample a raster using a specified resampling algorithm, new dimensions, an arbitrary grid corner and a set of raster georeferencing attributes defined or borrowed from another raster.';

ALTER FUNCTION st_resample(RASTER, RASTER, BOOLEAN, TEXT, DOUBLE PRECISION) OWNER TO postgres;

