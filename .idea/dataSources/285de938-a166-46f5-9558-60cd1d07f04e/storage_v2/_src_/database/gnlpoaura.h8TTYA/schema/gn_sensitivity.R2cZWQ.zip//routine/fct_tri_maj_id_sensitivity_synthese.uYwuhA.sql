CREATE FUNCTION fct_tri_maj_id_sensitivity_synthese() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
BEGIN
    UPDATE gn_synthese.synthese SET id_nomenclature_sensitivity = NEW.id_nomenclature_sensitivity
    WHERE unique_id_sinp = NEW.uuid_attached_row;
    RETURN NEW;
END;
$$;

ALTER FUNCTION fct_tri_maj_id_sensitivity_synthese() OWNER TO geonature;

