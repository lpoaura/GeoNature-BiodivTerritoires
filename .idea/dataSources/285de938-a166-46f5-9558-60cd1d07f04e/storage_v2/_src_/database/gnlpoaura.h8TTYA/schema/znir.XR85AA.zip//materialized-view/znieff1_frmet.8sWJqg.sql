CREATE MATERIALIZED VIEW znieff1_frmet AS
SELECT
    znieff1.fid
  , znieff1.msgeometry
  , znieff1.gml_id
  , znieff1.id_mnhn
  , znieff1.nom
  , znieff1.url
FROM tmp.znieff1;

ALTER MATERIALIZED VIEW znieff1_frmet OWNER TO lpo07_fcl;

CREATE INDEX znieff1_frmet_id_mnhn_idx
    ON znieff1_frmet(id_mnhn);

