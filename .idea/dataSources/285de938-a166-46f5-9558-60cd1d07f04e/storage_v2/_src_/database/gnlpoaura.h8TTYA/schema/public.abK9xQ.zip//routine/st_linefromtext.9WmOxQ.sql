CREATE FUNCTION st_linefromtext(text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'LINESTRING'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END

$$;

COMMENT ON FUNCTION st_linefromtext(TEXT) IS 'args: WKT - Makes a Geometry from WKT representation with the given SRID. If SRID is not given, it defaults to 0.';

ALTER FUNCTION st_linefromtext(TEXT) OWNER TO postgres;

