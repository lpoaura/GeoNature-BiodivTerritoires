CREATE FUNCTION trg_fct_refresh_nomfrancais_mv_taxref_list_forautocomplete() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
BEGIN
    UPDATE taxonomie.vm_taxref_list_forautocomplete v
    SET search_name = concat(NEW.nom_francais, ' =  <i> ', t.nom_valide, '</i>', ' - [', t.id_rang, ' - ', t.cd_nom , ']')
    FROM taxonomie.taxref t
		WHERE v.cd_nom = NEW.cd_nom AND t.cd_nom = NEW.cd_nom;
    RETURN NEW;
END;
$$;

ALTER FUNCTION trg_fct_refresh_nomfrancais_mv_taxref_list_forautocomplete() OWNER TO geonature;

