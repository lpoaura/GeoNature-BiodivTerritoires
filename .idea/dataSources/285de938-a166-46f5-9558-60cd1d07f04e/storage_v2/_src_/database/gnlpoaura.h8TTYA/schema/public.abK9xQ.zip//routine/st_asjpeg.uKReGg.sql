CREATE FUNCTION st_asjpeg(rast raster, nband integer, quality integer) RETURNS bytea
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.st_asjpeg($1, ARRAY[$2], $3)
$$;

COMMENT ON FUNCTION st_asjpeg(RASTER, INTEGER, INTEGER) IS 'args: rast, nband, quality - Return the raster tile selected bands as a single Joint Photographic Exports Group (JPEG) image (byte array). If no band is specified and 1 or more than 3 bands, then only the first band is used. If only 3 bands then all 3 bands are used and mapped to RGB.';

ALTER FUNCTION st_asjpeg(RASTER, INTEGER, INTEGER) OWNER TO postgres;

