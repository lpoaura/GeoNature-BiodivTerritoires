CREATE MATERIALIZED VIEW vm_taxonomie AS
SELECT
    'Règne'::TEXT                                                 AS level
  , COALESCE(vm_synthese.regne, 'Not defined'::CHARACTER VARYING) AS name_taxon
FROM gn_dashboard.vm_synthese
GROUP BY
    vm_synthese.regne
UNION ALL
SELECT
    'Phylum'::TEXT                                                 AS level
  , COALESCE(vm_synthese.phylum, 'Not defined'::CHARACTER VARYING) AS name_taxon
FROM gn_dashboard.vm_synthese
GROUP BY
    vm_synthese.phylum
UNION ALL
SELECT
    'Classe'::TEXT                                                 AS level
  , COALESCE(vm_synthese.classe, 'Not defined'::CHARACTER VARYING) AS name_taxon
FROM gn_dashboard.vm_synthese
GROUP BY
    vm_synthese.classe
UNION ALL
SELECT
    'Ordre'::TEXT                                                 AS level
  , COALESCE(vm_synthese.ordre, 'Not defined'::CHARACTER VARYING) AS name_taxon
FROM gn_dashboard.vm_synthese
GROUP BY
    vm_synthese.ordre
UNION ALL
SELECT
    'Famille'::TEXT                                                 AS level
  , COALESCE(vm_synthese.famille, 'Not defined'::CHARACTER VARYING) AS name_taxon
FROM gn_dashboard.vm_synthese
GROUP BY
    vm_synthese.famille
UNION ALL
SELECT
    'Groupe INPN 1'::TEXT                                               AS level
  , COALESCE(vm_synthese.group1_inpn, 'Not defined'::CHARACTER VARYING) AS name_taxon
FROM gn_dashboard.vm_synthese
GROUP BY
    vm_synthese.group1_inpn
UNION ALL
SELECT
    'Groupe INPN 2'::TEXT                                               AS level
  , COALESCE(vm_synthese.group2_inpn, 'Not defined'::CHARACTER VARYING) AS name_taxon
FROM gn_dashboard.vm_synthese
GROUP BY
    vm_synthese.group2_inpn;

ALTER MATERIALIZED VIEW vm_taxonomie OWNER TO geonature;

CREATE UNIQUE INDEX vm_taxonomie_name_taxon_level_idx
    ON vm_taxonomie(name_taxon, level);

