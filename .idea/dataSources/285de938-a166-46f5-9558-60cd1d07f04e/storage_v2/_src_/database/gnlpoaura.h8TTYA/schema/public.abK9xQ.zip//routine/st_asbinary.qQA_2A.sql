CREATE FUNCTION st_asbinary(raster, outasin boolean DEFAULT false) RETURNS bytea
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_AsWKB($1, $2)
$$;

COMMENT ON FUNCTION st_asbinary(RASTER, BOOLEAN) IS 'args: rast, outasin=FALSE - Return the Well-Known Binary (WKB) representation of the raster.';

ALTER FUNCTION st_asbinary(RASTER, BOOLEAN) OWNER TO postgres;

