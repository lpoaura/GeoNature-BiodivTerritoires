CREATE FUNCTION unlockrows(text) RETURNS integer
    STRICT
    LANGUAGE plpgsql
AS
$$
DECLARE
	ret int;
BEGIN

	IF NOT LongTransactionsEnabled() THEN
		RAISE EXCEPTION 'Long transaction support disabled, use EnableLongTransaction() to enable.';
	END IF;

	EXECUTE 'DELETE FROM authorization_table where authid = ' ||
		quote_literal($1);

	GET DIAGNOSTICS ret = ROW_COUNT;

	RETURN ret;
END;
$$;

COMMENT ON FUNCTION unlockrows(TEXT) IS 'args: auth_token - Remove all locks held by specified authorization id. Returns the number of locks released.';

ALTER FUNCTION unlockrows(TEXT) OWNER TO postgres;

