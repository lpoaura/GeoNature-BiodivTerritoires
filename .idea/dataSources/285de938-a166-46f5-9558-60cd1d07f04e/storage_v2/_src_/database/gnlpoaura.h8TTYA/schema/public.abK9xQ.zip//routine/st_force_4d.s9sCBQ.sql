CREATE FUNCTION st_force_4d(geometry) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._postgis_deprecate('ST_Force_4d', 'ST_Force4D', '2.1.0');
    SELECT public.ST_Force4D($1);
$$;

ALTER FUNCTION st_force_4d(GEOMETRY) OWNER TO postgres;

