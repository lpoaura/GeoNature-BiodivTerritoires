CREATE FUNCTION check_is_inbibnoms(mycdnom integer) RETURNS boolean
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--fonction permettant de vérifier si un texte proposé correspond à un group2_inpn dans la table taxref
  BEGIN
    IF mycdnom IN(SELECT cd_nom FROM taxonomie.bib_noms) THEN
      RETURN true;
    ELSE
      RETURN false;
    END IF;
  END;
$$;

ALTER FUNCTION check_is_inbibnoms(INTEGER) OWNER TO geonature;

