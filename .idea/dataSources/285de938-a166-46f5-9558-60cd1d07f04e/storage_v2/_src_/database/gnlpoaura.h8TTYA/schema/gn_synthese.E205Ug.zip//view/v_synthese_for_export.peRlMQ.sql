CREATE VIEW v_synthese_for_export
            ( "idSynthese", "permId", "permIdGrp", "denbrMin", "denbrMax", "vTAXREF", "sampleNumb", "preuvNum"
            , "preuvNoNum", "altMin", "altMax", wkt, "dateDebut", "dateFin", validateur, observer, id_digitiser
            , detminer, "obsCtx", "obsDescr", meta_create_date, meta_update_date, "jddId", "jddCode"
            , id_acquisition_framework, "cdNom", "cdRef", "nomValide", "nomCite", x_centroid, y_centroid, lastact
            , geojson_4326, geojson_local, "ObjGeoTyp", "methGrp", "obsMeth", "obsTech", "ocStatutBio", "ocEtatBio"
            , "ocNat", "preuveOui", "difNivPrec", "ocStade", "ocSex", "objDenbr", "denbrTyp", "sensiNiv", "statObs"
            , "dEEFlou", "statSource", "typInfGeo", "ocMethDet")
AS
SELECT
    s.id_synthese                                    AS "idSynthese"
  , s.unique_id_sinp                                 AS "permId"
  , s.unique_id_sinp_grp                             AS "permIdGrp"
  , s.count_min                                      AS "denbrMin"
  , s.count_max                                      AS "denbrMax"
  , s.meta_v_taxref                                  AS "vTAXREF"
  , s.sample_number_proof                            AS "sampleNumb"
  , s.digital_proof                                  AS "preuvNum"
  , s.non_digital_proof                              AS "preuvNoNum"
  , s.altitude_min                                   AS "altMin"
  , s.altitude_max                                   AS "altMax"
  , st_astext(s.the_geom_4326)                       AS wkt
  , s.date_min                                       AS "dateDebut"
  , s.date_max                                       AS "dateFin"
  , s.validator                                      AS validateur
  , s.observers                                      AS observer
  , s.id_digitiser
  , s.determiner                                     AS detminer
  , s.comment_context                                AS "obsCtx"
  , s.comment_description                            AS "obsDescr"
  , s.meta_create_date
  , s.meta_update_date
  , d.id_dataset                                     AS "jddId"
  , d.dataset_name                                   AS "jddCode"
  , d.id_acquisition_framework
  , t.cd_nom                                         AS "cdNom"
  , t.cd_ref                                         AS "cdRef"
  , t.nom_valide                                     AS "nomValide"
  , s.nom_cite                                       AS "nomCite"
  , st_x(st_transform(s.the_geom_point, 2154))       AS x_centroid
  , st_y(st_transform(s.the_geom_point, 2154))       AS y_centroid
  , COALESCE(s.meta_update_date, s.meta_create_date) AS lastact
  , st_asgeojson(s.the_geom_4326)                    AS geojson_4326
  , st_asgeojson(s.the_geom_local)                   AS geojson_local
  , n1.label_default                                 AS "ObjGeoTyp"
  , n2.label_default                                 AS "methGrp"
  , n3.label_default                                 AS "obsMeth"
  , n4.label_default                                 AS "obsTech"
  , n5.label_default                                 AS "ocStatutBio"
  , n6.label_default                                 AS "ocEtatBio"
  , n7.label_default                                 AS "ocNat"
  , n8.label_default                                 AS "preuveOui"
  , n9.label_default                                 AS "difNivPrec"
  , n10.label_default                                AS "ocStade"
  , n11.label_default                                AS "ocSex"
  , n12.label_default                                AS "objDenbr"
  , n13.label_default                                AS "denbrTyp"
  , n14.label_default                                AS "sensiNiv"
  , n15.label_default                                AS "statObs"
  , n16.label_default                                AS "dEEFlou"
  , n17.label_default                                AS "statSource"
  , n18.label_default                                AS "typInfGeo"
  , n19.label_default                                AS "ocMethDet"
FROM
    gn_synthese.synthese s
        JOIN taxonomie.taxref t ON t.cd_nom = s.cd_nom
        JOIN gn_meta.t_datasets d ON d.id_dataset = s.id_dataset
        JOIN gn_synthese.t_sources sources ON sources.id_source = s.id_source
        LEFT JOIN ref_nomenclatures.t_nomenclatures n1 ON s.id_nomenclature_geo_object_nature = n1.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n2 ON s.id_nomenclature_grp_typ = n2.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n3 ON s.id_nomenclature_obs_meth = n3.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n4 ON s.id_nomenclature_obs_technique = n4.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n5 ON s.id_nomenclature_bio_status = n5.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n6 ON s.id_nomenclature_bio_condition = n6.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n7 ON s.id_nomenclature_naturalness = n7.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n8 ON s.id_nomenclature_exist_proof = n8.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n9 ON s.id_nomenclature_diffusion_level = n9.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n10 ON s.id_nomenclature_life_stage = n10.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n11 ON s.id_nomenclature_sex = n11.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n12 ON s.id_nomenclature_obj_count = n12.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n13 ON s.id_nomenclature_type_count = n13.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n14 ON s.id_nomenclature_sensitivity = n14.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n15 ON s.id_nomenclature_observation_status = n15.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n16 ON s.id_nomenclature_blurring = n16.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n17 ON s.id_nomenclature_source_status = n17.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n18 ON s.id_nomenclature_info_geo_type = n18.id_nomenclature
        LEFT JOIN ref_nomenclatures.t_nomenclatures n19 ON s.id_nomenclature_determination_method = n19.id_nomenclature;

ALTER TABLE v_synthese_for_export
    OWNER TO geonature;

