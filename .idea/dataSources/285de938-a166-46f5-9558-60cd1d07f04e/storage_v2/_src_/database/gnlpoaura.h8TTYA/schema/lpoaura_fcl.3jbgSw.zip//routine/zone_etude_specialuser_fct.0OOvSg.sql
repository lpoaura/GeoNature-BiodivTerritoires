CREATE FUNCTION zone_etude_specialuser_fct() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
BEGIN
  IF current_user LIKE '%\_%'
  THEN NEW.creator = split_part( CURRENT_USER, '_', 1);
    RETURN NEW;
  ELSIF CURRENT_USER NOT LIKE '%\_%'
    THEN NEW.creator = split_part( CURRENT_USER, '_', 1);
      RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$;

ALTER FUNCTION zone_etude_specialuser_fct() OWNER TO lpoaura_fcl;

