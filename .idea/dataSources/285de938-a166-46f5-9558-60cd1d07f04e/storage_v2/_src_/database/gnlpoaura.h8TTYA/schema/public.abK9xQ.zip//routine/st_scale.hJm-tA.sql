CREATE FUNCTION st_scale(geometry, double precision, double precision, double precision) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_Scale($1, public.ST_MakePoint($2, $3, $4))
$$;

COMMENT ON FUNCTION st_scale(GEOMETRY, DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION) IS 'args: geomA, XFactor, YFactor, ZFactor - Scale a geometry by given factors.';

ALTER FUNCTION st_scale(GEOMETRY, DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION) OWNER TO postgres;

