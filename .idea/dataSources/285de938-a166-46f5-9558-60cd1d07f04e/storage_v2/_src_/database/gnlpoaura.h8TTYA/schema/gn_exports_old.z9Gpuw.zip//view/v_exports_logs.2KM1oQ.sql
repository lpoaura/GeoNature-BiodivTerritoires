CREATE VIEW v_exports_logs(utilisateur, label, format, start_time, end_time, status, log) AS
SELECT
    (r.nom_role::TEXT || ' '::TEXT) || r.prenom_role::TEXT AS utilisateur
  , e.label
  , l.format
  , l.start_time
  , l.end_time
  , l.status
  , l.log
FROM
    gn_exports_old.t_exports_logs l
        JOIN utilisateurs.t_roles r ON r.id_role = l.id_role
        JOIN gn_exports_old.t_exports e ON e.id = l.id_export
ORDER BY
    l.start_time;

ALTER TABLE v_exports_logs
    OWNER TO geonature;

