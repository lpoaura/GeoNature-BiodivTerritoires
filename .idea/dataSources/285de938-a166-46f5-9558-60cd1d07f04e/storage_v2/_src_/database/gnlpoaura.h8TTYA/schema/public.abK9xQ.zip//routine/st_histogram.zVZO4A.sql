CREATE FUNCTION st_histogram(rast raster, nband integer, bins integer, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) RETURNS SETOF record
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT min, max, count, percent FROM public._ST_histogram($1, $2, TRUE, 1, $3, $4, $5)
$$;

COMMENT ON FUNCTION st_histogram(RASTER, INTEGER, INTEGER, DOUBLE PRECISION[], BOOLEAN, OUT DOUBLE PRECISION, OUT DOUBLE PRECISION, OUT BIGINT, OUT DOUBLE PRECISION) IS 'args: rast, nband, bins, width=NULL, right=false - Returns a set of record summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

ALTER FUNCTION st_histogram(RASTER, INTEGER, INTEGER, DOUBLE PRECISION[], BOOLEAN, OUT DOUBLE PRECISION, OUT DOUBLE PRECISION, OUT BIGINT, OUT DOUBLE PRECISION) OWNER TO postgres;

