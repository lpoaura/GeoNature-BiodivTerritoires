CREATE FUNCTION st_asraster(geom geometry, ref raster, pixeltype text, value double precision DEFAULT 1, nodataval double precision DEFAULT 0, touched boolean DEFAULT false) RETURNS raster
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT  public.ST_AsRaster($1, $2, ARRAY[$3]::text[], ARRAY[$4]::double precision[], ARRAY[$5]::double precision[], $6)
$$;

COMMENT ON FUNCTION st_asraster(GEOMETRY, RASTER, TEXT, DOUBLE PRECISION, DOUBLE PRECISION, BOOLEAN) IS 'args: geom, ref, pixeltype, value=1, nodataval=0, touched=false - Converts a PostGIS geometry to a PostGIS raster.';

ALTER FUNCTION st_asraster(GEOMETRY, RASTER, TEXT, DOUBLE PRECISION, DOUBLE PRECISION, BOOLEAN) OWNER TO postgres;

