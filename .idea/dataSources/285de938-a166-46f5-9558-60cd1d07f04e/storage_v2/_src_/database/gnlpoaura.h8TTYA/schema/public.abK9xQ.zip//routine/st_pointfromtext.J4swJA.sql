CREATE FUNCTION st_pointfromtext(text, integer) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1, $2)) = 'POINT'
	THEN public.ST_GeomFromText($1, $2)
	ELSE NULL END

$$;

COMMENT ON FUNCTION st_pointfromtext(TEXT, INTEGER) IS 'args: WKT, srid - Makes a point Geometry from WKT with the given SRID. If SRID is not given, it defaults to unknown.';

ALTER FUNCTION st_pointfromtext(TEXT, INTEGER) OWNER TO postgres;

