CREATE FUNCTION get_uuid_field_name(myschema text, mytable text) RETURNS text
    LANGUAGE plpgsql
AS
$$
DECLARE
	theuuidfieldname character varying(50);
BEGIN
--Retrouver dans gn_commons.bib_tables_location le nom du champs UUID de la table passée en paramètre
  SELECT INTO theuuidfieldname uuid_field_name FROM gn_commons.bib_tables_location
	WHERE "schema_name" = myschema AND "table_name" = mytable;
  RETURN theuuidfieldname;
END;
$$;

ALTER FUNCTION get_uuid_field_name(TEXT, TEXT) OWNER TO geonature;

