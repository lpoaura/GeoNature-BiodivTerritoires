CREATE FUNCTION default_reference() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
begin
        if NEW.reference is null or NEW.reference = ''
        then
            NEW.reference := current_user || extract(epoch from now())::int::text;
        end if;
        return NEW;
    end
$$;

ALTER FUNCTION default_reference() OWNER TO lpoaura_fcl;

