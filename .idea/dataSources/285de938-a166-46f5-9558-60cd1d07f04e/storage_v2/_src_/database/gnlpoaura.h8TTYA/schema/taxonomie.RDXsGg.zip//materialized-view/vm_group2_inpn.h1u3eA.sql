CREATE MATERIALIZED VIEW vm_group2_inpn AS
SELECT DISTINCT tx.group2_inpn
FROM taxonomie.taxref tx;

ALTER MATERIALIZED VIEW vm_group2_inpn OWNER TO geonature;

CREATE UNIQUE INDEX i_unique_group2_inpn
    ON vm_group2_inpn(group2_inpn);

