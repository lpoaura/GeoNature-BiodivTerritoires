CREATE FUNCTION st_mlinefromtext(text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'MULTILINESTRING'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END

$$;

COMMENT ON FUNCTION st_mlinefromtext(TEXT) IS 'args: WKT - Return a specified ST_MultiLineString value from WKT representation.';

ALTER FUNCTION st_mlinefromtext(TEXT) OWNER TO postgres;

