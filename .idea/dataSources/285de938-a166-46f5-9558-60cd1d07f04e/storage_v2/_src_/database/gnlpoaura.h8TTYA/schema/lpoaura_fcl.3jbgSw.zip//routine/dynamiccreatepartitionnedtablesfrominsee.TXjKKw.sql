CREATE FUNCTION dynamiccreatepartitionnedtablesfrominsee(insee text) RETURNS boolean
    LANGUAGE plpgsql
AS
$$
declare
  query_str text;

begin

  raise notice 'INSEE %', insee
  ;

  query_str = format('create table test.observations_%1%I partition of test.observations FOR VALUES IN (''%1%I'');' ||
                     'alter table test.observations_%1%I add primary key (id) ;' ||
                     'create index on test.observations_%1%I (fichier_source);' ||
                     'create index on test.observations_%1%I (id_sighting);' ||
                     'create index on test.observations_%1%I (name_species);' ||
                     'create index on test.observations_%1%I (latin_species);' ||
                     'create index on test.observations_%1%I (id_species);' ||
                     'create index on test.observations_%1%I (atlas_code);' ||
                     'create index on test.observations_%1%I using GIST (geom);' ||
                     'create index on test.observations_%1%I (equipe);' ||
                     'create index on test.observations_%1%I (statut_nidif);' ||
                     'create index on test.observations_%1%I (exp_exclus);'
  , insee)
  ;

  execute query_str
  ;

  raise notice 'QUERY: %', query_str
  ;

  return true
  ;

end
$$;

ALTER FUNCTION dynamiccreatepartitionnedtablesfrominsee(TEXT) OWNER TO lpoaura_fcl;

