CREATE FUNCTION fct_tri_manage_area_synth_and_taxon() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
    the_id_areas int[];
BEGIN 
   -- on récupère tous les aires intersectées par l'id_synthese concerné
    SELECT array_agg(id_area) INTO the_id_areas
    FROM gn_synthese.cor_area_synthese
    WHERE id_synthese = OLD.id_synthese;
    -- DELETE AND INSERT sur cor_area_taxon: evite de faire un count sur nb_obs
    DELETE FROM gn_synthese.cor_area_taxon WHERE cd_nom = OLD.cd_nom AND id_area = ANY (the_id_areas);
    -- on réinsert dans cor_area_synthese en recalculant les max, nb_obs
    INSERT INTO gn_synthese.cor_area_taxon (cd_nom, nb_obs, id_area, last_date)
    SELECT s.cd_nom, count(s.id_synthese), cor.id_area,  max(s.date_min)
    FROM gn_synthese.cor_area_synthese cor
    JOIN gn_synthese.synthese s ON s.id_synthese = cor.id_synthese
    -- on ne prend pas l'OLD.synthese car c'est un trigger BEFORE DELETE
    WHERE id_area = ANY (the_id_areas) AND s.cd_nom = OLD.cd_nom AND s.id_synthese != OLD.id_synthese
    GROUP BY cor.id_area, s.cd_nom;
    -- suppression dans cor_area_synthese si tg_op = DELETE
    DELETE FROM gn_synthese.cor_area_synthese WHERE id_synthese = OLD.id_synthese;
    RETURN OLD;
END;
$$;

ALTER FUNCTION fct_tri_manage_area_synth_and_taxon() OWNER TO geonature;

