CREATE FUNCTION postgis_scripts_installed() RETURNS text
    IMMUTABLE
    LANGUAGE SQL
AS
$$
SELECT '2.5.2'::text || ' r' || 17328::text AS version
$$;

COMMENT ON FUNCTION postgis_scripts_installed() IS 'Returns version of the postgis scripts installed in this database.';

ALTER FUNCTION postgis_scripts_installed() OWNER TO postgres;

