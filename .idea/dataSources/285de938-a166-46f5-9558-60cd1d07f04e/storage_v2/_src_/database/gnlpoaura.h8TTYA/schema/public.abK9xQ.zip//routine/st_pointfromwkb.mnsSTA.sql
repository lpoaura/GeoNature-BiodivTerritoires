CREATE FUNCTION st_pointfromwkb(bytea) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'POINT'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END

$$;

ALTER FUNCTION st_pointfromwkb(BYTEA) OWNER TO postgres;

