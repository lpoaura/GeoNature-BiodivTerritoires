CREATE FUNCTION st_aspng(rast raster, nband integer, compression integer) RETURNS bytea
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.st_aspng($1, ARRAY[$2], $3)
$$;

COMMENT ON FUNCTION st_aspng(RASTER, INTEGER, INTEGER) IS 'args: rast, nband, compression - Return the raster tile selected bands as a single portable network graphics (PNG) image (byte array). If 1, 3, or 4 bands in raster and no bands are specified, then all bands are used. If more 2 or more than 4 bands and no bands specified, then only band 1 is used. Bands are mapped to RGB or RGBA space.';

ALTER FUNCTION st_aspng(RASTER, INTEGER, INTEGER) OWNER TO postgres;

