CREATE FUNCTION zone_etude_area_fct() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
BEGIN
  NEW.surf_ha = st_area(NEW.geom)/10000;
    RETURN NEW;
END;
$$;

ALTER FUNCTION zone_etude_area_fct() OWNER TO lpoaura_fcl;

