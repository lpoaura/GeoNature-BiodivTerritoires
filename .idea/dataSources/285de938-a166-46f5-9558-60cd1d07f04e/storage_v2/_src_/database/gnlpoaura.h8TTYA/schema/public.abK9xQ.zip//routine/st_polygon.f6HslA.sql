CREATE FUNCTION st_polygon(geometry, integer) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_SetSRID(public.ST_MakePolygon($1), $2)

$$;

COMMENT ON FUNCTION st_polygon(GEOMETRY, INTEGER) IS 'args: aLineString, srid - Returns a polygon built from the specified linestring and SRID.';

ALTER FUNCTION st_polygon(GEOMETRY, INTEGER) OWNER TO postgres;

