CREATE VIEW vn
            ( id, id_sighting, id_species, name_species, latin_species, taxonomy_name, family_name, date, time_start
            , time_stop, full_form, timing, id_place, place, municipality, county, insee, precision, x_l93, y_l93
            , altitude, estimation_code, total_count, detail, detail_array, atlas_code, statut_nidif, hidden, behaviour
            , behaviour_array, observer_id, surname, name, pers_moral_court, tra_surname, tra_name, form_id
            , tra_full_name, second_hand, comment, private_comment, insert_date, update_date, project_code
            , protocol_name, has_death_info, fichier_source, equipe, exp_exclus, geom)
AS
SELECT
    vn.id
  , vn.id_sighting
  , vn.id_species
  , vn.name_species
  , vn.latin_species
  , vn.taxonomy_name
  , vn.family_name
  , vn.date
  , vn.time_start
  , vn.time_stop
  , vn.full_form
  , vn.timing
  , vn.id_place
  , vn.place
  , vn.municipality
  , vn.county
  , vn.insee
  , vn."precision"
  , vn.x_l93
  , vn.y_l93
  , vn.altitude
  , vn.estimation_code
  , vn.total_count
  , vn.detail
  , vn.detail_array
  , vn.atlas_code
  , vn.statut_nidif
  , vn.hidden
  , vn.behaviour
  , vn.behaviour_array
  , vn.observer_id
  , vn.surname
  , vn.name
  , vn.pers_moral_court
  , vn.tra_surname
  , vn.tra_name
  , vn.form_id
  , vn.tra_full_name
  , vn.second_hand
  , vn.comment
  , vn.private_comment
  , vn.insert_date
  , vn.update_date
  , vn.project_code
  , vn.protocol_name
  , vn.has_death_info
  , vn.fichier_source
  , vn.equipe
  , vn.exp_exclus
  , vn.geom
FROM data.vn;

ALTER TABLE vn
    OWNER TO lpoaura_fcl;

