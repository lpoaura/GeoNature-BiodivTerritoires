CREATE FUNCTION st_snaptogrid(geometry, double precision) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_SnapToGrid($1, 0, 0, $2, $2)
$$;

COMMENT ON FUNCTION st_snaptogrid(GEOMETRY, DOUBLE PRECISION) IS 'args: geomA, size - Snap all points of the input geometry to a regular grid.';

ALTER FUNCTION st_snaptogrid(GEOMETRY, DOUBLE PRECISION) OWNER TO postgres;

