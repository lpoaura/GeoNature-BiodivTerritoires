CREATE MATERIALIZED VIEW znieff2_aura AS
SELECT
    znieff2_aura.fid
  , znieff2_aura.geom
  , znieff2_aura.gml_id
  , znieff2_aura.gid
  , znieff2_aura.id_org
  , znieff2_aura.id_mnhn
  , znieff2_aura.nom
  , znieff2_aura.url_pdf
  , znieff2_aura.lien_mnhn
  , znieff2_aura.surface_si
  , znieff2_aura.generation
FROM tmp.znieff2_aura;

ALTER MATERIALIZED VIEW znieff2_aura OWNER TO lpo07_fcl;

CREATE UNIQUE INDEX znieff2_aura_fid_idx
    ON znieff2_aura(fid);

CREATE INDEX znieff2_aura_geom_idx
    ON znieff2_aura(geom);

CREATE INDEX znieff2_aura_id_mnhn_idx
    ON znieff2_aura(id_mnhn);

