CREATE FUNCTION st_setvalues(rast raster, nband integer, x integer, y integer, newvalueset double precision[], nosetvalue double precision, keepnodata boolean DEFAULT false) RETURNS raster
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_setvalues($1, $2, $3, $4, $5, NULL, TRUE, $6, $7)
$$;

COMMENT ON FUNCTION st_setvalues(RASTER, INTEGER, INTEGER, INTEGER, DOUBLE PRECISION[], DOUBLE PRECISION, BOOLEAN) IS 'args: rast, nband, columnx, rowy, newvalueset, nosetvalue, keepnodata=FALSE - Returns modified raster resulting from setting the values of a given band.';

ALTER FUNCTION st_setvalues(RASTER, INTEGER, INTEGER, INTEGER, DOUBLE PRECISION[], DOUBLE PRECISION, BOOLEAN) OWNER TO postgres;

