CREATE MATERIALIZED VIEW vm_synthese_frameworks AS
SELECT DISTINCT
    af.acquisition_framework_name
  , date_part('year'::TEXT, s.date_min) AS year
  , count(*)                            AS nb_obs
FROM
    gn_synthese.synthese s
        JOIN gn_meta.t_datasets d ON d.id_dataset = s.id_dataset
        JOIN gn_meta.t_acquisition_frameworks af ON af.id_acquisition_framework = d.id_acquisition_framework
GROUP BY
    af.acquisition_framework_name
  , (date_part('year'::TEXT, s.date_min))
ORDER BY
    af.acquisition_framework_name
  , (date_part('year'::TEXT, s.date_min));

COMMENT ON MATERIALIZED VIEW vm_synthese_frameworks IS 'Vue matérialisée calculant le nombre d''observations par cadre d''acquisition par année';

ALTER MATERIALIZED VIEW vm_synthese_frameworks OWNER TO geonature;

CREATE UNIQUE INDEX vm_synthese_frameworks_acquisition_framework_name_year_idx
    ON vm_synthese_frameworks(acquisition_framework_name, year);

