CREATE FUNCTION modify_date_insert() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
BEGIN
    NEW.date_insert := now();
    NEW.date_update := now();
    RETURN NEW;
END;
$$;

ALTER FUNCTION modify_date_insert() OWNER TO geonature;

