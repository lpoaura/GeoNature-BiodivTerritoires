CREATE RULE lpoaura_fcl_layer_style_upd AS
    ON UPDATE TO layer_styles DO INSTEAD  UPDATE qgis_shared.layer_styles SET useasdefault = new.useasdefault, styleqml = new.styleqml, stylesld = new.stylesld, description = new.description, owner = new.owner
  WHERE layer_styles.f_table_catalog::text = old.f_table_catalog::text AND layer_styles.f_table_schema::text = old.f_table_schema::text AND layer_styles.f_table_name::text = old.f_table_name::text AND layer_styles.f_geometry_column::text = old.f_geometry_column::text AND layer_styles.stylename::text = old.stylename::text;

