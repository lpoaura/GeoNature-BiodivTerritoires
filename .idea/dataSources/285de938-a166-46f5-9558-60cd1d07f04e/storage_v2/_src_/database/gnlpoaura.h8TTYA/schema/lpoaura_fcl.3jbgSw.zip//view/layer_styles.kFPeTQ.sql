CREATE VIEW layer_styles
            ( id, f_table_catalog, f_table_schema, f_table_name, f_geometry_column, stylename, styleqml, stylesld
            , useasdefault, description, owner, ui, update_time)
AS
SELECT
    layer_styles.id
  , layer_styles.f_table_catalog
  , layer_styles.f_table_schema
  , layer_styles.f_table_name
  , layer_styles.f_geometry_column
  , layer_styles.stylename
  , layer_styles.styleqml
  , layer_styles.stylesld
  , layer_styles.useasdefault
  , layer_styles.description
  , layer_styles.owner
  , layer_styles.ui
  , layer_styles.update_time
FROM qgis_shared.layer_styles;

ALTER TABLE layer_styles
    OWNER TO geonature;

