CREATE FUNCTION get_id_area_type(mytype character varying) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--Function which return the id_type_area from the type_code of an area type
DECLARE theidtype character varying;
  BEGIN
SELECT INTO theidtype id_type FROM ref_geo.bib_areas_types WHERE type_code = mytype;
return theidtype;
  END;
$$;

ALTER FUNCTION get_id_area_type(VARCHAR) OWNER TO geonature;

