CREATE FUNCTION _st_bestsrid(geography) RETURNS integer
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_BestSRID($1,$1)
$$;

ALTER FUNCTION _st_bestsrid(GEOGRAPHY) OWNER TO postgres;

