CREATE FUNCTION postgis_raster_scripts_installed() RETURNS text
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT '2.5.2'::text || ' r' || 17328::text AS version
$$;

ALTER FUNCTION postgis_raster_scripts_installed() OWNER TO postgres;

