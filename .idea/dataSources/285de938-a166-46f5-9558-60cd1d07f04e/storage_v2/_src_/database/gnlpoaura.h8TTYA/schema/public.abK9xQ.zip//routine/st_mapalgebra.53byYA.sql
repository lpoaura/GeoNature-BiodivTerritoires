CREATE FUNCTION st_mapalgebra(rast1 raster, rast2 raster, expression text, pixeltype text DEFAULT NULL::text, extenttype text DEFAULT 'INTERSECTION'::text, nodata1expr text DEFAULT NULL::text, nodata2expr text DEFAULT NULL::text, nodatanodataval double precision DEFAULT NULL::double precision) RETURNS raster
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_mapalgebra($1, 1, $2, 1, $3, $4, $5, $6, $7, $8)
$$;

ALTER FUNCTION st_mapalgebra(RASTER, RASTER, TEXT, TEXT, TEXT, TEXT, TEXT, DOUBLE PRECISION) OWNER TO postgres;

