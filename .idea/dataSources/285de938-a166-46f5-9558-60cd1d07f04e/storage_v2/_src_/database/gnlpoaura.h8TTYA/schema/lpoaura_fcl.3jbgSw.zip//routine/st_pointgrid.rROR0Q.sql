CREATE FUNCTION st_pointgrid(geometry, integer, integer) RETURNS geometry
    LANGUAGE SQL
AS
$$
SELECT ST_Collect(st_setsrid(ST_POINT(x,y),$3)) FROM
  generate_series(floor(st_xmin($1))::int, ceiling(st_xmax($1))::int,$2) as x
  ,generate_series(floor(st_ymin($1))::int, ceiling(st_ymax($1))::int,$2) as y
where st_intersects($1,st_setsrid(ST_POINT(x,y),$3))
$$;

ALTER FUNCTION st_pointgrid(GEOMETRY, INTEGER, INTEGER) OWNER TO postgres;

