CREATE FUNCTION st_rastertoworldcoord(rast raster, columnx integer, rowy integer, OUT longitude double precision, OUT latitude double precision) RETURNS record
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT longitude, latitude FROM public._ST_rastertoworldcoord($1, $2, $3)
$$;

COMMENT ON FUNCTION st_rastertoworldcoord(RASTER, INTEGER, INTEGER, OUT DOUBLE PRECISION, OUT DOUBLE PRECISION) IS 'args: rast, xcolumn, yrow - Returns the rasters upper left corner as geometric X and Y (longitude and latitude) given a column and row. Column and row starts at 1.';

ALTER FUNCTION st_rastertoworldcoord(RASTER, INTEGER, INTEGER, OUT DOUBLE PRECISION, OUT DOUBLE PRECISION) OWNER TO postgres;

