CREATE FUNCTION st_asjpeg(rast raster, nband integer, options text[] DEFAULT NULL::text[]) RETURNS bytea
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.st_asjpeg(st_band($1, $2), $3)
$$;

COMMENT ON FUNCTION st_asjpeg(RASTER, INTEGER, TEXT[]) IS 'args: rast, nband, options=NULL - Return the raster tile selected bands as a single Joint Photographic Exports Group (JPEG) image (byte array). If no band is specified and 1 or more than 3 bands, then only the first band is used. If only 3 bands then all 3 bands are used and mapped to RGB.';

ALTER FUNCTION st_asjpeg(RASTER, INTEGER, TEXT[]) OWNER TO postgres;

