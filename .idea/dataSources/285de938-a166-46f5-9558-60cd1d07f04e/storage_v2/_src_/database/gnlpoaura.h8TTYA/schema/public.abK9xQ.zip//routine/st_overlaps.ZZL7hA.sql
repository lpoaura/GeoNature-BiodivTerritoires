CREATE FUNCTION st_overlaps(geom1 geometry, geom2 geometry) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Overlaps($1,$2)
$$;

COMMENT ON FUNCTION st_overlaps(GEOMETRY, GEOMETRY) IS 'args: A, B - Returns TRUE if the Geometries share space, are of the same dimension, but are not completely contained by each other.';

ALTER FUNCTION st_overlaps(GEOMETRY, GEOMETRY) OWNER TO postgres;

