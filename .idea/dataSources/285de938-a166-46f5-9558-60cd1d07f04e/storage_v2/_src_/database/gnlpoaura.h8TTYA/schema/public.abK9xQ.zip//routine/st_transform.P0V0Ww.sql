CREATE FUNCTION st_transform(geom geometry, from_proj text, to_proj text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.postgis_transform_geometry($1, $2, $3, 0)
$$;

COMMENT ON FUNCTION st_transform(GEOMETRY, TEXT, TEXT) IS 'args: geom, from_proj, to_proj - Return a new geometry with its coordinates transformed to a different spatial reference.';

ALTER FUNCTION st_transform(GEOMETRY, TEXT, TEXT) OWNER TO postgres;

