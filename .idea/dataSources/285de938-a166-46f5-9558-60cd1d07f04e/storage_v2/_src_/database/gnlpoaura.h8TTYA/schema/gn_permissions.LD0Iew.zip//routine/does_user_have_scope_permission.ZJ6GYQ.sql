CREATE FUNCTION does_user_have_scope_permission(myuser integer, mycodemodule character varying, myactioncode character varying, myscope integer) RETURNS boolean
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
    -- the function say if the given user can do the requested action in the requested module with its scope level
-- warning: NO heritage between parent and child module
-- USAGE : SELECT gn_persmissions.does_user_have_scope_permission(requested_userid,requested_actionid,requested_module_code,requested_scope);
-- SAMPLE : SELECT gn_permissions.does_user_have_scope_permission(2,'OCCTAX','R',3);
BEGIN
    IF myactioncode IN (
  SELECT code_action
    FROM gn_permissions.v_users_permissions
    WHERE id_role = myuser AND module_code = mycodemodule AND code_action = myactioncode AND value_filter::int >= myscope AND code_filter_type = 'SCOPE') THEN
    RETURN true;
END
IF;
 RETURN false;
END;
$$;

ALTER FUNCTION does_user_have_scope_permission(INTEGER, VARCHAR, VARCHAR, INTEGER) OWNER TO geonature;

