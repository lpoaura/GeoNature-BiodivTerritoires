CREATE FUNCTION slugify(texte character varying) RETURNS character varying
    LANGUAGE plpgsql
AS
$$
DECLARE
  result VARCHAR;
BEGIN
  result := replace(texte, 'æ', 'ae');
  result := replace(result, 'œ', 'oe');
  result := replace(result, '€', 'euros');
  result := replace(result, '$', 'dollars');
  result := replace(result, '£', 'pound');
  result := replace(result, '¥', 'yen');
  result := regexp_replace(translate(replace(lower(result), ' ', '-'),
                                     'áàâãäåāăąÁÂÃÄÅĀĂĄèééêëēĕėęěĒĔĖĘĚìíîïìĩīĭÌÍÎÏÌĨĪĬóôõöōŏőÒÓÔÕÖŌŎŐùúûüũūŭůÙÚÛÜŨŪŬŮçÇÿ&,.ñÑ',
                                     'aaaaaaaaaaaaaaaaaeeeeeeeeeeeeeeeiiiiiiiiiiiiiiiiooooooooooooooouuuuuuuuuuuuuuuuccy_--nn'),
                           E'[^\\w -]', '', 'g');
  RETURN result;
END;
$$;

ALTER FUNCTION slugify(VARCHAR) OWNER TO lpoaura_fcl;

