CREATE FUNCTION st_distinct4ma(matrix double precision[], nodatamode text, VARIADIC args text[]) RETURNS double precision
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT COUNT(DISTINCT unnest)::float FROM unnest($1)
$$;

ALTER FUNCTION st_distinct4ma(DOUBLE PRECISION[], TEXT, TEXT[]) OWNER TO postgres;

