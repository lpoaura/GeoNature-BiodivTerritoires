CREATE FUNCTION st_intersects(text, text) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_Intersects($1::public.geometry, $2::public.geometry);
$$;

ALTER FUNCTION st_intersects(TEXT, TEXT) OWNER TO postgres;

