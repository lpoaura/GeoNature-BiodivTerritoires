CREATE FUNCTION st_setbandnodatavalue(rast raster, nodatavalue double precision) RETURNS raster
    LANGUAGE SQL
AS
$$
SELECT public.ST_setbandnodatavalue($1, 1, $2, FALSE)
$$;

COMMENT ON FUNCTION st_setbandnodatavalue(RASTER, DOUBLE PRECISION) IS 'args: rast, nodatavalue - Sets the value for the given band that represents no data. Band 1 is assumed if no band is specified. To mark a band as having no nodata value, set the nodata value = NULL.';

ALTER FUNCTION st_setbandnodatavalue(RASTER, DOUBLE PRECISION) OWNER TO postgres;

