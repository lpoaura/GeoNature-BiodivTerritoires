CREATE FUNCTION lockrow(text, text, text) RETURNS integer
    STRICT
    LANGUAGE SQL
AS
$$
SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00');
$$;

COMMENT ON FUNCTION lockrow(TEXT, TEXT, TEXT) IS 'args: a_table_name, a_row_key, an_auth_token - Set lock/authorization for specific row in table';

ALTER FUNCTION lockrow(TEXT, TEXT, TEXT) OWNER TO postgres;

