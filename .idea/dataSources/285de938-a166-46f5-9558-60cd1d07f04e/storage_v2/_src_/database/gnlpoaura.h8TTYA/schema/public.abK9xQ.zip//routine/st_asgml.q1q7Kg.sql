CREATE FUNCTION st_asgml(geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_AsGML(2, $1, $2, $3, null, null);
$$;

COMMENT ON FUNCTION st_asgml(GEOMETRY, INTEGER, INTEGER) IS 'args: geom, maxdecimaldigits=15, options=0 - Return the geometry as a GML version 2 or 3 element.';

ALTER FUNCTION st_asgml(GEOMETRY, INTEGER, INTEGER) OWNER TO postgres;

