CREATE MATERIALIZED VIEW vm_min_max_for_taxons AS
WITH
    s AS (
        SELECT
            synt.cd_nom
          , t.cd_ref
          , synt.the_geom_local
          , synt.date_min
          , synt.date_max
          , synt.altitude_min
          , synt.altitude_max
        FROM
            gn_synthese.synthese synt
                LEFT JOIN taxonomie.taxref t ON t.cd_nom = synt.cd_nom
        WHERE synt.id_nomenclature_valid_status = ANY (ARRAY [1, 2])
    )
  , loc AS (
    SELECT
        s.cd_ref
      , count(*)                                                                    AS nbobs
      , st_transform(st_setsrid(st_extent(s.the_geom_local)::GEOMETRY, 2154), 4326) AS bbox4326
    FROM s
    GROUP BY s.cd_ref
)
  , dat AS (
    SELECT
        s.cd_ref
      , min(to_char(s.date_min, 'DDD'::TEXT)::INTEGER) AS daymin
      , max(to_char(s.date_max, 'DDD'::TEXT)::INTEGER) AS daymax
    FROM s
    GROUP BY s.cd_ref
)
  , alt AS (
    SELECT
        s.cd_ref
      , min(s.altitude_min) AS altitudemin
      , max(s.altitude_max) AS altitudemax
    FROM s
    GROUP BY s.cd_ref
)
SELECT
    loc.cd_ref
  , loc.nbobs
  , dat.daymin
  , dat.daymax
  , alt.altitudemin
  , alt.altitudemax
  , loc.bbox4326
FROM
    loc
        LEFT JOIN alt ON alt.cd_ref = loc.cd_ref
        LEFT JOIN dat ON dat.cd_ref = loc.cd_ref
ORDER BY
    loc.cd_ref;

ALTER MATERIALIZED VIEW vm_min_max_for_taxons OWNER TO fcloitre;

CREATE UNIQUE INDEX i_unique_cd_ref_vm_min_max_for_taxons
    ON vm_min_max_for_taxons(cd_ref);

