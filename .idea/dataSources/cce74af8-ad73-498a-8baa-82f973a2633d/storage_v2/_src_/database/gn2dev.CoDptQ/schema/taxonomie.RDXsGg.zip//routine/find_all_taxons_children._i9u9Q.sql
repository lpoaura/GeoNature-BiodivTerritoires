CREATE FUNCTION find_all_taxons_children(id integer)
    RETURNS TABLE(cd_nom integer, cd_ref integer)
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
    --Param : cd_nom ou cd_ref d'un taxon quelque soit son rang
 --Retourne le cd_nom de tous les taxons enfants sous forme d'un jeu de données utilisable comme une table
 --Usage SELECT taxonomie.find_all_taxons_children(197047);
 --ou SELECT * FROM atlas.vm_taxons WHERE cd_ref IN(SELECT * FROM taxonomie.find_all_taxons_children(197047))
  BEGIN
      RETURN QUERY
      WITH RECURSIVE descendants AS (
        SELECT tx1.cd_nom, tx1.cd_ref FROM taxonomie.taxref tx1 WHERE tx1.cd_taxsup = id
      UNION ALL
      SELECT tx2.cd_nom, tx2.cd_ref FROM descendants d JOIN taxonomie.taxref tx2 ON tx2.cd_taxsup = d.cd_nom
      )
      SELECT * FROM descendants;

  END;
$$;

ALTER FUNCTION find_all_taxons_children(INTEGER) OWNER TO fcloitre;

