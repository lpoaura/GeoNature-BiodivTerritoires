CREATE FUNCTION st_isvalid(geometry, integer) RETURNS boolean
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT (public.ST_isValidDetail($1, $2)).valid
$$;

COMMENT ON FUNCTION st_isvalid(GEOMETRY, INTEGER) IS 'args: g, flags - Returns true if the ST_Geometry is well formed.';

ALTER FUNCTION st_isvalid(GEOMETRY, INTEGER) OWNER TO postgres;

