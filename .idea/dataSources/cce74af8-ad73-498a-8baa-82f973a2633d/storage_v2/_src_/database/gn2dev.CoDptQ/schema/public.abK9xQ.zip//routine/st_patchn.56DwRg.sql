CREATE FUNCTION st_patchn(geometry, integer) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT CASE WHEN public.ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN public.ST_GeometryN($1, $2)
	ELSE NULL END

$$;

COMMENT ON FUNCTION st_patchn(GEOMETRY, INTEGER) IS 'args: geomA, n - Return the 1-based Nth geometry (face) if the geometry is a POLYHEDRALSURFACE, POLYHEDRALSURFACEM. Otherwise, return NULL.';

ALTER FUNCTION st_patchn(GEOMETRY, INTEGER) OWNER TO postgres;

