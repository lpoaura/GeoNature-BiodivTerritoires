CREATE FUNCTION st_geomfromgml(text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_GeomFromGML($1, 0)
$$;

COMMENT ON FUNCTION st_geomfromgml(TEXT) IS 'args: geomgml - Takes as input GML representation of geometry and outputs a PostGIS geometry object';

ALTER FUNCTION st_geomfromgml(TEXT) OWNER TO postgres;

