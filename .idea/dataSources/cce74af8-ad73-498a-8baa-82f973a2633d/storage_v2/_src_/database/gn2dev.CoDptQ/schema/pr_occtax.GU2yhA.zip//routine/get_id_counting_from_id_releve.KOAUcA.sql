CREATE FUNCTION get_id_counting_from_id_releve(my_id_releve integer) RETURNS integer[]
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
-- Function which return the id_countings in an array (table pr_occtax.cor_counting_occtax) from the id_releve(integer)
DECLARE the_array_id_counting integer[];
BEGIN
SELECT INTO the_array_id_counting array_agg(counting.id_counting_occtax)
FROM pr_occtax.cor_counting_occtax counting
JOIN pr_occtax.t_occurrences_occtax occ ON occ.id_occurrence_occtax = counting.id_occurrence_occtax
JOIN pr_occtax.t_releves_occtax rel ON rel.id_releve_occtax = occ.id_releve_occtax
WHERE rel.id_releve_occtax = my_id_releve;
RETURN the_array_id_counting;
END;
$$;

ALTER FUNCTION get_id_counting_from_id_releve(INTEGER) OWNER TO fcloitre;

