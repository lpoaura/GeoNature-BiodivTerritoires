CREATE MATERIALIZED VIEW vm_regne AS
SELECT DISTINCT tx.regne
FROM taxonomie.taxref tx;

ALTER MATERIALIZED VIEW vm_regne OWNER TO fcloitre;

CREATE UNIQUE INDEX i_unique_regne
    ON vm_regne(regne);

