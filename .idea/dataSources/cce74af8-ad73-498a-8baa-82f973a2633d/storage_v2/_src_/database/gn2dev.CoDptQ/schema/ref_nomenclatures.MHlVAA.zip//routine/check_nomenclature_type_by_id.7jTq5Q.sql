CREATE FUNCTION check_nomenclature_type_by_id(id integer, myidtype integer) RETURNS boolean
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--Function that checks if an id_nomenclature matches with wanted nomenclature type (use id_type)
  BEGIN
    IF (id IN (SELECT id_nomenclature FROM ref_nomenclatures.t_nomenclatures WHERE id_type = myidtype )
        OR id IS NULL) THEN
      RETURN true;
    ELSE
	    RAISE EXCEPTION 'Error : id_nomenclature --> (%) and id_type --> (%) didn''t match. Use nomenclature with corresponding type (id_type). See ref_nomenclatures.t_nomenclatures.id_type and ref_nomenclatures.bib_nomenclatures_types.id_type.', id, myidtype ;
    END IF;
    RETURN false;
  END;
$$;

ALTER FUNCTION check_nomenclature_type_by_id(INTEGER, INTEGER) OWNER TO fcloitre;

