CREATE FUNCTION st_asgeojson(gj_version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_AsGeoJson($2::public.geometry, $3::int4, $4::int4);
$$;

COMMENT ON FUNCTION st_asgeojson(INTEGER, GEOMETRY, INTEGER, INTEGER) IS 'args: gj_version, geom, maxdecimaldigits=15, options=0 - Return the geometry as a GeoJSON element.';

ALTER FUNCTION st_asgeojson(INTEGER, GEOMETRY, INTEGER, INTEGER) OWNER TO postgres;

