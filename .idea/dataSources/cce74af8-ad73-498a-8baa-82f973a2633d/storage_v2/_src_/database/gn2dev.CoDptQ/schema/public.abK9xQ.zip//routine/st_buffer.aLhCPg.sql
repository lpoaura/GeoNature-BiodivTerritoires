CREATE FUNCTION st_buffer(geometry, double precision, integer) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_Buffer($1, $2,
		CAST('quad_segs='||CAST($3 AS text) as cstring))

$$;

COMMENT ON FUNCTION st_buffer(GEOMETRY, DOUBLE PRECISION, INTEGER) IS 'args: g1, radius_of_buffer, num_seg_quarter_circle - (T)Returns a geometry covering all points within a given distancefrom the input geometry.';

ALTER FUNCTION st_buffer(GEOMETRY, DOUBLE PRECISION, INTEGER) OWNER TO postgres;

