CREATE FUNCTION fct_tri_update_cd_nom() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
    the_id_areas int[];
BEGIN 
   -- on récupère tous les aires intersectées par l'id_synthese concerné
    SELECT array_agg(id_area) INTO the_id_areas
    FROM gn_synthese.cor_area_synthese
    WHERE id_synthese = OLD.id_synthese;

    -- recalcul pour l'ancien taxon
    PERFORM(gn_synthese.delete_and_insert_area_taxon(OLD.cd_nom, the_id_areas));
    -- recalcul pour le nouveau taxon
    PERFORM(gn_synthese.delete_and_insert_area_taxon(NEW.cd_nom, the_id_areas));
    
  RETURN OLD;
END;
$$;

ALTER FUNCTION fct_tri_update_cd_nom() OWNER TO fcloitre;

