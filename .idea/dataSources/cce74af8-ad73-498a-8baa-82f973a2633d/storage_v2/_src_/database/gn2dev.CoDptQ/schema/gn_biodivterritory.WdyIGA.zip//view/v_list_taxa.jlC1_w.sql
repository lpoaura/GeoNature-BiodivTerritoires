CREATE VIEW v_list_taxa
            ( id, id_area, area_code, cd_ref, nom_vern, nom_valide, group1_inpn, group2_inpn, count_occtax, count_date
            , count_observer, count_dataset, reproduction, statuts_bio, threatened, protected)
AS
SELECT
    row_number() OVER ()                                                                        AS id
  , la.id_area
  , la.area_code
  , tx.cd_ref
  , tx.nom_vern
  , tx.nom_valide
  , tx.group1_inpn
  , tx.group2_inpn
  , count(sy.*)                                                                                 AS count_occtax
  , count(DISTINCT sy.date_min)                                                                 AS count_date
  , count(DISTINCT sy.observers)                                                                AS count_observer
  , count(DISTINCT sy.id_dataset)                                                               AS count_dataset
  , bool_or(
            CASE
                WHEN sy.id_nomenclature_bio_status =
                     ref_nomenclatures.get_id_nomenclature('STATUT_BIO'::CHARACTER VARYING, '3'::CHARACTER VARYING)
                    THEN TRUE
                ELSE FALSE
                END)                                                                            AS reproduction
  , array_agg(DISTINCT ref_nomenclatures.get_nomenclature_label(sy.id_nomenclature_bio_status)) AS statuts_bio
  , FALSE                                                                                       AS threatened
  , FALSE                                                                                       AS protected
FROM
    gn_synthese.cor_area_synthese cas
        JOIN gn_synthese.synthese sy ON cas.id_synthese = sy.id_synthese
        JOIN taxonomie.taxref tx ON sy.cd_nom = tx.cd_nom
        LEFT JOIN taxonomie.taxref_protection_especes ON tx.cd_nom = taxref_protection_especes.cd_nom
        LEFT JOIN taxonomie.taxref_liste_rouge_fr ON taxref_liste_rouge_fr.cd_nom = tx.cd_nom
        JOIN ref_geo.l_areas la ON cas.id_area = la.id_area
GROUP BY
    la.id_area
  , la.area_code
  , tx.cd_ref
  , tx.nom_vern
  , tx.nom_valide
  , tx.group1_inpn
  , tx.group2_inpn;

ALTER TABLE v_list_taxa
    OWNER TO fcloitre;

