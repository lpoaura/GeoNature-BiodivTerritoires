CREATE FUNCTION st_voronoipolygons(g1 geometry, tolerance double precision DEFAULT 0.0, extend_to geometry DEFAULT NULL::geometry) RETURNS geometry
    IMMUTABLE
    PARALLEL SAFE
    COST 1
    LANGUAGE SQL
AS
$$
SELECT public._ST_Voronoi(g1, extend_to, tolerance, true)
$$;

COMMENT ON FUNCTION st_voronoipolygons(GEOMETRY, DOUBLE PRECISION, GEOMETRY) IS 'args: g1, tolerance, extend_to - Returns the cells of the Voronoi diagram constructed from the vertices of a geometry.';

ALTER FUNCTION st_voronoipolygons(GEOMETRY, DOUBLE PRECISION, GEOMETRY) OWNER TO postgres;

