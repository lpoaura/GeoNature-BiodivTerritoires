CREATE FUNCTION get_cd_nomenclature(myidnomenclature integer) RETURNS character varying
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--Function which return the cd_nomenclature from an id_nomenclature
DECLARE thecdnomenclature character varying;
  BEGIN
SELECT INTO thecdnomenclature cd_nomenclature
FROM ref_nomenclatures.t_nomenclatures n
WHERE myidnomenclature = n.id_nomenclature;
return thecdnomenclature;
  END;
$$;

ALTER FUNCTION get_cd_nomenclature(INTEGER) OWNER TO fcloitre;

