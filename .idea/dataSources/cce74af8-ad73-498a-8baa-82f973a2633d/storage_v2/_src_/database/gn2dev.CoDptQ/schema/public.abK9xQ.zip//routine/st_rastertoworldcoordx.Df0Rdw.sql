CREATE FUNCTION st_rastertoworldcoordx(rast raster, xr integer) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT longitude FROM public._ST_rastertoworldcoord($1, $2, NULL)
$$;

COMMENT ON FUNCTION st_rastertoworldcoordx(RASTER, INTEGER) IS 'args: rast, xcolumn - Returns the geometric X coordinate upper left of a raster, column and row. Numbering of columns and rows starts at 1.';

ALTER FUNCTION st_rastertoworldcoordx(RASTER, INTEGER) OWNER TO postgres;

