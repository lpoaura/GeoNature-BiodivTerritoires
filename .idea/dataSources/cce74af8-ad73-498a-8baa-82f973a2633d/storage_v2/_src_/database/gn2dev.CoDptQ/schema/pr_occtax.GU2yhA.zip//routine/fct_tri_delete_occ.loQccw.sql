CREATE FUNCTION fct_tri_delete_occ() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
nb_occ integer;
BEGIN
  -- suppression du releve s'il n'y a plus d'occurrence
  SELECT INTO nb_occ count(*) FROM pr_occtax.t_occurrences_occtax WHERE id_releve_occtax = OLD.id_releve_occtax;
  IF nb_occ < 1 THEN
    DELETE FROM pr_occtax.t_releves_occtax WHERE id_releve_occtax = OLD.id_releve_occtax;
  END IF;

  RETURN OLD;
END;
$$;

ALTER FUNCTION fct_tri_delete_occ() OWNER TO fcloitre;

