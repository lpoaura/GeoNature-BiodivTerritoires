CREATE FUNCTION fct_tri_synthese_delete_occ() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
BEGIN
  -- Suppression dans la synthese
    DELETE FROM gn_synthese.synthese WHERE unique_id_sinp IN (
      SELECT unique_id_sinp_occtax FROM pr_occtax.cor_counting_occtax WHERE id_occurrence_occtax = OLD.id_occurrence_occtax 
    );
  RETURN OLD;
END;
$$;

ALTER FUNCTION fct_tri_synthese_delete_occ() OWNER TO fcloitre;

