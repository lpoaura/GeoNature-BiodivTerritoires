CREATE FUNCTION fct_tri_synthese_delete_counting() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
BEGIN
  -- suppression de l'obs dans le schéma gn_synthese
  DELETE FROM gn_synthese.synthese WHERE unique_id_sinp = OLD.unique_id_sinp_occtax;
  RETURN NULL;
END;
$$;

ALTER FUNCTION fct_tri_synthese_delete_counting() OWNER TO fcloitre;

