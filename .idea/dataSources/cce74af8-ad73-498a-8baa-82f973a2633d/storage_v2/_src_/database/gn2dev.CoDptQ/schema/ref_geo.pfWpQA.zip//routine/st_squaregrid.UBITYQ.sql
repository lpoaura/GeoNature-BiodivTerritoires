CREATE FUNCTION st_squaregrid(p_geometry geometry, p_tilesizex numeric, p_tilesizey numeric, p_point boolean DEFAULT true) RETURNS SETOF t_grid
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
DECLARE
    v_mbr   GEOMETRY;
    v_srid  INT4;
    v_halfX NUMERIC := p_TileSizeX / 2.0;
    v_halfY NUMERIC := p_TileSizeY / 2.0;
    v_loCol INT4;
    v_hiCol INT4;
    v_loRow INT4;
    v_hiRow INT4;
    v_grid  T_GRID;
BEGIN
    IF (p_geometry IS NULL)
    THEN
        RETURN
        ;
    END IF;
    v_srid := ST_SRID(p_geometry);
    v_mbr := ST_Envelope(p_geometry);
    v_loCol := trunc((ST_XMIN(v_mbr) / p_TileSizeX) :: NUMERIC);
    v_hiCol := CEIL((ST_XMAX(v_mbr) / p_TileSizeX) :: NUMERIC) - 1;
    v_loRow := trunc((ST_YMIN(v_mbr) / p_TileSizeY) :: NUMERIC);
    v_hiRow := CEIL((ST_YMAX(v_mbr) / p_TileSizeY) :: NUMERIC) - 1;

    FOR v_col IN v_loCol..v_hiCol
        LOOP
            FOR v_row IN v_loRow..v_hiRow
                LOOP
                    v_grid.gcol := v_col;
                    v_grid.grow := v_row;

                    IF (p_point)
                    THEN
                        v_grid.geom := ST_SetSRID(
                                ST_MakePoint((v_col * p_TileSizeX) + v_halfX,
                                             (v_row * p_TileSizeY) + V_HalfY),
                                v_srid);
                    ELSE
                        v_grid.geom := ST_SetSRID(
                                ST_MakeEnvelope((v_col * p_TileSizeX),
                                                (v_row * p_TileSizeY),
                                                (v_col * p_TileSizeX) + p_TileSizeX,
                                                (v_row * p_TileSizeY) + p_TileSizeY),
                                v_srid);
                    END IF;
                    RETURN NEXT v_grid;
                END LOOP;
        END LOOP;
END;
$$;

ALTER FUNCTION st_squaregrid(GEOMETRY, NUMERIC, NUMERIC, BOOLEAN) OWNER TO fcloitre;

