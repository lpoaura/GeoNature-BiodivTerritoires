CREATE FUNCTION shobj_description(oid, name) RETURNS text
    STABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
select description from pg_catalog.pg_shdescription where objoid = $1 and classoid = (select oid from pg_catalog.pg_class where relname = $2 and relnamespace = 11)
$$;

COMMENT ON FUNCTION shobj_description(OID, NAME) IS 'get description for object id and shared catalog name';

ALTER FUNCTION shobj_description(OID, NAME) OWNER TO fcloitre;

