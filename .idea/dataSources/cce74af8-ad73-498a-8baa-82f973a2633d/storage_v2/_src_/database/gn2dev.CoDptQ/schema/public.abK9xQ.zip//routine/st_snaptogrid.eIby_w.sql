CREATE FUNCTION st_snaptogrid(rast raster, gridx double precision, gridy double precision, scalexy double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) RETURNS raster
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_gdalwarp($1, $5, $6, NULL, $4, $4, $2, $3)
$$;

COMMENT ON FUNCTION st_snaptogrid(RASTER, DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION, TEXT, DOUBLE PRECISION) IS 'args: rast, gridx, gridy, scalexy, algorithm=NearestNeighbour, maxerr=0.125 - Resample a raster by snapping it to a grid. New pixel values are computed using the NearestNeighbor (english or american spelling), Bilinear, Cubic, CubicSpline or Lanczos resampling algorithm. Default is NearestNeighbor.';

ALTER FUNCTION st_snaptogrid(RASTER, DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION, TEXT, DOUBLE PRECISION) OWNER TO postgres;

