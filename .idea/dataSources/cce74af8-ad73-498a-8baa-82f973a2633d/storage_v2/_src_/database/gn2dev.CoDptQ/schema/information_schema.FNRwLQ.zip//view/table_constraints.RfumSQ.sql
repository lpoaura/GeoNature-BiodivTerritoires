CREATE VIEW table_constraints
            ( constraint_catalog, constraint_schema, constraint_name, table_catalog, table_schema, table_name
            , constraint_type, is_deferrable, initially_deferred, enforced)
AS
SELECT
    current_database()::information_schema.SQL_IDENTIFIER  AS constraint_catalog
  , nc.nspname::information_schema.SQL_IDENTIFIER          AS constraint_schema
  , c.conname::information_schema.SQL_IDENTIFIER           AS constraint_name
  , current_database()::information_schema.SQL_IDENTIFIER  AS table_catalog
  , nr.nspname::information_schema.SQL_IDENTIFIER          AS table_schema
  , r.relname::information_schema.SQL_IDENTIFIER           AS table_name
  , CASE c.contype
        WHEN 'c'::"char"
            THEN 'CHECK'::TEXT
        WHEN 'f'::"char"
            THEN 'FOREIGN KEY'::TEXT
        WHEN 'p'::"char"
            THEN 'PRIMARY KEY'::TEXT
        WHEN 'u'::"char"
            THEN 'UNIQUE'::TEXT
        ELSE NULL::TEXT
        END::information_schema.CHARACTER_DATA             AS constraint_type
  , CASE
        WHEN c.condeferrable
            THEN 'YES'::TEXT
        ELSE 'NO'::TEXT
        END::information_schema.YES_OR_NO                  AS is_deferrable
  , CASE
        WHEN c.condeferred
            THEN 'YES'::TEXT
        ELSE 'NO'::TEXT
        END::information_schema.YES_OR_NO                  AS initially_deferred
  , 'YES'::CHARACTER VARYING::information_schema.YES_OR_NO AS enforced
FROM
    pg_namespace nc
  , pg_namespace nr
  , pg_constraint c
  , pg_class r
WHERE
    nc.oid = c.connamespace AND
    nr.oid = r.relnamespace AND
    c.conrelid = r.oid AND
    (c.contype <> ALL (ARRAY ['t'::"char", 'x'::"char"])) AND
    (r.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"])) AND
    NOT pg_is_other_temp_schema(nr.oid) AND
    (pg_has_role(r.relowner, 'USAGE'::TEXT) OR
     has_table_privilege(r.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::TEXT) OR
     has_any_column_privilege(r.oid, 'INSERT, UPDATE, REFERENCES'::TEXT))
UNION ALL
SELECT
    current_database()::information_schema.SQL_IDENTIFIER         AS constraint_catalog
  , nr.nspname::information_schema.SQL_IDENTIFIER                 AS constraint_schema
  , (((((nr.oid::TEXT || '_'::TEXT) || r.oid::TEXT) || '_'::TEXT) || a.attnum::TEXT) ||
     '_not_null'::TEXT)::information_schema.SQL_IDENTIFIER        AS constraint_name
  , current_database()::information_schema.SQL_IDENTIFIER         AS table_catalog
  , nr.nspname::information_schema.SQL_IDENTIFIER                 AS table_schema
  , r.relname::information_schema.SQL_IDENTIFIER                  AS table_name
  , 'CHECK'::CHARACTER VARYING::information_schema.CHARACTER_DATA AS constraint_type
  , 'NO'::CHARACTER VARYING::information_schema.YES_OR_NO         AS is_deferrable
  , 'NO'::CHARACTER VARYING::information_schema.YES_OR_NO         AS initially_deferred
  , 'YES'::CHARACTER VARYING::information_schema.YES_OR_NO        AS enforced
FROM
    pg_namespace nr
  , pg_class r
  , pg_attribute a
WHERE
    nr.oid = r.relnamespace AND
    r.oid = a.attrelid AND
    a.attnotnull AND
    a.attnum > 0 AND
    NOT a.attisdropped AND
    (r.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"])) AND
    NOT pg_is_other_temp_schema(nr.oid) AND
    (pg_has_role(r.relowner, 'USAGE'::TEXT) OR
     has_table_privilege(r.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::TEXT) OR
     has_any_column_privilege(r.oid, 'INSERT, UPDATE, REFERENCES'::TEXT));

ALTER TABLE table_constraints
    OWNER TO fcloitre;

