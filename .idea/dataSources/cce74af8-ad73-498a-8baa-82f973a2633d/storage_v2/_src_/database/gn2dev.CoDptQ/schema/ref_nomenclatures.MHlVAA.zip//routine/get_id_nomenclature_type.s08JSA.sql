CREATE FUNCTION get_id_nomenclature_type(mytype character varying) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--Function which return the id_type from the mnemonique of a nomenclature type
DECLARE theidtype character varying;
  BEGIN
SELECT INTO theidtype id_type FROM ref_nomenclatures.bib_nomenclatures_types WHERE mnemonique = mytype;
return theidtype;
  END;
$$;

ALTER FUNCTION get_id_nomenclature_type(VARCHAR) OWNER TO fcloitre;

