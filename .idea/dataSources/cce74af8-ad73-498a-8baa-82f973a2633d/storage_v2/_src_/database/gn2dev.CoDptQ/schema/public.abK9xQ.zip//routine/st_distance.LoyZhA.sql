CREATE FUNCTION st_distance(geography, geography) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_Distance($1, $2, 0.0, true)
$$;

COMMENT ON FUNCTION st_distance(GEOGRAPHY, GEOGRAPHY) IS 'args: gg1, gg2 - For geometry type returns the 2D Cartesian distance between two geometries in projected units (based on spatial reference system). For geography type defaults to return minimum geodesic distance between two geographies in meters.';

ALTER FUNCTION st_distance(GEOGRAPHY, GEOGRAPHY) OWNER TO postgres;

