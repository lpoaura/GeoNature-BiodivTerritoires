CREATE FUNCTION st_bandmetadata(rast raster, band integer DEFAULT 1, OUT pixeltype text, OUT nodatavalue double precision, OUT isoutdb boolean, OUT path text, OUT outdbbandnum integer, OUT filesize bigint, OUT filetimestamp bigint) RETURNS record
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT pixeltype, nodatavalue, isoutdb, path, outdbbandnum, filesize, filetimestamp FROM public.ST_BandMetaData($1, ARRAY[$2]::int[]) LIMIT 1
$$;

COMMENT ON FUNCTION st_bandmetadata(RASTER, INTEGER, OUT TEXT, OUT DOUBLE PRECISION, OUT BOOLEAN, OUT TEXT, OUT INTEGER, OUT BIGINT, OUT BIGINT) IS 'args: rast, band=1 - Returns basic meta data for a specific raster band. band num 1 is assumed if none-specified.';

ALTER FUNCTION st_bandmetadata(RASTER, INTEGER, OUT TEXT, OUT DOUBLE PRECISION, OUT BOOLEAN, OUT TEXT, OUT INTEGER, OUT BIGINT, OUT BIGINT) OWNER TO postgres;

