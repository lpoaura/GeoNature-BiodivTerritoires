CREATE VIEW v_synthese_for_web_app
            ( id_synthese, unique_id_sinp, unique_id_sinp_grp, id_source, entity_source_pk_value, count_min, count_max
            , nom_cite, meta_v_taxref, sample_number_proof, digital_proof, non_digital_proof, altitude_min, altitude_max
            , the_geom_4326, st_asgeojson, date_min, date_max, validator, validation_comment, observers, id_digitiser
            , determiner, comment_context, comment_description, meta_validation_date, meta_create_date, meta_update_date
            , last_action, id_dataset, dataset_name, id_acquisition_framework, id_nomenclature_geo_object_nature
            , id_nomenclature_info_geo_type, id_nomenclature_grp_typ, id_nomenclature_obs_meth
            , id_nomenclature_obs_technique, id_nomenclature_bio_status, id_nomenclature_bio_condition
            , id_nomenclature_naturalness, id_nomenclature_exist_proof, id_nomenclature_valid_status
            , id_nomenclature_diffusion_level, id_nomenclature_life_stage, id_nomenclature_sex
            , id_nomenclature_obj_count, id_nomenclature_type_count, id_nomenclature_sensitivity
            , id_nomenclature_observation_status, id_nomenclature_blurring, id_nomenclature_source_status
            , id_nomenclature_determination_method, name_source, url_source, cd_nom, cd_ref, nom_valide, lb_nom
            , nom_vern)
AS
SELECT
    s.id_synthese
  , s.unique_id_sinp
  , s.unique_id_sinp_grp
  , s.id_source
  , s.entity_source_pk_value
  , s.count_min
  , s.count_max
  , s.nom_cite
  , s.meta_v_taxref
  , s.sample_number_proof
  , s.digital_proof
  , s.non_digital_proof
  , s.altitude_min
  , s.altitude_max
  , s.the_geom_4326
  , st_asgeojson(s.the_geom_4326) AS st_asgeojson
  , s.date_min
  , s.date_max
  , s.validator
  , s.validation_comment
  , s.observers
  , s.id_digitiser
  , s.determiner
  , s.comment_context
  , s.comment_description
  , s.meta_validation_date
  , s.meta_create_date
  , s.meta_update_date
  , s.last_action
  , d.id_dataset
  , d.dataset_name
  , d.id_acquisition_framework
  , s.id_nomenclature_geo_object_nature
  , s.id_nomenclature_info_geo_type
  , s.id_nomenclature_grp_typ
  , s.id_nomenclature_obs_meth
  , s.id_nomenclature_obs_technique
  , s.id_nomenclature_bio_status
  , s.id_nomenclature_bio_condition
  , s.id_nomenclature_naturalness
  , s.id_nomenclature_exist_proof
  , s.id_nomenclature_valid_status
  , s.id_nomenclature_diffusion_level
  , s.id_nomenclature_life_stage
  , s.id_nomenclature_sex
  , s.id_nomenclature_obj_count
  , s.id_nomenclature_type_count
  , s.id_nomenclature_sensitivity
  , s.id_nomenclature_observation_status
  , s.id_nomenclature_blurring
  , s.id_nomenclature_source_status
  , s.id_nomenclature_determination_method
  , sources.name_source
  , sources.url_source
  , t.cd_nom
  , t.cd_ref
  , t.nom_valide
  , t.lb_nom
  , t.nom_vern
FROM
    gn_synthese.synthese s
        JOIN taxonomie.taxref t ON t.cd_nom = s.cd_nom
        JOIN gn_meta.t_datasets d ON d.id_dataset = s.id_dataset
        JOIN gn_synthese.t_sources sources ON sources.id_source = s.id_source;

ALTER TABLE v_synthese_for_web_app
    OWNER TO fcloitre;

