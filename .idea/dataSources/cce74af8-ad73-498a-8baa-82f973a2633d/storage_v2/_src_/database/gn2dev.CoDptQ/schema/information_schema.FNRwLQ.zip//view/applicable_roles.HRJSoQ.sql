CREATE VIEW applicable_roles(grantee, role_name, is_grantable) AS
SELECT
    a.rolname::information_schema.SQL_IDENTIFIER AS grantee
  , b.rolname::information_schema.SQL_IDENTIFIER AS role_name
  , CASE
        WHEN m.admin_option
            THEN 'YES'::TEXT
        ELSE 'NO'::TEXT
        END::information_schema.YES_OR_NO        AS is_grantable
FROM
    pg_auth_members m
        JOIN pg_authid a ON m.member = a.oid
        JOIN pg_authid b ON m.roleid = b.oid
WHERE
    pg_has_role(a.oid, 'USAGE'::TEXT);

ALTER TABLE applicable_roles
    OWNER TO fcloitre;

