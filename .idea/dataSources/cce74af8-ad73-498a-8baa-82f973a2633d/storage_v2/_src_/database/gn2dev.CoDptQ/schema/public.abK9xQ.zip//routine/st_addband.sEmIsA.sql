CREATE FUNCTION st_addband(rast raster, outdbfile text, outdbindex integer[], index integer DEFAULT NULL::integer, nodataval double precision DEFAULT NULL::double precision) RETURNS raster
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_AddBand($1, $4, $2, $3, $5)
$$;

COMMENT ON FUNCTION st_addband(RASTER, TEXT, INTEGER[], INTEGER, DOUBLE PRECISION) IS 'args: rast, outdbfile, outdbindex, index=at_end, nodataval=NULL - Returns a raster with the new band(s) of given type added with given initial value in the given index location. If no index is specified, the band is added to the end.';

ALTER FUNCTION st_addband(RASTER, TEXT, INTEGER[], INTEGER, DOUBLE PRECISION) OWNER TO postgres;

