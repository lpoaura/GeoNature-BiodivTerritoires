CREATE FUNCTION user_max_accessible_data_level_in_module(myuser integer, myactioncode character varying, mymodulecode character varying) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
DECLARE
 themaxscopelevel integer;
-- the function return the max accessible extend of data the given user can access in the requested module
-- warning: NO heritage between parent and child module
-- USAGE : SELECT gn_permissions.user_max_accessible_data_level_in_module(requested_userid,requested_actionid,requested_moduleid);
-- SAMPLE :SELECT gn_permissions.user_max_accessible_data_level_in_module(2,'U','GEONATURE');
BEGIN
    SELECT max(value_filter::int)
    INTO themaxscopelevel
    FROM gn_permissions.v_users_permissions
    WHERE id_role = myuser AND module_code = mymodulecode AND code_action = myactioncode;
    RETURN themaxscopelevel;
END;
$$;

ALTER FUNCTION user_max_accessible_data_level_in_module(INTEGER, VARCHAR, VARCHAR) OWNER TO fcloitre;

