CREATE FUNCTION st_orderingequals(geometrya geometry, geometryb geometry) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.~=) $2 AND public._ST_OrderingEquals($1, $2)

$$;

COMMENT ON FUNCTION st_orderingequals(GEOMETRY, GEOMETRY) IS 'args: A, B - Returns true if the given geometries represent the same geometry and points are in the same directional order.';

ALTER FUNCTION st_orderingequals(GEOMETRY, GEOMETRY) OWNER TO postgres;

