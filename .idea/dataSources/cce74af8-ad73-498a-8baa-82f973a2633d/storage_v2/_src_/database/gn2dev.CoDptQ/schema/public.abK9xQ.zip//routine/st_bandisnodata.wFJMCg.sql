CREATE FUNCTION st_bandisnodata(rast raster, forcechecking boolean) RETURNS boolean
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_bandisnodata($1, 1, $2)
$$;

COMMENT ON FUNCTION st_bandisnodata(RASTER, BOOLEAN) IS 'args: rast, forceChecking=true - Returns true if the band is filled with only nodata values.';

ALTER FUNCTION st_bandisnodata(RASTER, BOOLEAN) OWNER TO postgres;

