CREATE VIEW user_defined_types
            ( user_defined_type_catalog, user_defined_type_schema, user_defined_type_name, user_defined_type_category
            , is_instantiable, is_final, ordering_form, ordering_category, ordering_routine_catalog
            , ordering_routine_schema, ordering_routine_name, reference_type, data_type, character_maximum_length
            , character_octet_length, character_set_catalog, character_set_schema, character_set_name, collation_catalog
            , collation_schema, collation_name, numeric_precision, numeric_precision_radix, numeric_scale
            , datetime_precision, interval_type, interval_precision, source_dtd_identifier, ref_dtd_identifier)
AS
SELECT
    current_database()::information_schema.SQL_IDENTIFIER              AS user_defined_type_catalog
  , n.nspname::information_schema.SQL_IDENTIFIER                       AS user_defined_type_schema
  , c.relname::information_schema.SQL_IDENTIFIER                       AS user_defined_type_name
  , 'STRUCTURED'::CHARACTER VARYING::information_schema.CHARACTER_DATA AS user_defined_type_category
  , 'YES'::CHARACTER VARYING::information_schema.YES_OR_NO             AS is_instantiable
  , NULL::CHARACTER VARYING::information_schema.YES_OR_NO              AS is_final
  , NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA         AS ordering_form
  , NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA         AS ordering_category
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS ordering_routine_catalog
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS ordering_routine_schema
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS ordering_routine_name
  , NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA         AS reference_type
  , NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA         AS data_type
  , NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS character_maximum_length
  , NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS character_octet_length
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS character_set_catalog
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS character_set_schema
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS character_set_name
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS collation_catalog
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS collation_schema
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS collation_name
  , NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS numeric_precision
  , NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS numeric_precision_radix
  , NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS numeric_scale
  , NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS datetime_precision
  , NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA         AS interval_type
  , NULL::INTEGER::information_schema.CARDINAL_NUMBER                  AS interval_precision
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS source_dtd_identifier
  , NULL::CHARACTER VARYING::information_schema.SQL_IDENTIFIER         AS ref_dtd_identifier
FROM
    pg_namespace n
  , pg_class c
  , pg_type t
WHERE
    n.oid = c.relnamespace AND
    t.typrelid = c.oid AND
    c.relkind = 'c'::"char" AND
    (pg_has_role(t.typowner, 'USAGE'::TEXT) OR has_type_privilege(t.oid, 'USAGE'::TEXT));

ALTER TABLE user_defined_types
    OWNER TO fcloitre;

