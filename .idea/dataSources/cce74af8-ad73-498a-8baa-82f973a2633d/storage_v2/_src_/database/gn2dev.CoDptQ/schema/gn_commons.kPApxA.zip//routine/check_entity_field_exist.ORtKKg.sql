CREATE FUNCTION check_entity_field_exist(myentity character varying) RETURNS boolean
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
    --Function that allows to check if the field of an entity of a table type exists. Parameter : 'schema.table.field'
--USAGE : SELECT gn_commons.check_entity_field_exist('schema.table.field');
  DECLARE
    entity_array character varying(255)[];
  BEGIN
    entity_array = string_to_array(myentity,'.');
      IF entity_array[3] IN(SELECT column_name FROM information_schema.columns WHERE table_schema = entity_array[1] AND table_name = entity_array[2] AND column_name = entity_array[3] ) THEN
        RETURN true;
      END IF;
    RETURN false;
  END;
$$;

ALTER FUNCTION check_entity_field_exist(VARCHAR) OWNER TO fcloitre;

