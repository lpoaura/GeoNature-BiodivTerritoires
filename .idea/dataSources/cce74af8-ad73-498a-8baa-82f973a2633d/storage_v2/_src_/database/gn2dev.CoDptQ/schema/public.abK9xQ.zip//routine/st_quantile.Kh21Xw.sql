CREATE FUNCTION st_quantile(rast raster, quantile double precision) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT ( public._ST_quantile($1, 1, TRUE, 1, ARRAY[$2]::double precision[])).value
$$;

COMMENT ON FUNCTION st_quantile(RASTER, DOUBLE PRECISION) IS 'args: rast, quantile - Compute quantiles for a raster or raster table coverage in the context of the sample or population. Thus, a value could be examined to be at the rasters 25%, 50%, 75% percentile.';

ALTER FUNCTION st_quantile(RASTER, DOUBLE PRECISION) OWNER TO postgres;

