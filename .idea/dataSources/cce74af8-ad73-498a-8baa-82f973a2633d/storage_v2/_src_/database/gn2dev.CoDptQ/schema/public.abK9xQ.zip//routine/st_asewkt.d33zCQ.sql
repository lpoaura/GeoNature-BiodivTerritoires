CREATE FUNCTION st_asewkt(text) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_AsEWKT($1::public.geometry);
$$;

ALTER FUNCTION st_asewkt(TEXT) OWNER TO postgres;

