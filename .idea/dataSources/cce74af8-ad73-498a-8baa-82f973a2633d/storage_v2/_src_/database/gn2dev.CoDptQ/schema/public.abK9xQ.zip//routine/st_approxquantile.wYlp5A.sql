CREATE FUNCTION st_approxquantile(rast raster, nband integer, exclude_nodata_value boolean, sample_percent double precision, quantile double precision) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT ( public._ST_quantile($1, $2, $3, $4, ARRAY[$5]::double precision[])).value
$$;

ALTER FUNCTION st_approxquantile(RASTER, INTEGER, BOOLEAN, DOUBLE PRECISION, DOUBLE PRECISION) OWNER TO postgres;

