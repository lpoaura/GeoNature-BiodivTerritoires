CREATE FUNCTION fct_tri_delete_id_sensitivity_synthese() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
BEGIN
    UPDATE gn_synthese.synthese SET id_nomenclature_sensitivity = gn_synthese.get_default_nomenclature_value('SENSIBILITE'::character varying)
    WHERE unique_id_sinp = OLD.uuid_attached_row;
    RETURN OLD;
END;
$$;

ALTER FUNCTION fct_tri_delete_id_sensitivity_synthese() OWNER TO fcloitre;

