CREATE FUNCTION st_transform(geom geometry, from_proj text, to_srid integer) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.postgis_transform_geometry($1, $2, proj4text, $3)
FROM spatial_ref_sys WHERE srid=$3;
$$;

COMMENT ON FUNCTION st_transform(GEOMETRY, TEXT, INTEGER) IS 'args: geom, from_proj, to_srid - Return a new geometry with its coordinates transformed to a different spatial reference.';

ALTER FUNCTION st_transform(GEOMETRY, TEXT, INTEGER) OWNER TO postgres;

