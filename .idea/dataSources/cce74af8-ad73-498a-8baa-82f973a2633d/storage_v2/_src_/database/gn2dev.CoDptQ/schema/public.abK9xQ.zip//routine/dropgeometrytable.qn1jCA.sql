CREATE FUNCTION dropgeometrytable(schema_name character varying, table_name character varying) RETURNS text
    STRICT
    LANGUAGE SQL
AS
$$
SELECT public.DropGeometryTable('',$1,$2)
$$;

COMMENT ON FUNCTION dropgeometrytable(VARCHAR, VARCHAR) IS 'args: schema_name, table_name - Drops a table and all its references in geometry_columns.';

ALTER FUNCTION dropgeometrytable(VARCHAR, VARCHAR) OWNER TO postgres;

