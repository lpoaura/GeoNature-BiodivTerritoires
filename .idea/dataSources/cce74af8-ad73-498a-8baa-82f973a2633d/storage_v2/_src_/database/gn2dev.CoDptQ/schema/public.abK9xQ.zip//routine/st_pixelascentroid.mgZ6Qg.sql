CREATE FUNCTION st_pixelascentroid(rast raster, x integer, y integer) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_Centroid(geom) FROM public._ST_pixelaspolygons($1, NULL, $2, $3)
$$;

COMMENT ON FUNCTION st_pixelascentroid(RASTER, INTEGER, INTEGER) IS 'args: rast, x, y - Returns the centroid (point geometry) of the area represented by a pixel.';

ALTER FUNCTION st_pixelascentroid(RASTER, INTEGER, INTEGER) OWNER TO postgres;

