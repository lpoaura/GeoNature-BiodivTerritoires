CREATE FUNCTION st_rotatez(geometry, double precision) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_Rotate($1, $2)
$$;

COMMENT ON FUNCTION st_rotatez(GEOMETRY, DOUBLE PRECISION) IS 'args: geomA, rotRadians - Rotate a geometry rotRadians about the Z axis.';

ALTER FUNCTION st_rotatez(GEOMETRY, DOUBLE PRECISION) OWNER TO postgres;

