CREATE VIEW raster_overviews
            ( o_table_catalog, o_table_schema, o_table_name, o_raster_column, r_table_catalog, r_table_schema
            , r_table_name, r_raster_column, overview_factor)
AS
SELECT
    current_database()                                                         AS o_table_catalog
  , n.nspname                                                                  AS o_table_schema
  , c.relname                                                                  AS o_table_name
  , a.attname                                                                  AS o_raster_column
  , current_database()                                                         AS r_table_catalog
  , split_part(split_part(s.consrc, '''::name'::TEXT, 1), ''''::TEXT, 2)::NAME AS r_table_schema
  , split_part(split_part(s.consrc, '''::name'::TEXT, 2), ''''::TEXT, 2)::NAME AS r_table_name
  , split_part(split_part(s.consrc, '''::name'::TEXT, 3), ''''::TEXT, 2)::NAME AS r_raster_column
  , btrim(split_part(s.consrc, ','::TEXT, 2))::INTEGER                         AS overview_factor
FROM
    pg_class c
  , pg_attribute a
  , pg_type t
  , pg_namespace n
  , (SELECT
         pg_constraint.connamespace
       , pg_constraint.conrelid
       , pg_constraint.conkey
       , pg_get_constraintdef(pg_constraint.oid) AS consrc
     FROM pg_constraint) s
WHERE
    t.typname = 'raster'::NAME AND
    a.attisdropped = FALSE AND
    a.atttypid = t.oid AND
    a.attrelid = c.oid AND
    c.relnamespace = n.oid AND
    (c.relkind::TEXT = ANY
     (ARRAY ['r'::CHARACTER(1), 'v'::CHARACTER(1), 'm'::CHARACTER(1), 'f'::CHARACTER(1)]::TEXT[])) AND
    s.connamespace = n.oid AND
    s.conrelid = c.oid AND
    s.consrc ~~ '%_overview_constraint(%'::TEXT AND
    NOT pg_is_other_temp_schema(c.relnamespace) AND
    has_table_privilege(c.oid, 'SELECT'::TEXT);

ALTER TABLE raster_overviews
    OWNER TO postgres;

