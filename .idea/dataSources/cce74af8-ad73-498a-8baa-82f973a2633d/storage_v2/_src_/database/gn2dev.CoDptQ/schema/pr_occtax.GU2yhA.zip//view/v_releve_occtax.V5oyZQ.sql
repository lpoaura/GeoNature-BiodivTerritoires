CREATE VIEW v_releve_occtax
            ( id_releve_occtax, id_dataset, id_digitiser, date_min, date_max, altitude_min, altitude_max
            , meta_device_entry, comment, geom_4326, precision, id_occurrence_occtax, cd_nom, nom_cite, lb_nom
            , nom_valide, nom_vern, leaflet_popup, observateurs)
AS
SELECT
    rel.id_releve_occtax
  , rel.id_dataset
  , rel.id_digitiser
  , rel.date_min
  , rel.date_max
  , rel.altitude_min
  , rel.altitude_max
  , rel.meta_device_entry
  , rel.comment
  , rel.geom_4326
  , rel."precision"
  , occ.id_occurrence_occtax
  , occ.cd_nom
  , occ.nom_cite
  , t.lb_nom
  , t.nom_valide
  , t.nom_vern
  , (((t.nom_complet_html::TEXT || ' '::TEXT) || rel.date_min::DATE) || '<br/>'::TEXT) ||
    string_agg(DISTINCT (obs.nom_role::TEXT || ' '::TEXT) || obs.prenom_role::TEXT, ', '::TEXT) AS leaflet_popup
  , COALESCE(string_agg(DISTINCT (obs.nom_role::TEXT || ' '::TEXT) || obs.prenom_role::TEXT, ', '::TEXT),
             rel.observers_txt::TEXT)                                                           AS observateurs
FROM
    pr_occtax.t_releves_occtax rel
        LEFT JOIN pr_occtax.t_occurrences_occtax occ ON rel.id_releve_occtax = occ.id_releve_occtax
        LEFT JOIN taxonomie.taxref t ON occ.cd_nom = t.cd_nom
        LEFT JOIN pr_occtax.cor_role_releves_occtax cor_role ON cor_role.id_releve_occtax = rel.id_releve_occtax
        LEFT JOIN utilisateurs.t_roles obs ON cor_role.id_role = obs.id_role
GROUP BY
    rel.id_releve_occtax
  , rel.id_dataset
  , rel.id_digitiser
  , rel.date_min
  , rel.date_max
  , rel.altitude_min
  , rel.altitude_max
  , rel.meta_device_entry
  , rel.comment
  , rel.geom_4326
  , rel."precision"
  , t.cd_nom
  , occ.nom_cite
  , occ.id_occurrence_occtax
  , t.lb_nom
  , t.nom_valide
  , t.nom_complet_html
  , t.nom_vern;

ALTER TABLE v_releve_occtax
    OWNER TO fcloitre;

