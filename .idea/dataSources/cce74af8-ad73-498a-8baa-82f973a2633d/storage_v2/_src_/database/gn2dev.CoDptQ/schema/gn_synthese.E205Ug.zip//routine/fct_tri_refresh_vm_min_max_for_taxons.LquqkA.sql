CREATE FUNCTION fct_tri_refresh_vm_min_max_for_taxons() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
BEGIN
      EXECUTE 'REFRESH MATERIALIZED VIEW CONCURRENTLY gn_synthese.vm_min_max_for_taxons;';
      RETURN NULL;
END;
$$;

ALTER FUNCTION fct_tri_refresh_vm_min_max_for_taxons() OWNER TO fcloitre;

