CREATE FUNCTION st_asgml(text) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_AsGML(2,$1::public.geometry,15,0, NULL, NULL);
$$;

ALTER FUNCTION st_asgml(TEXT) OWNER TO postgres;

