CREATE FUNCTION st_length(text) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT ST_Length($1::public.geometry);
$$;

ALTER FUNCTION st_length(TEXT) OWNER TO postgres;

