CREATE MATERIALIZED VIEW vm_ordre AS
SELECT DISTINCT tx.ordre
FROM taxonomie.taxref tx;

ALTER MATERIALIZED VIEW vm_ordre OWNER TO fcloitre;

CREATE UNIQUE INDEX i_unique_ordre
    ON vm_ordre(ordre);

