CREATE FUNCTION fct_tri_synthese_insert_cor_role_releve() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
  uuids_counting uuid[];
BEGIN
  -- Récupération des id_counting à partir de l'id_releve
  SELECT INTO uuids_counting pr_occtax.get_unique_id_sinp_from_id_releve(NEW.id_releve_occtax::integer);
  
  IF uuids_counting IS NOT NULL THEN
      -- Insertion dans cor_observer_synthese pour chaque counting
      INSERT INTO gn_synthese.cor_observer_synthese(id_synthese, id_role) 
      SELECT id_synthese, NEW.id_role 
      FROM gn_synthese.synthese 
      WHERE unique_id_sinp IN(SELECT unnest(uuids_counting));
  END IF;
RETURN NULL;
END;
$$;

ALTER FUNCTION fct_tri_synthese_insert_cor_role_releve() OWNER TO fcloitre;

