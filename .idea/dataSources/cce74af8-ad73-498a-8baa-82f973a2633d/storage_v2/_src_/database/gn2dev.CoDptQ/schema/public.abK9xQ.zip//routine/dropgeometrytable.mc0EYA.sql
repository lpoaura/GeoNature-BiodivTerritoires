CREATE FUNCTION dropgeometrytable(table_name character varying) RETURNS text
    STRICT
    LANGUAGE SQL
AS
$$
SELECT public.DropGeometryTable('','',$1)
$$;

COMMENT ON FUNCTION dropgeometrytable(VARCHAR) IS 'args: table_name - Drops a table and all its references in geometry_columns.';

ALTER FUNCTION dropgeometrytable(VARCHAR) OWNER TO postgres;

