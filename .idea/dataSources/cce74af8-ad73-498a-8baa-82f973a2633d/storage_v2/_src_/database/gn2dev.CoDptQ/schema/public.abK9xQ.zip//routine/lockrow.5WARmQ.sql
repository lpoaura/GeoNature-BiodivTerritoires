CREATE FUNCTION lockrow(text, text, text, timestamp without time zone) RETURNS integer
    STRICT
    LANGUAGE SQL
AS
$$
SELECT LockRow(current_schema(), $1, $2, $3, $4);
$$;

COMMENT ON FUNCTION lockrow(TEXT, TEXT, TEXT, TIMESTAMP) IS 'args: a_table_name, a_row_key, an_auth_token, expire_dt - Set lock/authorization for specific row in table';

ALTER FUNCTION lockrow(TEXT, TEXT, TEXT, TIMESTAMP) OWNER TO postgres;

