CREATE FUNCTION st_3ddwithin(geom1 geometry, geom2 geometry, double precision) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.&&) public.ST_Expand($2,$3) AND $2 OPERATOR(public.&&) public.ST_Expand($1,$3) AND public._ST_3DDWithin($1, $2, $3)
$$;

COMMENT ON FUNCTION st_3ddwithin(GEOMETRY, GEOMETRY, DOUBLE PRECISION) IS 'args: g1, g2, distance_of_srid - For 3d (z) geometry type Returns true if two geometries 3d distance is within number of units.';

ALTER FUNCTION st_3ddwithin(GEOMETRY, GEOMETRY, DOUBLE PRECISION) OWNER TO postgres;

