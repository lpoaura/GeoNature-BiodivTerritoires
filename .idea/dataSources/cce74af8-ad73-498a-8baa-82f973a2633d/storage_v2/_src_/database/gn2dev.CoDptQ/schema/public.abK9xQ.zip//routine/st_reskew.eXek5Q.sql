CREATE FUNCTION st_reskew(rast raster, skewx double precision, skewy double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) RETURNS raster
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_GdalWarp($1, $4, $5, NULL, 0, 0, NULL, NULL, $2, $3)
$$;

COMMENT ON FUNCTION st_reskew(RASTER, DOUBLE PRECISION, DOUBLE PRECISION, TEXT, DOUBLE PRECISION) IS 'args: rast, skewx, skewy, algorithm=NearestNeighbour, maxerr=0.125 - Resample a raster by adjusting only its skew (or rotation parameters). New pixel values are computed using the NearestNeighbor (english or american spelling), Bilinear, Cubic, CubicSpline or Lanczos resampling algorithm. Default is NearestNeighbor.';

ALTER FUNCTION st_reskew(RASTER, DOUBLE PRECISION, DOUBLE PRECISION, TEXT, DOUBLE PRECISION) OWNER TO postgres;

