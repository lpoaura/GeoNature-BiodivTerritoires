CREATE FUNCTION st_transform(geom geometry, to_proj text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.postgis_transform_geometry($1, proj4text, $2, 0)
FROM spatial_ref_sys WHERE srid=public.ST_SRID($1);
$$;

COMMENT ON FUNCTION st_transform(GEOMETRY, TEXT) IS 'args: geom, to_proj - Return a new geometry with its coordinates transformed to a different spatial reference.';

ALTER FUNCTION st_transform(GEOMETRY, TEXT) OWNER TO postgres;

