CREATE FUNCTION calcul_cor_area_taxon(my_id_area integer, my_cd_nom integer) RETURNS void
    LANGUAGE plpgsql
AS
$$
BEGIN
  -- on supprime cor_area_taxon et recree à chaque fois
  -- cela evite de regarder dans cor_area_taxon s'il y a deja une ligne, de faire un + 1  ou -1 sur nb_obs etc...
  DELETE FROM gn_synthese.cor_area_taxon WHERE cd_nom = my_cd_nom AND id_area = my_id_area;
-- puis on réinsert
-- on récupère la dernière date de l'obs dans l'aire concernée depuis cor_area_synthese et synthese
	INSERT INTO gn_synthese.cor_area_taxon (id_area, cd_nom, last_date, nb_obs)
	SELECT id_area, s.cd_nom,  max(s.date_min) AS last_date, count(s.id_synthese) AS nb_obs
	FROM gn_synthese.cor_area_synthese cor
  JOIN gn_synthese.synthese s ON s.id_synthese = cor.id_synthese
	WHERE s.cd_nom = my_cd_nom
	AND id_area = my_id_area
  GROUP BY id_area, s.cd_nom
  ;
  END;
$$;

ALTER FUNCTION calcul_cor_area_taxon(INTEGER, INTEGER) OWNER TO fcloitre;

