CREATE FUNCTION st_intersection(text, text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_Intersection($1::public.geometry, $2::public.geometry);
$$;

ALTER FUNCTION st_intersection(TEXT, TEXT) OWNER TO postgres;

