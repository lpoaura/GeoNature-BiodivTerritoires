CREATE VIEW information_schema_catalog_name(catalog_name) AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS catalog_name;

ALTER TABLE information_schema_catalog_name
    OWNER TO fcloitre;

