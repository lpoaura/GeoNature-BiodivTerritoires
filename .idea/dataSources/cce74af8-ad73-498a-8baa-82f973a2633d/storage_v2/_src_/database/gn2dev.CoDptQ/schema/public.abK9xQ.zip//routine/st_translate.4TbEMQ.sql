CREATE FUNCTION st_translate(geometry, double precision, double precision) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_Translate($1, $2, $3, 0)
$$;

COMMENT ON FUNCTION st_translate(GEOMETRY, DOUBLE PRECISION, DOUBLE PRECISION) IS 'args: g1, deltax, deltay - Translate a geometry by given offsets.';

ALTER FUNCTION st_translate(GEOMETRY, DOUBLE PRECISION, DOUBLE PRECISION) OWNER TO postgres;

