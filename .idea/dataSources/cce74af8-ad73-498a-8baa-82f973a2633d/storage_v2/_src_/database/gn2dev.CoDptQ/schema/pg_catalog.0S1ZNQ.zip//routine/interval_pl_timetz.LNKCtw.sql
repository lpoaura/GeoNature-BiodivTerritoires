CREATE FUNCTION interval_pl_timetz(interval, time with time zone) RETURNS time with time zone
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE SQL
AS
$$
select $2 + $1
$$;

COMMENT ON FUNCTION interval_pl_timetz(INTERVAL, TIME WITH TIME ZONE) IS 'implementation of + operator';

ALTER FUNCTION interval_pl_timetz(INTERVAL, TIME WITH TIME ZONE) OWNER TO fcloitre;

