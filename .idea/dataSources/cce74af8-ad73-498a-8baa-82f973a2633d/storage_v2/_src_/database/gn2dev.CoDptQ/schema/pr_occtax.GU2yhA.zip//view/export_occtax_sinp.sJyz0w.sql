CREATE VIEW export_occtax_sinp
            ( "permId", "statObs", "nomCite", "dateDebut", "dateFin", "heureDebut", "heureFin", "altMax", "altMin"
            , "cdNom", "cdRef", "vTAXREF", "dSPublique", "jddMetaId", "statSource", "difNivPrec", "idOrigine", "jddCode"
            , "jddId", "refBiblio", "obsMeth", "ocEtatBio", "ocNat", "ocSex", "ocStade", "ocBiogeo", "ocStatBio"
            , "preuveOui", "ocMethDet", "preuvNum", "preuvNoNum", "obsCtx", "obsDescr", "permIdGrp", "methGrp", "typGrp"
            , "denbrMax", "denbrMin", "objDenbr", "typDenbr", "obsId", "obsNomOrg", "detId", "detNomOrg", "orgGestDat"
            , "WKT", "natObjGeo", date_min, date_max, id_dataset, id_releve_occtax, id_occurrence_occtax, id_digitiser
            , geom_4326)
AS
SELECT
    ccc.unique_id_sinp_occtax                                                                                      AS "permId"
  , ref_nomenclatures.get_cd_nomenclature(
            occ.id_nomenclature_observation_status)                                                                AS "statObs"
  , occ.nom_cite                                                                                                   AS "nomCite"
  , to_char(rel.date_min, 'DD/MM/YYYY'::TEXT)                                                                      AS "dateDebut"
  , to_char(rel.date_max, 'DD/MM/YYYY'::TEXT)                                                                      AS "dateFin"
  , rel.hour_min                                                                                                   AS "heureDebut"
  , rel.hour_max                                                                                                   AS "heureFin"
  , rel.altitude_max                                                                                               AS "altMax"
  , rel.altitude_min                                                                                               AS "altMin"
  , occ.cd_nom                                                                                                     AS "cdNom"
  , taxonomie.find_cdref(occ.cd_nom)                                                                               AS "cdRef"
  , gn_commons.get_default_parameter('taxref_version'::TEXT,
                                     NULL::INTEGER)                                                                AS "vTAXREF"
  , 'NSP'::TEXT                                                                                                    AS "dSPublique"
  , d.unique_dataset_id                                                                                            AS "jddMetaId"
  , ref_nomenclatures.get_cd_nomenclature(
            occ.id_nomenclature_source_status)                                                                     AS "statSource"
  , '0'::TEXT                                                                                                      AS "difNivPrec"
  , ccc.unique_id_sinp_occtax                                                                                      AS "idOrigine"
  , d.dataset_name                                                                                                 AS "jddCode"
  , d.unique_dataset_id                                                                                            AS "jddId"
  , NULL::TEXT                                                                                                     AS "refBiblio"
  , ref_nomenclatures.get_cd_nomenclature(occ.id_nomenclature_obs_meth)                                            AS "obsMeth"
  , ref_nomenclatures.get_cd_nomenclature(
            occ.id_nomenclature_bio_condition)                                                                     AS "ocEtatBio"
  , COALESCE(ref_nomenclatures.get_cd_nomenclature(occ.id_nomenclature_naturalness),
             '0'::TEXT::CHARACTER VARYING)                                                                         AS "ocNat"
  , ref_nomenclatures.get_cd_nomenclature(ccc.id_nomenclature_sex)                                                 AS "ocSex"
  , ref_nomenclatures.get_cd_nomenclature(
            ccc.id_nomenclature_life_stage)                                                                        AS "ocStade"
  , '0'::TEXT                                                                                                      AS "ocBiogeo"
  , COALESCE(ref_nomenclatures.get_cd_nomenclature(occ.id_nomenclature_bio_status),
             '0'::TEXT::CHARACTER VARYING)                                                                         AS "ocStatBio"
  , COALESCE(ref_nomenclatures.get_cd_nomenclature(occ.id_nomenclature_exist_proof),
             '0'::TEXT::CHARACTER VARYING)                                                                         AS "preuveOui"
  , ref_nomenclatures.get_nomenclature_label(occ.id_nomenclature_determination_method,
                                             'fr'::CHARACTER VARYING)                                              AS "ocMethDet"
  , occ.digital_proof                                                                                              AS "preuvNum"
  , occ.non_digital_proof                                                                                          AS "preuvNoNum"
  , rel.comment                                                                                                    AS "obsCtx"
  , occ.comment                                                                                                    AS "obsDescr"
  , rel.unique_id_sinp_grp                                                                                         AS "permIdGrp"
  , 'Relevé'::TEXT                                                                                                 AS "methGrp"
  , 'OBS'::TEXT                                                                                                    AS "typGrp"
  , ccc.count_max                                                                                                  AS "denbrMax"
  , ccc.count_min                                                                                                  AS "denbrMin"
  , ref_nomenclatures.get_cd_nomenclature(ccc.id_nomenclature_obj_count)                                           AS "objDenbr"
  , ref_nomenclatures.get_cd_nomenclature(
            ccc.id_nomenclature_type_count)                                                                        AS "typDenbr"
  , COALESCE(string_agg(DISTINCT (r.nom_role::TEXT || ' '::TEXT) || r.prenom_role::TEXT, ','::TEXT),
             rel.observers_txt::TEXT)                                                                              AS "obsId"
  , COALESCE(string_agg(DISTINCT o.nom_organisme::TEXT, ','::TEXT),
             'NSP'::TEXT)                                                                                          AS "obsNomOrg"
  , COALESCE(occ.determiner, 'Inconnu'::CHARACTER VARYING)                                                         AS "detId"
  , 'NSP'::TEXT                                                                                                    AS "detNomOrg"
  , 'NSP'::TEXT                                                                                                    AS "orgGestDat"
  , st_astext(rel.geom_4326)                                                                                       AS "WKT"
  , 'In'::TEXT                                                                                                     AS "natObjGeo"
  , rel.date_min
  , rel.date_max
  , rel.id_dataset
  , rel.id_releve_occtax
  , occ.id_occurrence_occtax
  , rel.id_digitiser
  , rel.geom_4326
FROM
    pr_occtax.t_releves_occtax rel
        LEFT JOIN pr_occtax.t_occurrences_occtax occ ON rel.id_releve_occtax = occ.id_releve_occtax
        LEFT JOIN pr_occtax.cor_counting_occtax ccc ON ccc.id_occurrence_occtax = occ.id_occurrence_occtax
        LEFT JOIN taxonomie.taxref tax ON tax.cd_nom = occ.cd_nom
        LEFT JOIN gn_meta.t_datasets d ON d.id_dataset = rel.id_dataset
        LEFT JOIN pr_occtax.cor_role_releves_occtax cr ON cr.id_releve_occtax = rel.id_releve_occtax
        LEFT JOIN utilisateurs.t_roles r ON r.id_role = cr.id_role
        LEFT JOIN utilisateurs.bib_organismes o ON o.id_organisme = r.id_organisme
GROUP BY
    ccc.unique_id_sinp_occtax
  , d.unique_dataset_id
  , occ.id_occurrence_occtax
  , occ.id_nomenclature_bio_condition
  , occ.id_nomenclature_naturalness
  , ccc.id_nomenclature_sex
  , ccc.id_nomenclature_life_stage
  , occ.id_nomenclature_bio_status
  , occ.id_nomenclature_exist_proof
  , occ.id_nomenclature_determination_method
  , rel.unique_id_sinp_grp
  , d.id_nomenclature_source_status
  , occ.id_nomenclature_blurring
  , occ.id_nomenclature_diffusion_level
  , occ.nom_cite
  , rel.id_releve_occtax
  , rel.date_min
  , rel.date_max
  , rel.hour_min
  , rel.hour_max
  , rel.altitude_max
  , rel.altitude_min
  , rel.id_digitiser
  , occ.cd_nom
  , occ.id_nomenclature_observation_status
  , (taxonomie.find_cdref(occ.cd_nom))
  , (gn_commons.get_default_parameter('taxref_version'::TEXT, NULL::INTEGER))
  , rel.comment
  , rel.id_dataset
  , (ref_nomenclatures.get_cd_nomenclature(occ.id_nomenclature_source_status))
  , ccc.id_counting_occtax
  , d.dataset_name
  , occ.determiner
  , occ.comment
  , (ref_nomenclatures.get_cd_nomenclature(occ.id_nomenclature_obs_meth))
  , (ref_nomenclatures.get_cd_nomenclature(occ.id_nomenclature_bio_condition))
  , (ref_nomenclatures.get_cd_nomenclature(occ.id_nomenclature_naturalness))
  , (ref_nomenclatures.get_cd_nomenclature(ccc.id_nomenclature_sex))
  , (ref_nomenclatures.get_cd_nomenclature(ccc.id_nomenclature_life_stage))
  , (ref_nomenclatures.get_cd_nomenclature(occ.id_nomenclature_bio_status))
  , (ref_nomenclatures.get_cd_nomenclature(occ.id_nomenclature_exist_proof))
  , (ref_nomenclatures.get_nomenclature_label(occ.id_nomenclature_determination_method))
  , occ.digital_proof
  , occ.non_digital_proof
  , ccc.count_max
  , ccc.count_min
  , (ref_nomenclatures.get_cd_nomenclature(ccc.id_nomenclature_obj_count))
  , (ref_nomenclatures.get_cd_nomenclature(ccc.id_nomenclature_type_count))
  , rel.observers_txt
  , rel.geom_4326;

ALTER TABLE export_occtax_sinp
    OWNER TO fcloitre;

