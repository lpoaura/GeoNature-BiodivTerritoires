CREATE VIEW view_routine_usage
            (table_catalog, table_schema, table_name, specific_catalog, specific_schema, specific_name) AS
SELECT DISTINCT
    current_database()::information_schema.SQL_IDENTIFIER                              AS table_catalog
  , nv.nspname::information_schema.SQL_IDENTIFIER                                      AS table_schema
  , v.relname::information_schema.SQL_IDENTIFIER                                       AS table_name
  , current_database()::information_schema.SQL_IDENTIFIER                              AS specific_catalog
  , np.nspname::information_schema.SQL_IDENTIFIER                                      AS specific_schema
  , ((p.proname::TEXT || '_'::TEXT) || p.oid::TEXT)::information_schema.SQL_IDENTIFIER AS specific_name
FROM
    pg_namespace nv
  , pg_class v
  , pg_depend dv
  , pg_depend dp
  , pg_proc p
  , pg_namespace np
WHERE
    nv.oid = v.relnamespace AND
    v.relkind = 'v'::"char" AND
    v.oid = dv.refobjid AND
    dv.refclassid = 'pg_class'::REGCLASS::OID AND
    dv.classid = 'pg_rewrite'::REGCLASS::OID AND
    dv.deptype = 'i'::"char" AND
    dv.objid = dp.objid AND
    dp.classid = 'pg_rewrite'::REGCLASS::OID AND
    dp.refclassid = 'pg_proc'::REGCLASS::OID AND
    dp.refobjid = p.oid AND
    p.pronamespace = np.oid AND
    pg_has_role(p.proowner, 'USAGE'::TEXT);

ALTER TABLE view_routine_usage
    OWNER TO fcloitre;

