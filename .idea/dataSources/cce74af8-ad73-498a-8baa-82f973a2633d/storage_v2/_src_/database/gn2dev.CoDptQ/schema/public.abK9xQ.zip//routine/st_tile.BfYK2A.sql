CREATE FUNCTION st_tile(rast raster, nband integer[], width integer, height integer, padwithnodata boolean DEFAULT false, nodataval double precision DEFAULT NULL::double precision) RETURNS SETOF raster
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_tile($1, $3, $4, $2, $5, $6)
$$;

COMMENT ON FUNCTION st_tile(RASTER, INTEGER[], INTEGER, INTEGER, BOOLEAN, DOUBLE PRECISION) IS 'args: rast, nband, width, height, padwithnodata=FALSE, nodataval=NULL - Returns a set of rasters resulting from the split of the input raster based upon the desired dimensions of the output rasters.';

ALTER FUNCTION st_tile(RASTER, INTEGER[], INTEGER, INTEGER, BOOLEAN, DOUBLE PRECISION) OWNER TO postgres;

