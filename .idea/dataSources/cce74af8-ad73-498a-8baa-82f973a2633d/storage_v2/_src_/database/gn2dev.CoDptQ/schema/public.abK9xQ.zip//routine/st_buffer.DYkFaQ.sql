CREATE FUNCTION st_buffer(geometry, double precision, text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_Buffer($1, $2,
		CAST( regexp_replace($3, '^[0123456789]+$',
			'quad_segs='||$3) AS cstring)
		)

$$;

COMMENT ON FUNCTION st_buffer(GEOMETRY, DOUBLE PRECISION, TEXT) IS 'args: g1, radius_of_buffer, buffer_style_parameters - (T)Returns a geometry covering all points within a given distancefrom the input geometry.';

ALTER FUNCTION st_buffer(GEOMETRY, DOUBLE PRECISION, TEXT) OWNER TO postgres;

