CREATE FUNCTION st_resize(rast raster, width integer, height integer, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) RETURNS raster
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_gdalwarp($1, $4, $5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, abs($2), abs($3))
$$;

COMMENT ON FUNCTION st_resize(RASTER, INTEGER, INTEGER, TEXT, DOUBLE PRECISION) IS 'args: rast, width, height, algorithm=NearestNeighbor, maxerr=0.125 - Resize a raster to a new width/height';

ALTER FUNCTION st_resize(RASTER, INTEGER, INTEGER, TEXT, DOUBLE PRECISION) OWNER TO postgres;

