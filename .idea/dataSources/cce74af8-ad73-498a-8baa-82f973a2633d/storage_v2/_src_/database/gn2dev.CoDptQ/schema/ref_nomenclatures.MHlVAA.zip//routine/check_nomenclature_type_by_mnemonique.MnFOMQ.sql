CREATE FUNCTION check_nomenclature_type_by_mnemonique(id integer, mytype character varying) RETURNS boolean
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--Function that checks if an id_nomenclature matches with wanted nomenclature type (use mnemonique type)
  BEGIN
    IF (id IN (SELECT id_nomenclature FROM ref_nomenclatures.t_nomenclatures WHERE id_type = ref_nomenclatures.get_id_nomenclature_type(mytype))
        OR id IS NULL) THEN
      RETURN true;
    ELSE
	    RAISE EXCEPTION 'Error : id_nomenclature --> (%) and nomenclature --> (%) type didn''t match. Use id_nomenclature in corresponding type (mnemonique field). See ref_nomenclatures.t_nomenclatures.id_type.', id,mytype;
    END IF;
    RETURN false;
  END;
$$;

ALTER FUNCTION check_nomenclature_type_by_mnemonique(INTEGER, VARCHAR) OWNER TO fcloitre;

