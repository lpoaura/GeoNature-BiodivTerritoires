CREATE FUNCTION geometry_raster_contain(geometry, raster) RETURNS boolean
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
select $1 OPERATOR(public.~) $2::public.geometry
$$;

ALTER FUNCTION geometry_raster_contain(GEOMETRY, RASTER) OWNER TO postgres;

