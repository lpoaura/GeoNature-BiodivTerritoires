CREATE FUNCTION st_histogram(rast raster, nband integer, exclude_nodata_value boolean, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) RETURNS SETOF record
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT min, max, count, percent FROM public._ST_histogram($1, $2, $3, 1, $4, NULL, $5)
$$;

COMMENT ON FUNCTION st_histogram(RASTER, INTEGER, BOOLEAN, INTEGER, BOOLEAN, OUT DOUBLE PRECISION, OUT DOUBLE PRECISION, OUT BIGINT, OUT DOUBLE PRECISION) IS 'args: rast, nband, exclude_nodata_value, bins, right - Returns a set of record summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

ALTER FUNCTION st_histogram(RASTER, INTEGER, BOOLEAN, INTEGER, BOOLEAN, OUT DOUBLE PRECISION, OUT DOUBLE PRECISION, OUT BIGINT, OUT DOUBLE PRECISION) OWNER TO postgres;

