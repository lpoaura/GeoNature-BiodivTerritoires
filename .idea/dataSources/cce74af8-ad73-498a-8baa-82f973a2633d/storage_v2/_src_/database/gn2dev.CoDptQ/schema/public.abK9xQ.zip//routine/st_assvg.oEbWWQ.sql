CREATE FUNCTION st_assvg(text) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_AsSVG($1::public.geometry,0,15);
$$;

ALTER FUNCTION st_assvg(TEXT) OWNER TO postgres;

