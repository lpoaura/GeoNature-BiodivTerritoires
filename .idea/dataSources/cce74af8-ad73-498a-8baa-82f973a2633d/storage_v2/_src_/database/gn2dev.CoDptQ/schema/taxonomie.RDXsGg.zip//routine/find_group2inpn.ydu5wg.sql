CREATE FUNCTION find_group2inpn(mycdnom integer) RETURNS text
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--fonction permettant de renvoyer le group2_inpn d'un taxon à partir de son cd_nom
  DECLARE group2 character varying(255);
  BEGIN
    SELECT INTO group2 group2_inpn FROM taxonomie.taxref WHERE cd_nom = mycdnom;
    return group2;
  END;
$$;

ALTER FUNCTION find_group2inpn(INTEGER) OWNER TO fcloitre;

