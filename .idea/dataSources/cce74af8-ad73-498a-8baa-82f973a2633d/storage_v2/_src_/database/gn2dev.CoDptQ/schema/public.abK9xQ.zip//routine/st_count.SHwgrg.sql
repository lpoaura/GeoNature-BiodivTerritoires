CREATE FUNCTION st_count(rastertable text, rastercolumn text, exclude_nodata_value boolean) RETURNS bigint
    STABLE
    STRICT
    LANGUAGE SQL
AS
$$
SELECT public._ST_count($1, $2, 1, $3, 1)
$$;

COMMENT ON FUNCTION st_count(TEXT, TEXT, BOOLEAN) IS 'args: rastertable, rastercolumn, exclude_nodata_value - Returns the number of pixels in a given band of a raster or raster coverage. If no band is specified defaults to band 1. If exclude_nodata_value is set to true, will only count pixels that are not equal to the nodata value.';

ALTER FUNCTION st_count(TEXT, TEXT, BOOLEAN) OWNER TO postgres;

