CREATE FUNCTION _pg_truetypid(pg_attribute, pg_type) RETURNS oid
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT CASE WHEN $2.typtype = 'd' THEN $2.typbasetype ELSE $1.atttypid END
$$;

ALTER FUNCTION _pg_truetypid(PG_ATTRIBUTE, PG_TYPE) OWNER TO fcloitre;

