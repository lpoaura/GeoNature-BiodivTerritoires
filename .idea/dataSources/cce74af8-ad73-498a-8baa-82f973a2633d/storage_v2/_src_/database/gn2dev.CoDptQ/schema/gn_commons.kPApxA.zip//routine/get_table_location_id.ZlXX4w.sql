CREATE FUNCTION get_table_location_id(myschema text, mytable text) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE
	theidtablelocation int;
BEGIN
--Retrouver dans gn_commons.bib_tables_location l'id (PK) de la table passée en paramètre
  SELECT INTO theidtablelocation id_table_location FROM gn_commons.bib_tables_location
	WHERE "schema_name" = myschema AND "table_name" = mytable;
  RETURN theidtablelocation;
END;
$$;

ALTER FUNCTION get_table_location_id(TEXT, TEXT) OWNER TO fcloitre;

