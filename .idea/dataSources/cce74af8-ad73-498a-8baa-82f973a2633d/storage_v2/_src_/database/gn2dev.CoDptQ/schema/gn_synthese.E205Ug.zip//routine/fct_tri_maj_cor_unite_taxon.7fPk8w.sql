CREATE FUNCTION fct_tri_maj_cor_unite_taxon() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE the_cd_nom integer;
BEGIN
    SELECT cd_nom INTO the_cd_nom FROM gn_synthese.synthese WHERE id_synthese = NEW.id_synthese;
  -- on supprime cor_area_taxon et recree à chaque fois
    -- cela evite de regarder dans cor_area_taxon s'il y a deja une ligne, de faire un + 1  ou -1 sur nb_obs etc...
    IF (TG_OP = 'INSERT') THEN
      DELETE FROM gn_synthese.cor_area_taxon WHERE cd_nom = the_cd_nom AND id_area IN (NEW.id_area);
    ELSE
      DELETE FROM gn_synthese.cor_area_taxon WHERE cd_nom = the_cd_nom AND id_area IN (NEW.id_area, OLD.id_area);
    END IF;
    -- puis on réinsert
    -- on récupère la dernière date de l'obs dans l'aire concernée depuis cor_area_synthese et synthese
    INSERT INTO gn_synthese.cor_area_taxon (id_area, cd_nom, last_date, nb_obs)
    SELECT id_area, s.cd_nom,  max(s.date_min) AS last_date, count(s.id_synthese) AS nb_obs
    FROM gn_synthese.cor_area_synthese cor
    JOIN gn_synthese.synthese s ON s.id_synthese = cor.id_synthese
    WHERE s.cd_nom = the_cd_nom AND id_area = NEW.id_area
    GROUP BY id_area, s.cd_nom;
    RETURN NULL;
END;
$$;

ALTER FUNCTION fct_tri_maj_cor_unite_taxon() OWNER TO fcloitre;

