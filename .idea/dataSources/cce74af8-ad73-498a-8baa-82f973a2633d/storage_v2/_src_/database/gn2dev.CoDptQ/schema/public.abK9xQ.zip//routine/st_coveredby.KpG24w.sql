CREATE FUNCTION st_coveredby(geography, geography) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Covers($2, $1)
$$;

COMMENT ON FUNCTION st_coveredby(GEOGRAPHY, GEOGRAPHY) IS 'args: geogA, geogB - Returns 1 (TRUE) if no point in Geometry/Geography A is outside Geometry/Geography B';

ALTER FUNCTION st_coveredby(GEOGRAPHY, GEOGRAPHY) OWNER TO postgres;

