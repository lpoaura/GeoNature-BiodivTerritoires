CREATE FUNCTION check_is_default_group_for_app_is_grp_and_unique(id_app integer, id_grp integer, is_default boolean) RETURNS boolean
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
BEGIN
    -- Fonction de vérification
    -- Test : si le role est un groupe et qu'il n'y a qu'un seul groupe par défaut définit par application
    IF is_default IS TRUE THEN
        IF (
            SELECT DISTINCT TRUE
            FROM utilisateurs.cor_role_app_profil
            WHERE id_application = id_app AND is_default_group_for_app IS TRUE
        ) IS TRUE THEN
            RETURN FALSE;
        ELSIF (SELECT TRUE FROM utilisateurs.t_roles WHERE id_role = id_grp AND groupe IS TRUE) IS NULL THEN
            RETURN FALSE;
        ELSE
          RETURN TRUE;
        END IF;
    END IF;
    RETURN TRUE;
  END
$$;

ALTER FUNCTION check_is_default_group_for_app_is_grp_and_unique(INTEGER, INTEGER, BOOLEAN) OWNER TO fcloitre;

