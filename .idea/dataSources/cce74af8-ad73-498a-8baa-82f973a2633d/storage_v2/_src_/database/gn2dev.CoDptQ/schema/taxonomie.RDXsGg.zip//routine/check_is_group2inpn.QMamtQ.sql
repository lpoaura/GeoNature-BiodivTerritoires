CREATE FUNCTION check_is_group2inpn(mygroup text) RETURNS boolean
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--fonction permettant de vérifier si un texte proposé correspond à un group2_inpn dans la table taxref
  BEGIN
    IF mygroup IN(SELECT group2_inpn FROM taxonomie.vm_group2_inpn) OR mygroup IS NULL THEN
      RETURN true;
    ELSE
      RETURN false;
    END IF;
  END;
$$;

ALTER FUNCTION check_is_group2inpn(TEXT) OWNER TO fcloitre;

