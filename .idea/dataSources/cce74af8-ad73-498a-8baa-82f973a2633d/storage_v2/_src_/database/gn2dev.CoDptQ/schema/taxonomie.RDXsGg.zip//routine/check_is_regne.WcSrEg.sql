CREATE FUNCTION check_is_regne(myregne text) RETURNS boolean
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--fonction permettant de vérifier si un texte proposé correspond à un regne dans la table taxref
  BEGIN
    IF myregne IN(SELECT regne FROM taxonomie.vm_regne) OR myregne IS NULL THEN
      return true;
    ELSE
      RETURN false;
    END IF;
  END;
$$;

ALTER FUNCTION check_is_regne(TEXT) OWNER TO fcloitre;

