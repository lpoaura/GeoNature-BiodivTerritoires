CREATE VIEW v_taxref_all_listes
            ( regne, phylum, classe, ordre, famille, group1_inpn, group2_inpn, cd_nom, cd_ref, nom_complet, nom_valide
            , nom_vern, lb_nom, id_liste)
AS
WITH
    bib_nom_lst AS (
        SELECT
            cor_nom_liste.id_nom
          , bib_noms.cd_nom
          , bib_noms.nom_francais
          , cor_nom_liste.id_liste
        FROM
            taxonomie.cor_nom_liste
                JOIN taxonomie.bib_noms USING (id_nom)
    )
SELECT
    t.regne
  , t.phylum
  , t.classe
  , t.ordre
  , t.famille
  , t.group1_inpn
  , t.group2_inpn
  , t.cd_nom
  , t.cd_ref
  , t.nom_complet
  , t.nom_valide
  , d.nom_francais AS nom_vern
  , t.lb_nom
  , d.id_liste
FROM
    taxonomie.taxref t
        JOIN bib_nom_lst d ON t.cd_nom = d.cd_nom;

ALTER TABLE v_taxref_all_listes
    OWNER TO fcloitre;

