CREATE FUNCTION fct_get_altitude_intersection(mygeom geometry)
    RETURNS TABLE(altitude_min integer, altitude_max integer)
    LANGUAGE plpgsql
AS
$$
DECLARE
    thesrid int;
    is_vectorized int;
BEGIN
  SELECT gn_commons.get_default_parameter('local_srid', NULL) INTO thesrid;
  SELECT COALESCE(gid, NULL) FROM ref_geo.dem_vector LIMIT 1 INTO is_vectorized;
	
  IF is_vectorized IS NULL THEN
    -- Use dem
    RETURN QUERY
    SELECT min((altitude).val)::integer AS altitude_min, max((altitude).val)::integer AS altitude_max
    FROM (
	SELECT public.ST_DumpAsPolygons(public.ST_clip(
    rast, 
    1,
	  public.st_transform(myGeom,thesrid), 
    true)
  ) AS altitude
	FROM ref_geo.dem AS altitude 
	WHERE public.st_intersects(rast,public.st_transform(myGeom,thesrid))
    ) AS a;		
  -- Use dem_vector
  ELSE
    RETURN QUERY
    WITH d  as (
        SELECT public.st_transform(myGeom,thesrid) a
     )
    SELECT min(val)::int as altitude_min, max(val)::int as altitude_max
    FROM ref_geo.dem_vector, d
    WHERE public.st_intersects(a,geom);
  END IF;
END;
$$;

ALTER FUNCTION fct_get_altitude_intersection(GEOMETRY) OWNER TO fcloitre;

