CREATE FUNCTION st_band(rast raster, nband integer) RETURNS raster
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT  public.ST_band($1, ARRAY[$2])
$$;

COMMENT ON FUNCTION st_band(RASTER, INTEGER) IS 'args: rast, nband - Returns one or more bands of an existing raster as a new raster. Useful for building new rasters from existing rasters.';

ALTER FUNCTION st_band(RASTER, INTEGER) OWNER TO postgres;

