CREATE FUNCTION get_default_nomenclature_value(mytype character varying, myidorganism integer DEFAULT 0) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
    --Function that return the default nomenclature id with wanted nomenclature type (mnemonique), organism id
--Return -1 if nothing matches with given parameters
  DECLARE
    thenomenclatureid integer;
  BEGIN
      SELECT INTO thenomenclatureid id_nomenclature
      FROM ref_nomenclatures.defaults_nomenclatures_value
      WHERE mnemonique_type = mytype
      AND (id_organism = myidorganism OR id_organism = 0)
      ORDER BY id_organism DESC LIMIT 1;
    IF (thenomenclatureid IS NOT NULL) THEN
      RETURN thenomenclatureid;
    END IF;
    RETURN -1;
  END;
$$;

ALTER FUNCTION get_default_nomenclature_value(VARCHAR, INTEGER) OWNER TO fcloitre;

