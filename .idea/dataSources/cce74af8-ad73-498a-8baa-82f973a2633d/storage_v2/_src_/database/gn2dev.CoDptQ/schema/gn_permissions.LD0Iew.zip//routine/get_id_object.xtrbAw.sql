CREATE FUNCTION get_id_object(mycodeobject character varying) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
BEGIN
RETURN (SELECT id_object
FROM gn_permissions.t_objects
WHERE code_object = mycodeobject);
END;
$$;

ALTER FUNCTION get_id_object(VARCHAR) OWNER TO fcloitre;

