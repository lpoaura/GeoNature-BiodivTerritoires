CREATE FUNCTION st_askml(geom geometry, maxdecimaldigits integer DEFAULT 15) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_AsKML(2, ST_Transform($1,4326), $2, null);
$$;

COMMENT ON FUNCTION st_askml(GEOMETRY, INTEGER) IS 'args: geom, maxdecimaldigits=15 - Return the geometry as a KML element. Several variants. Default version=2, default maxdecimaldigits=15';

ALTER FUNCTION st_askml(GEOMETRY, INTEGER) OWNER TO postgres;

