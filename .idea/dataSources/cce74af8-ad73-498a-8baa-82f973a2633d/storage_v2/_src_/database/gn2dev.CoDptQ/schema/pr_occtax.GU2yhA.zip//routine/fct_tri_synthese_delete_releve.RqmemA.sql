CREATE FUNCTION fct_tri_synthese_delete_releve() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
BEGIN
    DELETE FROM gn_synthese.synthese WHERE unique_id_sinp IN (
      SELECT unnest(pr_occtax.get_unique_id_sinp_from_id_releve(OLD.id_releve_occtax::integer))
    );
  RETURN OLD;
END;
$$;

ALTER FUNCTION fct_tri_synthese_delete_releve() OWNER TO fcloitre;

