CREATE VIEW v_statut_obs (regne, group2_inpn, id_nomenclature, mnemonique, label, definition, id_broader, hierarchy) AS
SELECT
    ctn.regne
  , ctn.group2_inpn
  , n.id_nomenclature
  , n.mnemonique
  , n.label_default      AS label
  , n.definition_default AS definition
  , n.id_broader
  , n.hierarchy
FROM
    ref_nomenclatures.t_nomenclatures n
        LEFT JOIN ref_nomenclatures.cor_taxref_nomenclature ctn ON ctn.id_nomenclature = n.id_nomenclature
        LEFT JOIN ref_nomenclatures.bib_nomenclatures_types t ON t.id_type = n.id_type
WHERE
    t.mnemonique::TEXT = 'STATUT_OBS'::TEXT AND
    n.active = TRUE;

ALTER TABLE v_statut_obs
    OWNER TO fcloitre;

