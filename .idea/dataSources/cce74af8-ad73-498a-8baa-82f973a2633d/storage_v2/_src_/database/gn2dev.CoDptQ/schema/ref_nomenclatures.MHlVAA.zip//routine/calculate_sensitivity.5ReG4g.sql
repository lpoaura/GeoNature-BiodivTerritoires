CREATE FUNCTION calculate_sensitivity(mycdnom integer, mynomenclatureid integer) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
    --Function to return id_nomenclature depending on observation sensitivity
  --USAGE : SELECT ref_nomenclatures.calculate_sensitivity(240,21);
  DECLARE
  sensitivityid integer;
  BEGIN
    SELECT max(id_nomenclature_niv_precis) INTO sensitivityid
    FROM ref_nomenclatures.cor_taxref_sensitivity
    WHERE cd_nom = mycdnom
    AND (id_nomenclature = mynomenclatureid OR id_nomenclature = 0);
  IF sensitivityid IS NULL THEN
    sensitivityid = ref_nomenclatures.get_id_nomenclature('NIV_PRECIS', '5');
  END IF;
  RETURN sensitivityid;
  END;
$$;

ALTER FUNCTION calculate_sensitivity(INTEGER, INTEGER) OWNER TO fcloitre;

