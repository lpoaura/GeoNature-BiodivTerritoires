CREATE VIEW v_taxref_hierarchie_bibtaxons
            ( regne, phylum, classe, ordre, famille, cd_nom, cd_ref, lb_nom, id_rang, nb_tx_fm, nb_tx_or, nb_tx_cl
            , nb_tx_ph, nb_tx_kd)
AS
WITH
    mestaxons AS (
        SELECT
            tx_1.cd_nom
          , tx_1.id_statut
          , tx_1.id_habitat
          , tx_1.id_rang
          , tx_1.regne
          , tx_1.phylum
          , tx_1.classe
          , tx_1.ordre
          , tx_1.famille
          , tx_1.cd_taxsup
          , tx_1.cd_sup
          , tx_1.cd_ref
          , tx_1.lb_nom
          , tx_1.lb_auteur
          , tx_1.nom_complet
          , tx_1.nom_complet_html
          , tx_1.nom_valide
          , tx_1.nom_vern
          , tx_1.nom_vern_eng
          , tx_1.group1_inpn
          , tx_1.group2_inpn
        FROM
            taxonomie.taxref tx_1
                JOIN taxonomie.bib_noms t ON t.cd_nom = tx_1.cd_nom
    )
SELECT DISTINCT
    tx.regne
  , tx.phylum
  , tx.classe
  , tx.ordre
  , tx.famille
  , tx.cd_nom
  , tx.cd_ref
  , tx.lb_nom
  , btrim(tx.id_rang::TEXT) AS id_rang
  , f.nb_tx_fm
  , o.nb_tx_or
  , c.nb_tx_cl
  , p.nb_tx_ph
  , r.nb_tx_kd
FROM
    taxonomie.taxref tx
        JOIN (SELECT DISTINCT
                  tx_1.regne
                , tx_1.phylum
                , tx_1.classe
                , tx_1.ordre
                , tx_1.famille
              FROM mestaxons tx_1) a ON a.regne::TEXT = tx.regne::TEXT AND tx.id_rang::TEXT = 'KD'::TEXT OR
                                        a.phylum::TEXT = tx.phylum::TEXT AND tx.id_rang::TEXT = 'PH'::TEXT OR
                                        a.classe::TEXT = tx.classe::TEXT AND tx.id_rang::TEXT = 'CL'::TEXT OR
                                        a.ordre::TEXT = tx.ordre::TEXT AND tx.id_rang::TEXT = 'OR'::TEXT OR
                                        a.famille::TEXT = tx.famille::TEXT AND tx.id_rang::TEXT = 'FM'::TEXT
        LEFT JOIN (SELECT
                       mestaxons.famille
                     , count(*) AS nb_tx_fm
                   FROM mestaxons
                   WHERE mestaxons.id_rang::TEXT <> 'FM'::TEXT
                   GROUP BY mestaxons.famille) f ON f.famille::TEXT = tx.famille::TEXT
        LEFT JOIN (SELECT
                       mestaxons.ordre
                     , count(*) AS nb_tx_or
                   FROM mestaxons
                   WHERE mestaxons.id_rang::TEXT <> 'OR'::TEXT
                   GROUP BY mestaxons.ordre) o ON o.ordre::TEXT = tx.ordre::TEXT
        LEFT JOIN (SELECT
                       mestaxons.classe
                     , count(*) AS nb_tx_cl
                   FROM mestaxons
                   WHERE mestaxons.id_rang::TEXT <> 'CL'::TEXT
                   GROUP BY mestaxons.classe) c ON c.classe::TEXT = tx.classe::TEXT
        LEFT JOIN (SELECT
                       mestaxons.phylum
                     , count(*) AS nb_tx_ph
                   FROM mestaxons
                   WHERE mestaxons.id_rang::TEXT <> 'PH'::TEXT
                   GROUP BY mestaxons.phylum) p ON p.phylum::TEXT = tx.phylum::TEXT
        LEFT JOIN (SELECT
                       mestaxons.regne
                     , count(*) AS nb_tx_kd
                   FROM mestaxons
                   WHERE mestaxons.id_rang::TEXT <> 'KD'::TEXT
                   GROUP BY mestaxons.regne) r ON r.regne::TEXT = tx.regne::TEXT
WHERE
    (tx.id_rang::TEXT = ANY
     (ARRAY ['KD'::CHARACTER VARYING::TEXT, 'PH'::CHARACTER VARYING::TEXT, 'CL'::CHARACTER VARYING::TEXT, 'OR'::CHARACTER VARYING::TEXT, 'FM'::CHARACTER VARYING::TEXT])) AND
    tx.cd_nom = tx.cd_ref;

ALTER TABLE v_taxref_hierarchie_bibtaxons
    OWNER TO fcloitre;

