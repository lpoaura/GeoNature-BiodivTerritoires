CREATE FUNCTION fct_trg_refresh_taxons_forautocomplete() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
  thenomvern VARCHAR;
  BEGIN
    IF TG_OP in ('DELETE', 'TRUNCATE', 'UPDATE') AND OLD.cd_nom NOT IN (SELECT DISTINCT cd_nom FROM gn_synthese.synthese) THEN
        DELETE FROM gn_synthese.taxons_synthese_autocomplete auto
        WHERE auto.cd_nom = OLD.cd_nom;
    END IF;

    IF TG_OP in ('INSERT', 'UPDATE') AND NEW.cd_nom NOT IN (SELECT DISTINCT cd_nom FROM gn_synthese.taxons_synthese_autocomplete) THEN
      INSERT INTO gn_synthese.taxons_synthese_autocomplete
      SELECT t.cd_nom,
              t.cd_ref,
          concat(t.lb_nom, ' = <i>', t.nom_valide, '</i>', ' - [', t.id_rang, ' - ', t.cd_nom , ']') AS search_name,
          t.nom_valide,
          t.lb_nom,
          t.regne,
          t.group2_inpn
      FROM taxonomie.taxref t WHERE cd_nom = NEW.cd_nom;
      --On insère une seule fois le nom_vern car il est le même pour tous les synonymes
      SELECT INTO thenomvern t.cd_nom 
      FROM gn_synthese.taxons_synthese_autocomplete a
      JOIN taxonomie.taxref t ON t.cd_nom = a.cd_nom
      WHERE a.cd_ref = taxonomie.find_cdref(NEW.cd_nom)
      AND a.search_name ILIKE t.nom_vern||'%';
      IF thenomvern IS NULL THEN
        INSERT INTO gn_synthese.taxons_synthese_autocomplete
        SELECT t.cd_nom,
          t.cd_ref,
          concat(t.nom_vern, ' =  <i> ', t.nom_valide, '</i>', ' - [', t.id_rang, ' - ', t.cd_nom , ']' ) AS search_name,
          t.nom_valide,
          t.lb_nom,
          t.regne,
          t.group2_inpn
        FROM taxonomie.taxref t WHERE t.nom_vern IS NOT NULL AND cd_nom = NEW.cd_nom;
      END IF;
    END IF;
  RETURN NULL;
  END;
$$;

ALTER FUNCTION fct_trg_refresh_taxons_forautocomplete() OWNER TO fcloitre;

