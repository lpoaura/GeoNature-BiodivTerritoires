CREATE FUNCTION get_id_module_bycode(mymodule text) RETURNS integer
    LANGUAGE plpgsql
AS
$$
DECLARE
	theidmodule integer;
BEGIN
  --Retrouver l'id du module par son code
  SELECT INTO theidmodule id_module FROM gn_commons.t_modules
	WHERE "module_code" ILIKE mymodule;
  RETURN theidmodule;
END;
$$;

ALTER FUNCTION get_id_module_bycode(TEXT) OWNER TO fcloitre;

