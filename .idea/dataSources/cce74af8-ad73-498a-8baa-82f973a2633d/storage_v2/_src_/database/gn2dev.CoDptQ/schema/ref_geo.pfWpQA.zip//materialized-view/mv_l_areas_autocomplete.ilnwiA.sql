CREATE MATERIALIZED VIEW mv_l_areas_autocomplete AS
SELECT DISTINCT
    l_areas.id_area                          AS id
  , bib_areas_types.type_name
  , lower(unaccent(l_areas.area_name::TEXT)) AS search_area_name
  , bib_areas_types.type_desc
  , bib_areas_types.type_code
  , l_areas.area_name
  , l_areas.area_code
FROM
    ref_geo.bib_areas_types
        LEFT JOIN ref_geo.l_areas ON l_areas.id_type = bib_areas_types.id_type
        JOIN gn_synthese.cor_area_synthese USING (id_area)
        JOIN gn_biodivterritory.l_areas_type_selection ON l_areas.id_type = l_areas_type_selection.id_type
WHERE
    cor_area_synthese.id_area IS NOT NULL;

ALTER MATERIALIZED VIEW mv_l_areas_autocomplete OWNER TO fcloitre;

