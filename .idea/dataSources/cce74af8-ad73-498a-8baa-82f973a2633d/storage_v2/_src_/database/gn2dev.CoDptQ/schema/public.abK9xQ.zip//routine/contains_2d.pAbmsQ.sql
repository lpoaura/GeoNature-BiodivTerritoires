CREATE FUNCTION contains_2d(geometry, box2df) RETURNS boolean
    IMMUTABLE
    STRICT
    LANGUAGE SQL
AS
$$
SELECT $2 OPERATOR(public.@) $1;
$$;

ALTER FUNCTION contains_2d(GEOMETRY, BOX2DF) OWNER TO postgres;

