CREATE FUNCTION st_pixelaspolygon(rast raster, x integer, y integer) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT geom FROM public._ST_pixelaspolygons($1, NULL, $2, $3)
$$;

COMMENT ON FUNCTION st_pixelaspolygon(RASTER, INTEGER, INTEGER) IS 'args: rast, columnx, rowy - Returns the polygon geometry that bounds the pixel for a particular row and column.';

ALTER FUNCTION st_pixelaspolygon(RASTER, INTEGER, INTEGER) OWNER TO postgres;

