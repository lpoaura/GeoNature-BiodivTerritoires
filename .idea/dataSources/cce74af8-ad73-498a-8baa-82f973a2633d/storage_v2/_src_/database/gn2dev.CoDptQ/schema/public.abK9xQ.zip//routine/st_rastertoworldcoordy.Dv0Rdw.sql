CREATE FUNCTION st_rastertoworldcoordy(rast raster, yr integer) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT latitude FROM public._ST_rastertoworldcoord($1, NULL, $2)
$$;

COMMENT ON FUNCTION st_rastertoworldcoordy(RASTER, INTEGER) IS 'args: rast, yrow - Returns the geometric Y coordinate upper left corner of a raster, column and row. Numbering of columns and rows starts at 1.';

ALTER FUNCTION st_rastertoworldcoordy(RASTER, INTEGER) OWNER TO postgres;

