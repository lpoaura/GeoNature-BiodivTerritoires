CREATE FUNCTION st_polygonfromtext(text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.ST_PolyFromText($1)
$$;

COMMENT ON FUNCTION st_polygonfromtext(TEXT) IS 'args: WKT - Makes a Geometry from WKT with the given SRID. If SRID is not given, it defaults to 0.';

ALTER FUNCTION st_polygonfromtext(TEXT) OWNER TO postgres;

