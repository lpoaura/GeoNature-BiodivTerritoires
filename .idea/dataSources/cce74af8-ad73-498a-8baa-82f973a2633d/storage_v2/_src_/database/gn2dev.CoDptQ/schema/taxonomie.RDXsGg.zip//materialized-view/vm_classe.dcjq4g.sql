CREATE MATERIALIZED VIEW vm_classe AS
SELECT DISTINCT tx.classe
FROM taxonomie.taxref tx;

ALTER MATERIALIZED VIEW vm_classe OWNER TO fcloitre;

CREATE UNIQUE INDEX i_unique_classe
    ON vm_classe(classe);

