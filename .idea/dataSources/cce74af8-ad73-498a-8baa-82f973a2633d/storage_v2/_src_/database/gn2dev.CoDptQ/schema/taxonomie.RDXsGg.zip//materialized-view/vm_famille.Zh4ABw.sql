CREATE MATERIALIZED VIEW vm_famille AS
SELECT DISTINCT tx.famille
FROM taxonomie.taxref tx;

ALTER MATERIALIZED VIEW vm_famille OWNER TO fcloitre;

CREATE UNIQUE INDEX i_unique_famille
    ON vm_famille(famille);

