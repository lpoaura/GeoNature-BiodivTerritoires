CREATE FUNCTION id_releve_from_id_counting(my_id_counting integer) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
-- Function which return the id_countings in an array (table pr_occtax.cor_counting_occtax) from the id_releve(integer)
DECLARE the_id_releve integer;
BEGIN
  SELECT INTO the_id_releve rel.id_releve_occtax
  FROM pr_occtax.t_releves_occtax rel
  JOIN pr_occtax.t_occurrences_occtax occ ON occ.id_releve_occtax = rel.id_releve_occtax
  JOIN pr_occtax.cor_counting_occtax counting ON counting.id_occurrence_occtax = occ.id_occurrence_occtax
  WHERE counting.id_counting_occtax = my_id_counting;
  RETURN the_id_releve;
END;
$$;

ALTER FUNCTION id_releve_from_id_counting(INTEGER) OWNER TO fcloitre;

