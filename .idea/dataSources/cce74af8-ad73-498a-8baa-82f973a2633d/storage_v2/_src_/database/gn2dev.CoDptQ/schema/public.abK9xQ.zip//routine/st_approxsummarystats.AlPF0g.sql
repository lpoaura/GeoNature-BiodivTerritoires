CREATE FUNCTION st_approxsummarystats(rast raster, exclude_nodata_value boolean, sample_percent double precision DEFAULT 0.1) RETURNS summarystats
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_summarystats($1, 1, $2, $3)
$$;

ALTER FUNCTION st_approxsummarystats(RASTER, BOOLEAN, DOUBLE PRECISION) OWNER TO postgres;

