CREATE FUNCTION st_dumpvalues(rast raster, nband integer, exclude_nodata_value boolean DEFAULT true) RETURNS double precision[]
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT valarray FROM public.ST_dumpvalues($1, ARRAY[$2]::integer[], $3)
$$;

COMMENT ON FUNCTION st_dumpvalues(RASTER, INTEGER, BOOLEAN) IS 'args: rast, nband, exclude_nodata_value=true - Get the values of the specified band as a 2-dimension array.';

ALTER FUNCTION st_dumpvalues(RASTER, INTEGER, BOOLEAN) OWNER TO postgres;

