CREATE FUNCTION get_id_nomenclature(mytype character varying, mycdnomenclature character varying) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--Function which return the id_nomenclature from an mnemonique_type and an cd_nomenclature
DECLARE theidnomenclature integer;
  BEGIN
SELECT INTO theidnomenclature id_nomenclature
FROM ref_nomenclatures.t_nomenclatures n
WHERE n.id_type = ref_nomenclatures.get_id_nomenclature_type(mytype) AND mycdnomenclature = n.cd_nomenclature;
return theidnomenclature;
  END;
$$;

ALTER FUNCTION get_id_nomenclature(VARCHAR, VARCHAR) OWNER TO fcloitre;

