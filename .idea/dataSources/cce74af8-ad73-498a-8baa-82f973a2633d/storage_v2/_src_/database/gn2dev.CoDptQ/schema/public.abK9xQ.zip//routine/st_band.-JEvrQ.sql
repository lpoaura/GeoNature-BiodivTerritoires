CREATE FUNCTION st_band(rast raster, nbands text, delimiter character DEFAULT ','::bpchar) RETURNS raster
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT  public.ST_band($1, regexp_split_to_array(regexp_replace($2, '[[:space:]]', '', 'g'), E'\\' || array_to_string(regexp_split_to_array($3, ''), E'\\'))::int[])
$$;

COMMENT ON FUNCTION st_band(RASTER, TEXT, CHAR) IS 'args: rast, nbands, delimiter=, - Returns one or more bands of an existing raster as a new raster. Useful for building new rasters from existing rasters.';

ALTER FUNCTION st_band(RASTER, TEXT, CHAR) OWNER TO postgres;

