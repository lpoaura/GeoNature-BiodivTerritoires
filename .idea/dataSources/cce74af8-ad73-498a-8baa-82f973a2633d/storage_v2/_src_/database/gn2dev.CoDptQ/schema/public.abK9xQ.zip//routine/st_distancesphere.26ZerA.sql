CREATE FUNCTION st_distancesphere(geom1 geometry, geom2 geometry) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 300
    LANGUAGE SQL
AS
$$
select public.ST_distance( public.geography($1), public.geography($2),false)

$$;

COMMENT ON FUNCTION st_distancesphere(GEOMETRY, GEOMETRY) IS 'args: geomlonlatA, geomlonlatB - Returns minimum distance in meters between two lon/lat geometries. Uses a spherical earth and radius derived from the spheroid defined by the SRID. Faster than ST_DistanceSpheroid , but less accurate. PostGIS versions prior to 1.5 only implemented for points.';

ALTER FUNCTION st_distancesphere(GEOMETRY, GEOMETRY) OWNER TO postgres;

