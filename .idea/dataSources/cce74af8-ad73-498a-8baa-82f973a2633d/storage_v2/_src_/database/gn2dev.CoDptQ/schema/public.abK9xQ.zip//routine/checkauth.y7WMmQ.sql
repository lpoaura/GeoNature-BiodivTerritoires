CREATE FUNCTION checkauth(text, text) RETURNS integer
    LANGUAGE SQL
AS
$$
SELECT CheckAuth('', $1, $2)
$$;

COMMENT ON FUNCTION checkauth(TEXT, TEXT) IS 'args: a_table_name, a_key_column_name - Creates trigger on a table to prevent/allow updates and deletes of rows based on authorization token.';

ALTER FUNCTION checkauth(TEXT, TEXT) OWNER TO postgres;

