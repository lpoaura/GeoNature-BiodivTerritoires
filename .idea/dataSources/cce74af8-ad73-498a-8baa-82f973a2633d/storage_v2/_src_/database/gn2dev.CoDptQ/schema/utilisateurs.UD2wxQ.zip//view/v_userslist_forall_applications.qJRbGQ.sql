CREATE VIEW v_userslist_forall_applications
            ( groupe, active, id_role, identifiant, nom_role, prenom_role, desc_role, pass, pass_plus, email
            , id_organisme, organisme, id_unite, remarques, date_insert, date_update, id_droit_max, id_application)
AS
SELECT
    v_roleslist_forall_applications.groupe
  , v_roleslist_forall_applications.active
  , v_roleslist_forall_applications.id_role
  , v_roleslist_forall_applications.identifiant
  , v_roleslist_forall_applications.nom_role
  , v_roleslist_forall_applications.prenom_role
  , v_roleslist_forall_applications.desc_role
  , v_roleslist_forall_applications.pass
  , v_roleslist_forall_applications.pass_plus
  , v_roleslist_forall_applications.email
  , v_roleslist_forall_applications.id_organisme
  , v_roleslist_forall_applications.organisme
  , v_roleslist_forall_applications.id_unite
  , v_roleslist_forall_applications.remarques
  , v_roleslist_forall_applications.date_insert
  , v_roleslist_forall_applications.date_update
  , v_roleslist_forall_applications.id_droit_max
  , v_roleslist_forall_applications.id_application
FROM utilisateurs.v_roleslist_forall_applications
WHERE
    v_roleslist_forall_applications.groupe = FALSE;

ALTER TABLE v_userslist_forall_applications
    OWNER TO fcloitre;

