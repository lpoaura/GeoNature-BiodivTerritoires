CREATE FUNCTION raster_geometry_overlap(raster, geometry) RETURNS boolean
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
select $1::public.geometry OPERATOR(public.&&) $2
$$;

ALTER FUNCTION raster_geometry_overlap(RASTER, GEOMETRY) OWNER TO postgres;

