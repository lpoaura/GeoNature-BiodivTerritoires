CREATE FUNCTION raster_contained_by_geometry(raster, geometry) RETURNS boolean
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
select $1::public.geometry OPERATOR(public.@) $2
$$;

ALTER FUNCTION raster_contained_by_geometry(RASTER, GEOMETRY) OWNER TO postgres;

