CREATE FUNCTION st_askml(version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, nprefix text DEFAULT NULL::text) RETURNS text
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_AsKML($1, public.ST_Transform($2,4326), $3, $4);
$$;

COMMENT ON FUNCTION st_askml(INTEGER, GEOMETRY, INTEGER, TEXT) IS 'args: version, geom, maxdecimaldigits=15, nprefix=NULL - Return the geometry as a KML element. Several variants. Default version=2, default maxdecimaldigits=15';

ALTER FUNCTION st_askml(INTEGER, GEOMETRY, INTEGER, TEXT) OWNER TO postgres;

