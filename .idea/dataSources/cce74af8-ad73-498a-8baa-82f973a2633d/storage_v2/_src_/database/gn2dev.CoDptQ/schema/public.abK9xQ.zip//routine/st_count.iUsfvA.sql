CREATE FUNCTION st_count(rast raster, exclude_nodata_value boolean) RETURNS bigint
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_count($1, 1, $2, 1)
$$;

COMMENT ON FUNCTION st_count(RASTER, BOOLEAN) IS 'args: rast, exclude_nodata_value - Returns the number of pixels in a given band of a raster or raster coverage. If no band is specified defaults to band 1. If exclude_nodata_value is set to true, will only count pixels that are not equal to the nodata value.';

ALTER FUNCTION st_count(RASTER, BOOLEAN) OWNER TO postgres;

