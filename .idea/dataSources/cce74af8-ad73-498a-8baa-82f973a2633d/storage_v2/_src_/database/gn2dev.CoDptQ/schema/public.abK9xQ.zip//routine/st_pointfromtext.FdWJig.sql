CREATE FUNCTION st_pointfromtext(text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'POINT'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END

$$;

COMMENT ON FUNCTION st_pointfromtext(TEXT) IS 'args: WKT - Makes a point Geometry from WKT with the given SRID. If SRID is not given, it defaults to unknown.';

ALTER FUNCTION st_pointfromtext(TEXT) OWNER TO postgres;

