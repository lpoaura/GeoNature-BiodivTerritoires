CREATE FUNCTION st_geomfromgeohash(text, integer DEFAULT NULL::integer) RETURNS geometry
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT CAST(public.ST_Box2dFromGeoHash($1, $2) AS geometry);
$$;

COMMENT ON FUNCTION st_geomfromgeohash(TEXT, INTEGER) IS 'args: geohash, precision=full_precision_of_geohash - Return a geometry from a GeoHash string.';

ALTER FUNCTION st_geomfromgeohash(TEXT, INTEGER) OWNER TO postgres;

