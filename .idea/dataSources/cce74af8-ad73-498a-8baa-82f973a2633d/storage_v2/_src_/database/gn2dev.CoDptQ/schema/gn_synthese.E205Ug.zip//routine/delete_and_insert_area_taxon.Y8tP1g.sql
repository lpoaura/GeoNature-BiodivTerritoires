CREATE FUNCTION delete_and_insert_area_taxon(my_cd_nom integer, my_id_area integer[]) RETURNS void
    LANGUAGE plpgsql
AS
$$
BEGIN 
  -- supprime dans cor_area_taxon
  DELETE FROM gn_synthese.cor_area_taxon WHERE cd_nom = my_cd_nom AND id_area = ANY (my_id_area);
  -- réinsertion et calcul
  INSERT INTO gn_synthese.cor_area_taxon (cd_nom, nb_obs, id_area, last_date)
  SELECT s.cd_nom, count(s.id_synthese), cor.id_area,  max(s.date_min)
  FROM gn_synthese.cor_area_synthese cor
  JOIN gn_synthese.synthese s ON s.id_synthese = cor.id_synthese
  WHERE id_area = ANY (my_id_area) AND s.cd_nom = my_cd_nom
  GROUP BY cor.id_area, s.cd_nom;
END;
$$;

ALTER FUNCTION delete_and_insert_area_taxon(INTEGER, INTEGER[]) OWNER TO fcloitre;

