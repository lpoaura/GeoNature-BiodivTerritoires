CREATE FUNCTION st_intersects(geography, geography) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Distance($1, $2, 0.0, false) < 0.00001
$$;

COMMENT ON FUNCTION st_intersects(GEOGRAPHY, GEOGRAPHY) IS 'args: geogA, geogB - Returns TRUE if the Geometries/Geography "spatially intersect in 2D" - (share any portion of space) and FALSE if they dont (they are Disjoint). For geography -- tolerance is 0.00001 meters (so any points that close are considered to intersect)';

ALTER FUNCTION st_intersects(GEOGRAPHY, GEOGRAPHY) OWNER TO postgres;

