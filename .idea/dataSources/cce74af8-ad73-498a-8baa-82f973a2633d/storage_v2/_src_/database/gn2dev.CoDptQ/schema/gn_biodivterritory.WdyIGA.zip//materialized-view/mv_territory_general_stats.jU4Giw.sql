CREATE MATERIALIZED VIEW mv_territory_general_stats AS
SELECT
    l_areas.id_area
  , bib_areas_types.type_code
  , l_areas.area_code
  , l_areas.area_name
  , count(DISTINCT synthese.cd_nom)                                                                       AS count_taxa
  , count(DISTINCT synthese.id_synthese)                                                                  AS count_occtax
  , count(DISTINCT synthese.cd_nom) FILTER (WHERE bib_redlist_categories.threatened AND
                                                  bib_redlist_source.area_code::TEXT ~~ 'FR'::TEXT)       AS count_threatened
  , count(DISTINCT synthese.id_dataset)                                                                   AS count_dataset
  , count(DISTINCT synthese.date_min)                                                                     AS count_date
  , count(DISTINCT synthese.observers)                                                                    AS count_observer
  , max(synthese.date_min)                                                                                AS last_obs
  , l_areas.geom                                                                                          AS geom_local
  , st_transform(l_areas.geom, 4326)                                                                      AS geom_4326
FROM
    ref_geo.l_areas
        JOIN ref_geo.bib_areas_types ON l_areas.id_type = bib_areas_types.id_type
        JOIN gn_synthese.cor_area_synthese ON l_areas.id_area = cor_area_synthese.id_area
        JOIN gn_synthese.synthese ON cor_area_synthese.id_synthese = synthese.id_synthese
        JOIN taxonomie.taxref ON synthese.cd_nom = taxref.cd_nom
        LEFT JOIN taxonomie.t_redlist ON taxref.cd_nom = t_redlist.cd_nom
        JOIN taxonomie.bib_redlist_categories ON t_redlist.category = bib_redlist_categories.code_category::BPCHAR
        JOIN taxonomie.bib_redlist_source ON t_redlist.id_source = bib_redlist_source.id_source
GROUP BY
    l_areas.id_area
  , bib_areas_types.type_code
  , l_areas.area_code
  , l_areas.area_name
  , l_areas.geom;

ALTER MATERIALIZED VIEW mv_territory_general_stats OWNER TO fcloitre;

