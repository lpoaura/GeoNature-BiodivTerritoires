CREATE FUNCTION find_cdref(id integer) RETURNS integer
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
    --fonction permettant de renvoyer le cd_ref d'un taxon à partir de son cd_nom
--
--Gil DELUERMOZ septembre 2011

  DECLARE ref integer;
  BEGIN
	SELECT INTO ref cd_ref FROM taxonomie.taxref WHERE cd_nom = id;
	return ref;
  END;
$$;

ALTER FUNCTION find_cdref(INTEGER) OWNER TO fcloitre;

