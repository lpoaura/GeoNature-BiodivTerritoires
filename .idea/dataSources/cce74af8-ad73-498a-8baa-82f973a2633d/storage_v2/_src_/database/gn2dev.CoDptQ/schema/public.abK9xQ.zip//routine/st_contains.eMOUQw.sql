CREATE FUNCTION st_contains(geom1 geometry, geom2 geometry) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.~) $2 AND public._ST_Contains($1,$2)
$$;

COMMENT ON FUNCTION st_contains(GEOMETRY, GEOMETRY) IS 'args: geomA, geomB - Returns true if and only if no points of B lie in the exterior of A, and at least one point of the interior of B lies in the interior of A.';

ALTER FUNCTION st_contains(GEOMETRY, GEOMETRY) OWNER TO postgres;

