CREATE FUNCTION fct_tri_synthese_delete_cor_role_releve() RETURNS trigger
    LANGUAGE plpgsql
AS
$$
DECLARE
  uuids_counting  uuid[];
BEGIN
  -- Récupération des id_counting à partir de l'id_releve
  SELECT INTO uuids_counting pr_occtax.get_unique_id_sinp_from_id_releve(OLD.id_releve_occtax::integer);
  IF uuids_counting IS NOT NULL THEN
      -- Suppression des enregistrements dans cor_observer_synthese
      DELETE FROM gn_synthese.cor_observer_synthese
      WHERE id_role = OLD.id_role 
      AND id_synthese IN (
          SELECT id_synthese 
          FROM gn_synthese.synthese
          WHERE unique_id_sinp IN (SELECT unnest(uuids_counting))
      );
  END IF;
RETURN NULL;
END;
$$;

ALTER FUNCTION fct_tri_synthese_delete_cor_role_releve() OWNER TO fcloitre;

