CREATE FUNCTION st_gmltosql(text) RETURNS geometry
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_GeomFromGML($1, 0)
$$;

COMMENT ON FUNCTION st_gmltosql(TEXT) IS 'args: geomgml - Return a specified ST_Geometry value from GML representation. This is an alias name for ST_GeomFromGML';

ALTER FUNCTION st_gmltosql(TEXT) OWNER TO postgres;

