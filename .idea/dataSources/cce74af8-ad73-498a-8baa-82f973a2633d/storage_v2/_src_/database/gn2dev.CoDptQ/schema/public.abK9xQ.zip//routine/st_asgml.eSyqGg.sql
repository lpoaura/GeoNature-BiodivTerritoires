CREATE FUNCTION st_asgml(version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0, nprefix text DEFAULT NULL::text, id text DEFAULT NULL::text) RETURNS text
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public._ST_AsGML($1, $2, $3, $4, $5, $6);
$$;

COMMENT ON FUNCTION st_asgml(INTEGER, GEOMETRY, INTEGER, INTEGER, TEXT, TEXT) IS 'args: version, geom, maxdecimaldigits=15, options=0, nprefix=null, id=null - Return the geometry as a GML version 2 or 3 element.';

ALTER FUNCTION st_asgml(INTEGER, GEOMETRY, INTEGER, INTEGER, TEXT, TEXT) OWNER TO postgres;

