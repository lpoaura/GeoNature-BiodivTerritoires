CREATE FUNCTION geometry_raster_overlap(geometry, raster) RETURNS boolean
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
select $1 OPERATOR(public.&&) $2::public.geometry
$$;

ALTER FUNCTION geometry_raster_overlap(GEOMETRY, RASTER) OWNER TO postgres;

