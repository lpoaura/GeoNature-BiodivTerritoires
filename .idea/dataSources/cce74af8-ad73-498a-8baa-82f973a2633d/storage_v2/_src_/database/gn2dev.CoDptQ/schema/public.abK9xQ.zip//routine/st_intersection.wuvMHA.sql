CREATE FUNCTION st_intersection(geography, geography) RETURNS geography
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT public.geography(public.ST_Transform(public.ST_Intersection(public.ST_Transform(public.geometry($1), public._ST_BestSRID($1, $2)), public.ST_Transform(public.geometry($2), public._ST_BestSRID($1, $2))), 4326))
$$;

COMMENT ON FUNCTION st_intersection(GEOGRAPHY, GEOGRAPHY) IS 'args: geogA, geogB - (T)Returns a geometry that represents the shared portion of geomA and geomB.';

ALTER FUNCTION st_intersection(GEOGRAPHY, GEOGRAPHY) OWNER TO postgres;

