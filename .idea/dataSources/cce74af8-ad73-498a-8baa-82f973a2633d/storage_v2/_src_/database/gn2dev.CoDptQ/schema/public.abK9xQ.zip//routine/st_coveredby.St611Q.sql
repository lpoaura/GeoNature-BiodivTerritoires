CREATE FUNCTION st_coveredby(geom1 geometry, geom2 geometry) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE SQL
AS
$$
SELECT $1 OPERATOR(public.@) $2 AND public._ST_CoveredBy($1,$2)
$$;

COMMENT ON FUNCTION st_coveredby(GEOMETRY, GEOMETRY) IS 'args: geomA, geomB - Returns 1 (TRUE) if no point in Geometry/Geography A is outside Geometry/Geography B';

ALTER FUNCTION st_coveredby(GEOMETRY, GEOMETRY) OWNER TO postgres;

