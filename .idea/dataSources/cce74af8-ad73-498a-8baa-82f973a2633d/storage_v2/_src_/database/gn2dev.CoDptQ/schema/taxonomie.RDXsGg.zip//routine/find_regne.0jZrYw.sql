CREATE FUNCTION find_regne(mycdnom integer) RETURNS text
    IMMUTABLE
    LANGUAGE plpgsql
AS
$$
--fonction permettant de renvoyer le regne d'un taxon à partir de son cd_nom
  DECLARE theregne character varying(255);
  BEGIN
    SELECT INTO theregne regne FROM taxonomie.taxref WHERE cd_nom = mycdnom;
    return theregne;
  END;
$$;

ALTER FUNCTION find_regne(INTEGER) OWNER TO fcloitre;

