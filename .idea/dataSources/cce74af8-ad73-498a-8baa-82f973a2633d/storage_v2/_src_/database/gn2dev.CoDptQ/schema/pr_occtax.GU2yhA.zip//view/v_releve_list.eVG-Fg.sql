CREATE VIEW v_releve_list
            ( id_releve_occtax, id_dataset, id_digitiser, date_min, date_max, altitude_min, altitude_max
            , meta_device_entry, comment, geom_4326, precision, observers_txt, dataset_name, taxons, leaflet_popup
            , observateurs, nb_occ, nb_observer)
AS
WITH
    occurrences(id_releve_occtax, taxons, nb_occ) AS (
        SELECT
            occ_1.id_releve_occtax
          , string_agg(DISTINCT t.nom_valide::TEXT, ', '::TEXT) AS taxons
          , count(DISTINCT occ_1.id_occurrence_occtax)          AS nb_occ
        FROM
            pr_occtax.t_occurrences_occtax occ_1
                JOIN taxonomie.taxref t ON occ_1.cd_nom = t.cd_nom
        GROUP BY occ_1.id_releve_occtax
    )
  , observateurs(id_releve_occtax, nb_observer, observers_txt) AS (
    SELECT
        cor_role_1.id_releve_occtax
      , count(DISTINCT obs.id_role) AS nb_observer
      , string_agg(DISTINCT
                   concat_ws(' '::TEXT, NULLIF(obs.nom_role::TEXT, ''::TEXT), NULLIF(obs.prenom_role::TEXT, ''::TEXT)),
                   ', '::TEXT)      AS observers
    FROM
        pr_occtax.cor_role_releves_occtax cor_role_1
            JOIN utilisateurs.t_roles obs ON cor_role_1.id_role = obs.id_role
    GROUP BY cor_role_1.id_releve_occtax
)
SELECT
    rel.id_releve_occtax
  , rel.id_dataset
  , rel.id_digitiser
  , rel.date_min
  , rel.date_max
  , rel.altitude_min
  , rel.altitude_max
  , rel.meta_device_entry
  , rel.comment
  , rel.geom_4326
  , rel."precision"
  , rel.observers_txt
  , dataset.dataset_name
  , occ.taxons
  , concat_ws('<br/>'::TEXT, occ.taxons,
              CASE
                  WHEN rel.date_min::DATE = rel.date_max::DATE
                      THEN to_char(rel.date_min, 'DD/MM/YYYY'::TEXT)
                  ELSE concat(to_char(rel.date_min, 'DD/MM/YYYY'::TEXT), ' - ',
                              to_char(rel.date_max::DATE::TIMESTAMP WITH TIME ZONE, 'DD/MM/YYYY'::TEXT))
                  END, COALESCE(cor_role.observers_txt, rel.observers_txt::TEXT)) AS leaflet_popup
  , COALESCE(cor_role.observers_txt, rel.observers_txt::TEXT)                     AS observateurs
  , occ.nb_occ
  , cor_role.nb_observer
FROM
    pr_occtax.t_releves_occtax rel
        JOIN gn_meta.t_datasets dataset ON dataset.id_dataset = rel.id_dataset
        LEFT JOIN observateurs cor_role ON cor_role.id_releve_occtax = rel.id_releve_occtax
        LEFT JOIN occurrences occ ON occ.id_releve_occtax = rel.id_releve_occtax;

ALTER TABLE v_releve_list
    OWNER TO fcloitre;

